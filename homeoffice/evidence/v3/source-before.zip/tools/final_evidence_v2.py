from pathlib import Path
import json,shutil,subprocess
R=Path(__file__).resolve().parents[1];repo=R.parent/'deployment/Friendslop_HomeOffice'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip()
p=R/'evidence/pages-validation.json';v=json.loads(p.read_text(encoding='utf8'));v['testedSourceCommit']=head;p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
for name in ['pages-validation.json','v2-pages-game.png']:shutil.copyfile(R/'evidence'/name,repo/'homeoffice/evidence'/name)
test_names={'v2-bindings-ownership.json':'actual-two-browser-controls-ownership','v2-storage-visual.json':'actual-browser-storage-drawer','v2-living-props.json':'engine-storage-light-fixtures','v2-authority.json':'engine-authority-fixtures','pages-validation.json':'public-two-browser-rtc-synthetic-microphone'}
summary={'sourceCommit':head,'completeProduct':False,'checks':[]}
for name,kind in test_names.items():
 data=json.loads((R/'evidence'/name).read_text(encoding='utf8'));rows=[x for x in data['results']if 'passed'in x]
 assert all(x['passed']for x in rows),name
 assert not data.get('errors'),name
 summary['checks'].append({'evidence':name,'type':kind,'passed':len(rows),'failed':0})
summary['notes']=['Passing subset checks are not 80 full acceptance tests.','No real-person microphone or separate-WAN-PC claim.','Eight Chromium processes on one PC: latest low graphics host 12–14 FPS, target not met.']
for target in [R/'evidence/v2-delivery-verification.json',repo/'homeoffice/evidence/v2-delivery-verification.json']:target.write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
for base in [R,repo/'homeoffice']:
 p=base/'docs/v2/acceptance-80.md';s=p.read_text(encoding='utf8');s=s.replace('미통과 · v2-multiplayer-scale.json 2/4/8 동시 Chromium. 8개 동일 PC host 6~7fps. STT 동시 1080p 별도 32~38fps. 목표 성능 및 전체 메모리/대역폭 미달/미계측','미통과 · 이전 기본 8인 6~7fps, v2-multiplayer-scale-low.json 최신 저사양 8인 12~14fps. 별도 한국어 인식 측정은 korean-stt-measurement.md. 모든 기능 동시 목표 성능 및 전체 메모리/대역폭 미달/미계측');p.write_text(s,encoding='utf8',newline='\n')
 p=base/'docs/deployment.md';s=p.read_text(encoding='utf8');s+='\n실제 공개 빌드 검사: 커밋 `'+head+'`의 GitHub Pages 빌드가 `built`임을 확인하고 HTTPS/P2P 두 브라우저 검사 6개를 통과했다. WASM/PCK 해시는 `evidence/pages-validation.json`과 `docs/v2/web-build-manifest.json`에서 비교한다. 이 시험은 같은 PC의 독립 Chromium 두 개이며 실제 사람 마이크·서로 다른 WAN의 검증이 아니다.\n';p.write_text(s,encoding='utf8',newline='\n')
body='''단순 집/편집기 방향을 Godot 4.6.1/GDScript의 캐릭터 시점 소셜 생활 공간으로 개편했습니다. 2층 본관·연결 게임 별동·두 스포츠 코트·확장 개인실, 사용자 제공 남자 GLB와 Blender 제작 원본, 실제 웹 export를 포함합니다. 기존 main과 Firebase/Blender 프로젝트는 보존했습니다.

[GitHub Pages에서 실행](https://mjayj9.github.io/Friendslop_HomeOffice/). `docs/`는 실행 빌드, `homeoffice/`는 소스·에셋·제작 스크립트·저장 스키마·검증 증거입니다. 호스트 기준 이동/소품/좌석/생활/권한, WebRTC 음성, Yjs 동시 한글, 보드·PDF·레이저·주석, 자체 미로/러너, 공간 파일과 정상 방장 이전/강제 종료 복구를 연결했습니다. 뚜껑 있는 수납함·서랍·조명은 실제 움직임과 내용 보관/전원/저장으로 작동합니다. 22개 물리 키 재설정과 원격 소품 보간도 포함합니다.

실제 검증:

- 공개 HTTPS 주소에서 두 독립 Chromium: 초기화·공개 시그널링·이동·한글 채팅·합성 마이크 RTP·WASM/PCK 해시 6개 통과.
- 두 브라우저 실제 보행/키 조작으로 키 재설정·재접속 보존·입력 해제·상자/좌석 동시 경합·책 수납/뚜껑/다운로드 9개 통과. 수정된 수납함/서랍 실제 화면과 다운로드 4개 추가 통과.
- 엔진 수납/조명/참조 복원 12개, 권위/오래된 세션/위조 이동 14개, Node 저장·규칙 12개 통과. 엔진 위치 고정 시험과 브라우저/사람 플레이를 구분합니다.
- 독립 Chromium 2/4/8명 연결, 같은 이름의 고유 개인실과 퇴장 후 확장 보존. 실제 Yjs 한글/PDF/레이저/주석/방장 이전과 합성 음성 범위 시험은 개별 evidence에 기록했습니다.
- 실제 한국어 Whisper tiny q8: 합성 6문장 CER 17.2%/WER 29.7%. 실제 사람 품질 수치가 아닙니다.

**전체 제품 완료가 아니므로 Draft입니다.** 자연스러운 전체 캐릭터 동작/손·발 그립, 완결된 팀 경기, 전체 회의 흐름/질문, 실제 사람 음질/STT, WAN·장시간·모든 기능 동시 통합 인수가 필수 미완료입니다. 최신 저사양에서 같은 PC의 8개 Chromium 호스트가 12~14fps로 성능 목표에 미달했습니다. U01~U56과 80개 인수의 모든 범위 및 부분 증거/미완료는 `homeoffice/docs/v2/`에 유지합니다.
'''
(R/'evidence/pr-body-v2.md').write_text(body,encoding='utf8')
print(json.dumps(summary,ensure_ascii=False,indent=2))
