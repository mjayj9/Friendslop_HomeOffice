from pathlib import Path
R=Path(__file__).resolve().parents[1];s=(R/'tests/v2-browser-collaboration.mjs').read_text(encoding='utf8')
start=s.index(' await a.screenshot({path:');end=s.index('\n}catch(e)',start)
s=s[:start]+'''
 await a.locator('#closeTool').click({force:true});await move(a,10,11);await move(a,10,6);await aim(a,9,1.85,4.14);await a.keyboard.press('KeyE');await wait(a,()=>!document.getElementById('presentation').hidden);
 await a.locator('#slideUpload').setInputFiles('homeoffice/tests/meeting-fixture.pdf');await wait(a,()=>document.getElementById('slidePage').textContent==='1 / 2',40000);await a.locator('#slideNext').click({force:true});await wait(a,()=>document.getElementById('slidePage').textContent==='2 / 2');pass('Actual uploaded PDF renders and page changes');
 await b.locator('#closeTool').click({force:true});await move(b,10,11);await move(b,10,6);await aim(b,9,1.85,4.14);await b.keyboard.press('KeyE');await wait(b,()=>!document.getElementById('presentation').hidden);await wait(b,()=>document.getElementById('slidePage').textContent==='2 / 2',40000);pass('Second browser receives PDF bytes and synchronized page');await b.screenshot({path:'homeoffice/evidence/v2-pdf-shared.png'});
 await b.locator('#slidePrev').click({force:true});await b.waitForTimeout(300);assert.equal(await b.locator('#slidePage').textContent(),'2 / 2');pass('Unapproved guest cannot turn presenter pages');
 await a.locator('#closeTool').click({force:true});await a.screenshot({path:'homeoffice/evidence/v2-slide-in-game.png'});await a.evaluate(()=>Homeoffice.menu());const[download]=await Promise.all([a.waitForEvent('download'),a.locator('#export').click({force:true})]);await download.saveAs('homeoffice/evidence/v2-with-pdf.homeworld');pass('Download includes actual original PDF bytes');
''' +s[end:]
s=s.replace('v2-browser-collaboration.json','v2-browser-presentation.json').replace('v2-browser-collaboration.log','v2-browser-presentation.log').replace('v2-video','v2-presentation-video');(R/'tests/v2-browser-presentation.mjs').write_text(s,encoding='utf8')
