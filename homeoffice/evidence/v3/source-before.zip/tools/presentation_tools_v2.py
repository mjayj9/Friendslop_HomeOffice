from pathlib import Path
p=Path(__file__).resolve().parents[1]
f=p/'web/presentation.mjs';s=f.read_text(encoding='utf8');s="import {validatePresentationView} from './presentation-view.mjs';\n"+s
s=s.replace('inWorld,notify})','inWorld,inWorldPointer,notify})')
s=s.replace('<canvas id="slideCanvas"','<div class="row"><label>발표 도구 <select id="slideTool"><option value="laser">레이저</option><option value="pen">주석 펜</option></select></label><select id="slideInk"><option value="#c94c36">빨강</option><option value="#315eac">파랑</option><option value="#2b7258">초록</option></select><button id="slideUndo">현재 쪽 주석 되돌리기</button></div><canvas id="slideCanvas"')
s=s.replace("cancelled=false;", "cancelled=false;",1)
marker=' const permitted=who=>'
at=s.index(marker)
s=s[:at]+''' let annotations=[],drawing=null,laserAt=0;const base=document.createElement('canvas');base.width=1280;base.height=720;
 const view=()=>({selected,page,annotations:structuredClone(annotations)});
 function paint(){const c=$('slideCanvas').getContext('2d');c.drawImage(base,0,0);for(const stroke of [...annotations.filter(s=>s.asset===metas[selected]?.id&&s.page===page),...(drawing?[drawing]:[])]){c.strokeStyle=stroke.color;c.lineWidth=4;c.lineCap='round';c.beginPath();stroke.points.forEach((p,i)=>i?c.lineTo(p[0]*1280,p[1]*720):c.moveTo(p[0]*1280,p[1]*720));c.stroke()}}
 function pointer(uv){inWorldPointer?.(uv);paint();if(uv){const c=$('slideCanvas').getContext('2d');c.fillStyle='#f33225';c.beginPath();c.arc(uv[0]*1280,uv[1]*720,7,0,Math.PI*2);c.fill()}}
 function change(m){if(isHost())receive(identity(),m);else send(m)}
 const uv=e=>{const r=$('slideCanvas').getBoundingClientRect();return [Math.max(0,Math.min(1,(e.clientX-r.left)/r.width)),Math.max(0,Math.min(1,(e.clientY-r.top)/r.height))]};
 $('slideCanvas').onpointerdown=e=>{if(!permitted(identity())||!metas[selected])return;if($('slideTool').value==='pen'){drawing={id:crypto.randomUUID(),asset:metas[selected].id,page,color:$('slideInk').value,points:[uv(e)]};$('slideCanvas').setPointerCapture(e.pointerId)}};
 $('slideCanvas').onpointermove=e=>{if(!permitted(identity()))return;if(drawing){if(drawing.points.length<128)drawing.points.push(uv(e));paint()}else if($('slideTool').value==='laser'&&performance.now()-laserAt>80){laserAt=performance.now();change({type:'presentation-pointer',uv:uv(e)})}};
 $('slideCanvas').onpointerup=()=>{if(drawing){if(drawing.points.length>1)change({type:'presentation-ink',stroke:drawing});drawing=null;paint()}};
 $('slideCanvas').onpointerleave=()=>{if(permitted(identity()))change({type:'presentation-pointer',uv:null})};
 $('slideUndo').onclick=()=>change({type:'presentation-undo'});
'''+s[at:]
s=s.replace("inWorld(canvas.toDataURL('image/jpeg',.80).split(',')[1]);", "base.getContext('2d').clearRect(0,0,1280,720);base.getContext('2d').drawImage(canvas,0,0);paint();inWorld(canvas.toDataURL('image/jpeg',.80).split(',')[1]);")
s=s.replace("metas,selected,page,presenter:presenter||identity()", "metas,selected,page,presenter:presenter||identity(),view:view()")
at=s.index("  if(m.type==='asset-request')")
s=s[:at]+'''  if(['presentation-pointer','presentation-ink','presentation-undo'].includes(m.type)){
   if(isHost()&&!permitted(sender))return true;
   if(m.type==='presentation-pointer'){if(m.uv!==null&&(!Array.isArray(m.uv)||m.uv.length!==2||m.uv.some(n=>!Number.isFinite(n)||n<0||n>1)))return true;pointer(m.uv);if(isHost())send(m);return true}
   if(!isHost())return true;
   if(m.type==='presentation-ink'){try{validatePresentationView({selected,page,annotations:[...annotations,m.stroke]},metas);annotations.push(m.stroke)}catch{return true}}
   else{const at=annotations.findLastIndex(s=>s.asset===metas[selected]?.id&&s.page===page);if(at>=0)annotations.splice(at,1)}broadcastState();render();return true;
  }
'''+s[at:]
s=s.replace("metas=m.metas;selected=m.selected;page=m.page;presenter=m.presenter;", "let v;try{v=validatePresentationView(m.view||{selected:m.selected,page:m.page,annotations:[]},m.metas)}catch{return true}metas=m.metas;selected=v.selected;page=v.page;annotations=v.annotations;presenter=m.presenter;")
s=s.replace("session(){return {selected,page,presenter}}", "view,session(){return {...view(),presenter}}")
s=s.replace("setSession(s){selected=s.selected||0;page=s.page||1;presenter=s.presenter||'';", "setSession(s){selected=s.selected||0;page=s.page||1;annotations=structuredClone(s.annotations||[]);presenter=s.presenter||'';")
s=s.replace("restore(list,files){", "restore(list,files,savedView={selected:0,page:1,annotations:[]}){")
s=s.replace("metas=structuredClone(list||[]);selected=0;page=1;presenter='';", "metas=structuredClone(list||[]);const v=validatePresentationView(savedView,metas);selected=v.selected;page=v.page;annotations=v.annotations;presenter='';")
f.write_text(s,encoding='utf8')
f=p/'web/save-v2.mjs';s=f.read_text(encoding='utf8');s="import {validatePresentationView} from './presentation-view.mjs';\n"+s;s=s.replace("['collaboration','presentation']", "['collaboration','presentation','presentationView']")
s=s.replace(' return structuredClone(w);', " if(w.presentationView!==undefined)validatePresentationView(w.presentationView,w.presentation||[]);\n return structuredClone(w);")
# No duplicate attachment IDs or dangling storage object references.
s=s.replace(' return structuredClone(w);', " const attachmentIds=(w.presentation||[]).map(a=>a.id);if(new Set(attachmentIds).size!==attachmentIds.length)bad('중복 발표 자료 ID');for(const o of w.objects)if(o.state.contents?.some(id=>!ids.has(id)||id===o.id))bad('수납 참조 오류');\n return structuredClone(w);")
f.write_text(s,encoding='utf8')
f=p/'web/bridge.mjs';s=f.read_text(encoding='utf8')
s=s.replace("inWorld:image=>push({type:'slide_texture',image})", "inWorld:image=>push({type:'slide_texture',image}),inWorldPointer:uv=>push({type:'slide_pointer',uv})")
s=s.replace('m.world.presentation=presentation.metadata();','m.world.presentation=presentation.metadata();m.world.presentationView=presentation.view();')
s=s.replace('world.presentation=presentation.metadata();','world.presentation=presentation.metadata();world.presentationView=presentation.view();')
# Above replacement also sees the substring in m.world: repair if it introduced a free variable.
s=s.replace('m.world.presentation=presentation.metadata();world.presentationView=presentation.view();m.world.presentationView=presentation.view();','m.world.presentation=presentation.metadata();m.world.presentationView=presentation.view();')
s=s.replace('presentation.restore(candidate.presentation,files)', 'presentation.restore(candidate.presentation,files,candidate.presentationView)')
s=s.replace("if(!host&&m.type==='state'){", "if(!host&&m.type==='state'){if(m.epoch!==epoch)return;")
s=s.replace("if(!host&&m.type==='voice-ranges'){", "if(!host&&m.type==='voice-ranges'){if(m.epoch!==epoch)return;")
s=s.replace("net({type:'voice-ranges',ranges:","net({type:'voice-ranges',epoch,ranges:")
f.write_text(s,encoding='utf8')
f=p/'tools/v2_base.txt';s=f.read_text(encoding='utf8');s=s.replace('"slide_texture":set_slide(String(e.get("image","")))','"slide_texture":set_slide(String(e.get("image","")))\n\t\t"slide_pointer":set_slide_pointer(e.get("uv"))');s='var slide_laser:MeshInstance3D\nvar slide_laser_until=0\n'+s if not s.startswith('extends') else s.replace('\n','\nvar slide_laser:MeshInstance3D\nvar slide_laser_until=0\n',1);f.write_text(s,encoding='utf8')
f=p/'tools/v2_functions.txt';s=f.read_text(encoding='utf8')
s=s.replace('func update_room_lighting(dt:float):','func update_room_lighting(dt:float):\n\tif slide_laser and Time.get_ticks_msec()>slide_laser_until:slide_laser.visible=false')
s+='''
func set_slide_pointer(uv):
	if uv==null:
		if slide_laser:slide_laser.visible=false
		return
	if not uv is Array or uv.size()!=2:return
	if not slide_laser:
		slide_laser=MeshInstance3D.new()
		var sphere=SphereMesh.new();sphere.radius=.025;sphere.height=.05
		var mat=StandardMaterial3D.new();mat.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED;mat.albedo_color=Color(1,.05,.03)
		sphere.material=mat;slide_laser.mesh=sphere;add_child(slide_laser)
	slide_laser.position=Vector3(9+(float(uv[0])-.5)*3.6,1.85+(.5-float(uv[1]))*2.025,4.18)
	slide_laser.visible=true;slide_laser_until=Time.get_ticks_msec()+500
'''
f.write_text(s,encoding='utf8')
print('Shared presenter-authorized laser and persistent page annotations added')
