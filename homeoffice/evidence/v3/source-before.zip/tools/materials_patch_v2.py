from pathlib import Path
p=Path(__file__).resolve().parents[1]
c=p/'art/build_v2.py';s=c.read_text(encoding='utf8').replace("groups={};collisions=[];ASSETS={};current='';objects=[]", "exec(compile((R/'art/materials_v2.py').read_text(encoding='utf8'),'materials_v2.py','exec'))\napply_materials(palette,M,R)\ngroups={};collisions=[];ASSETS={};current='';objects=[]")
s=s.replace('mesh.from_pydata(vertices,[],faces);mesh.update();o=', 'mesh.from_pydata(vertices,[],faces);mesh.update();world_uv(mesh);o=')
c.write_text(s,encoding='utf8')
print('Physical sRGB-to-linear material colors and portable authored surface textures wired into Blender source')
