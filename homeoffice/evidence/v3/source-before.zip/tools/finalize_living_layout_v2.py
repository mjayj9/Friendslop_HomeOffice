from pathlib import Path
import json
R=Path(__file__).resolve().parents[1]
p=R/'assets/v2/layout.json';d=json.loads(p.read_text(encoding='utf8'))
next(x for x in d['furniture'] if x['id']=='living-drawer')['yaw']=-1.57079632679
p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
p=R/'tools/design_v2.py';s=p.read_text(encoding='utf8');s+='\n# Interactive living furniture extension is applied by living_layout_v2.py after regeneration.\n';p.write_text(s,encoding='utf8')
# Dedicated repeatable extension, used after full architectural regeneration.
items=[x for x in d['furniture'] if x['id'] in ['living-storage','living-drawer','living-lamp']]
(R/'tools/living_layout_v2.py').write_text('from pathlib import Path\nimport json\np=Path(__file__).resolve().parents[1]/"assets/v2/layout.json"\nd=json.loads(p.read_text(encoding="utf8"))\nitems='+repr(items)+'\nd["furniture"]=[x for x in d["furniture"] if x["id"] not in {i["id"] for i in items}]+items\np.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding="utf8")\n',encoding='utf8')
print('Drawer opens into living room; repeatable layout extension preserved')
