from pathlib import Path
p=Path(__file__).resolve().parents[1]/'scripts/v2/avatar.gd'
s=p.read_text(encoding='utf8').replace('var desired=Vector3(velocity.x,0,velocity.z)*dt','var desired=Basis(Vector3.UP,float(command.yaw))*Vector3(float(command.x),0,float(command.z)).limit_length(1)*dt*(5.2 if command.run else 3.1)')
p.write_text(s,encoding='utf8')
