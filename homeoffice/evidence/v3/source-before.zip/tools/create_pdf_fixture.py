from pathlib import Path
R=Path(__file__).resolve().parents[1]
objects=[]
def obj(s):objects.append(s.encode('ascii'));return len(objects)
obj('<< /Type /Catalog /Pages 2 0 R >>')
obj('<< /Type /Pages /Kids [3 0 R 5 0 R] /Count 2 >>')
obj('<< /Type /Page /Parent 2 0 R /MediaBox [0 0 640 360] /Resources << /Font << /F1 7 0 R >> >> /Contents 4 0 R >>')
content='q 0.14 0.30 0.24 rg 0 0 640 360 re f Q BT /F1 36 Tf 1 1 1 rg 45 255 Td (MOYEO / WORK TOGETHER) Tj 0 -65 Td /F1 20 Tf (Agenda: make the house a place to live.) Tj ET'
obj(f'<< /Length {len(content)} >>\nstream\n{content}\nendstream')
obj('<< /Type /Page /Parent 2 0 R /MediaBox [0 0 640 360] /Resources << /Font << /F1 7 0 R >> >> /Contents 6 0 R >>')
content='q 0.80 0.43 0.23 rg 0 0 640 360 re f Q BT /F1 36 Tf 1 1 1 rg 45 255 Td (NEXT STEPS) Tj 0 -65 Td /F1 20 Tf (Meet. Cook. Play. Export. Return.) Tj ET'
obj(f'<< /Length {len(content)} >>\nstream\n{content}\nendstream')
obj('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>')
out=b'%PDF-1.4\n';offsets=[0]
for i,s in enumerate(objects,1):offsets.append(len(out));out+=f'{i} 0 obj\n'.encode()+s+b'\nendobj\n'
start=len(out);out+=f'xref\n0 {len(objects)+1}\n0000000000 65535 f \n'.encode()
for n in offsets[1:]:out+=f'{n:010} 00000 n \n'.encode()
out+=f'trailer\n<< /Size {len(objects)+1} /Root 1 0 R >>\nstartxref\n{start}\n%%EOF\n'.encode()
(R/'tests/meeting-fixture.pdf').write_bytes(out)
print('Created original two-page PDF test fixture',len(out))
