from pathlib import Path
p=Path(__file__).resolve().parents[1]
base=p/'tools/v2_base.txt'
s=base.read_text(encoding='utf8').replace('a.position=vec(layout.spawn)+Vector3(0,0,-players.size()*.75)','a.position=vec(layout.spawn)+Vector3(.45,0,-players.size()*.85)\n\ta.remote_target=a.position')
base.write_text(s,encoding='utf8')
c=p/'web/collaboration-source.mjs';s=c.read_text(encoding='utf8')
s=s.replace('binding?.destroy();doc?.destroy();doc=new Y.Doc();if(snapshot)Y.applyUpdate(doc,bytes(snapshot),\'restore\');',"const next=new Y.Doc();try{if(snapshot)Y.applyUpdate(next,bytes(snapshot),'restore');validateCandidate(next)}catch(e){next.destroy();throw e}binding?.destroy();doc?.destroy();doc=next;")
s=s.replace("init();return {open,", "function validateSnapshot(s){const next=new Y.Doc();try{if(s?.update)Y.applyUpdate(next,bytes(s.update));validateCandidate(next);return true}finally{next.destroy()}}\n init();return {open,validate:validateSnapshot,")
c.write_text(s,encoding='utf8')
c=p/'web/presentation.mjs';s=c.read_text(encoding='utf8')
s=s.replace('return {open,hide()',"async function validate(list,files){for(const a of list||[]){const data=files.get(a.id);if(!data)throw Error('누락된 발표 자료');validAttachment(a,data);if(a.mime==='application/pdf'){const task=getDocument({data:data.slice(),isEvalSupported:false});try{const document=await task.promise;if(document.numPages>200)throw Error('PDF는 200쪽까지 지원합니다');await document.getPage(1)}finally{await task.destroy()}}else{const b=await createImageBitmap(new Blob([data],{type:a.mime}));const okay=b.width<=8192&&b.height<=8192;b.close();if(!okay)throw Error('이미지 크기 제한 8192px')}}return true}\n return {open,validate,ready(){return metas.every(a=>attachments.has(a.id))},session(){return {selected,page,presenter}},setSession(s){selected=s.selected||0;page=s.page||1;presenter=s.presenter||'';updateSelect();render()},hide()")
c.write_text(s,encoding='utf8')
c=p/'web/bridge.mjs';s=c.read_text(encoding='utf8')
s=s.replace('pendingWorld=bundle.world;pendingAttachments=bundle.attachments;', 'collaboration.validate(bundle.world.collaboration);await presentation.validate(bundle.world.presentation,bundle.attachments);pendingWorld=bundle.world;pendingAttachments=bundle.attachments;')
s=s.replace("else {push({type:'start',host:false,id,epoch:'',clientId:clientIdentity});entered()}", "else if(!handoffSwitching){push({type:'start',host:false,id,epoch:'',clientId:clientIdentity});playing=false;status('호스트의 확정 상태를 받는 중입니다.')}else entered()")
s=s.replace("status('같은 집에 연결되었습니다. 서로의 캐릭터를 확인하세요.')", "entered();handoffSwitching=false;status('같은 집에 연결되었습니다. 서로의 캐릭터를 확인하세요.')")
s=s.replace("let pendingAttachments=new Map();", "let handoffSwitching=false;let pendingAttachments=new Map();")
c.write_text(s,encoding='utf8')
for name in ['v2-browser-presentation.mjs','v2-browser-collaboration.mjs']:
 c=p/'tests'/name;s=c.read_text(encoding='utf8').replace('i<4;i++','i<24;i++').replace("Math.abs(d)/1.5*1000)","Math.min(350,Math.abs(d)/1.5*1000))").replace("Math.abs(d)/1.2*1000)","Math.min(250,Math.abs(d)/1.2*1000))").replace('i<35;i++','i<80;i++').replace('Math.min(1500,','Math.min(650,')
 c.write_text(s,encoding='utf8')
print('Candidate validation before replacement, join initialization, closed-loop browser steering updated')
