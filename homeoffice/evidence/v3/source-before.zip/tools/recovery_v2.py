from pathlib import Path
p=Path(__file__).resolve().parents[1]
c=p/'web/bridge.mjs';s=c.read_text(encoding='utf8').replace('let perfSample={};','let recoverPending=null;let perfSample={};')
s=s.replace('connections.set(c.peer,c);','connections.set(c.peer,c);c.lastSeen=performance.now();')
s=s.replace("if(performance.now()-windowAt>1000)", "c.lastSeen=performance.now();\n  if(m?.type==='heartbeat')return;\n  if(performance.now()-windowAt>1000)")
start=s.index(" c.on('close',()=>{");end=s.index("\n c.on('error'",start)
s=s[:start]+" c.on('close',()=>forgetConnection(c));"+s[end:]
s=s.replace("if(host){push({type:'start',host:true,id,epoch,clientId:clientIdentity});entered()}", "if(host){push({type:'start',host:true,id,epoch,clientId:clientIdentity});entered();if(recoverPending){const w=recoverPending;recoverPending=null;collaboration.restore(w.collaboration);arcade.restore({records:w.results.arcade||[]});push({type:'restore',world:w});status('마지막 확인 복구본으로 새 세션을 열었습니다. 확인 이후 변경은 포함되지 않을 수 있습니다.')}}")
s+='''
function forgetConnection(c){if(c.retired||connections.get(c.peer)!==c)return;connections.delete(c.peer);sendQueues.delete(c);push({type:'leave',id:c.peer});if(!host){playing=false;stopTransmit();$('network').textContent='호스트 연결 종료';showMenu();status('호스트 연결이 종료되었습니다. 마지막 확인: '+(recoveryTime||'없음')+' · 확인 이후 변경은 잃을 수 있습니다.');$('recoverSession').hidden=false}}
setInterval(()=>{for(const c of [...connections.values()]){if(performance.now()-(c.lastSeen||0)>15000){forgetConnection(c);c.close()}else sendRaw(c,{type:'heartbeat',epoch})}},1000);
const recoveryButton=document.createElement('button');recoveryButton.id='recoverSession';recoveryButton.textContent='마지막 확인 복구본으로 새 세션 열기';recoveryButton.hidden=true;recoveryButton.onclick=async()=>{try{if(!lastWorld)throw Error('확인된 복구본이 없습니다.');const w=validateWorld(lastWorld);collaboration.validate(w.collaboration);await presentation.validate(w.presentation,presentation.attachments);recoverPending=w;for(const c of connections.values()){c.retired=true;c.close()}connections.clear();peer?.destroy();peer=null;recoveryButton.hidden=true;await startOnline()}catch(e){status('복구를 시작하지 못했습니다: '+e.message)}};$('menu').querySelector('.panel').append(recoveryButton);
'''
c.write_text(s,encoding='utf8')
c=p/'tests/v2-multiplayer-scale.mjs';s=c.read_text(encoding='utf8').replace("console.log('FAIL',e.stack)","console.log('FAIL',e.stack);try{const d=await diag(pages[0]);console.log('REMAINING',d.connections,d.currentState?.players.map(p=>p.id))}catch{}")
c.write_text(s,encoding='utf8')
print('Bounded connection heartbeat, explicit last-confirmed recovery session, and complete disconnect cleanup')
