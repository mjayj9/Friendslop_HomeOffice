from pathlib import Path
R=Path(__file__).resolve().parents[1]
p=R/'tests/v2-living-props.gd';s=p.read_text(encoding='utf8')
s=s.replace('check("Held book becomes', 'print("STORED ",box.get_meta("state")," ",a.holding," ",book.freeze," ",book.collision_layer)\n\tcheck("Held book becomes')
s=s.replace('check("Whole world restore', 'print("RESTORED ",box.get_meta("state")," ",book.freeze," ",book.visible)\n\tcheck("Whole world restore')
s=s.replace('action(a,"interact");w.update_living_props(1)\n\tcheck("Drawer', 'print("DRAWER RAY ",w.target(a)," ",a.position," ",a.command);action(a,"interact");w.update_living_props(1);print("DRAWER ",drawer.get_meta("state")," ",drawer.get_node("MovingPart").position)\n\tcheck("Drawer')
s=s.replace('action(a,"interact");w.update_living_props(1);w.update_room_lighting(1)', 'print("LAMP RAY ",w.target(a)," ",a.position," ",a.command);action(a,"interact");w.update_living_props(1);w.update_room_lighting(1);print("LAMP ",lamp.get_meta("state"))')
p.write_text(s,encoding='utf8')
