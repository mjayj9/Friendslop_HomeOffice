from pathlib import Path
import json,shutil
R=Path(__file__).resolve().parents[1];D=R/'docs/v2';layout=json.loads((R/'assets/v2/layout.json').read_text(encoding='utf8'))
rows=['# 공간 프로그램과 도면 기준','', '이 치수는 설계 기본안이다. 공식 경기 규격/건축 법규나 사용자가 원문에서 지정한 숫자로 취급하지 않는다. 실제 생성 기준은 `assets/v2/layout.json`이다.','', '| 공간 | X 범위(m) | Z 범위(m) | 바닥 높이(m) | 바닥 | 천장 | 배치된 기능 사물 수 |','|---|---|---|---:|---|---|---:|']
for room in layout['rooms']:
 a,b,c,d=room['rect'];items=[x for x in layout['furniture'] if a<=x['p'][0]<=c and b<=x['p'][2]<=d and abs(room['y']-x['p'][1])<2]
 rows.append(f"| {room['name']} | {a}~{c} | {b}~{d} | {room['y']} | {room['finish']} | {'있음' if room['ceiling'] else '외부'} | {len(items)} |")
rows+=['','## 문과 창','', '문짝/개구부/창틀의 실제 위치·회전·폭·높이는 layout.json의 doors/walls.openings에 기록했다. 문 뒤 통로를 포함해 엔진 연속 보행을 시험했다. 회의실 문, 거실 통로, 전실 승인문, 개인실 갤러리는 텔레포트 메뉴로 연결하지 않는다.','', '## 개인실과 구역','', '2층 북측 예약 영역 X −6.2~6.2m, Z −33.6~−12m에 최대 4쌍, 8실을 덧붙인다. 2.8m 복도와 5.4m 모듈, 방당 약 4.8×5.4m. 기존 방과 사람/가구의 좌표는 바꾸지 않는다. 참가자가 나가도 방과 배정 슬롯/작업물은 남는다. 가져오기는 옛 접속/점유/권한을 초기화한다.','', 'Session은 접속 그룹, Zone은 실제 물리 구역이다. 근거리/현재 Zone/세션 전체 음성을 별도로 표시한다. 게임 별동의 출입 승인, 사용자별 무기 허가, 허용 Zone을 각각 검증한다. 자유방의 무기는 별도 구역 허가가 필요하다.','', '## 이번 도면 변경','', '거실–홀 통로를 계단 측벽과 겹치지 않는 Z=10.5m로 옮겼다. 마당 벤치를 보행로 밖으로 이동했다. 게임 별동 뒷문을 창으로 바꾸어 승인문 우회를 막았다. 농구 림의 내부 통과 공간을 확보하도록 반지름을 .43m로 조정했다. source layout과 Blender 제작 스크립트를 함께 수정했다.']
(D/'space-program.md').write_text('\n'.join(rows)+'\n',encoding='utf8')
svg='''<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="560" viewBox="0 0 1000 560"><rect width="1000" height="560" fill="#f4f0e8"/><g font-family="Malgun Gothic,Arial" fill="#203d34"><text x="45" y="48" font-size="25">모여집 · U자 계단 단면 / 설계 치수</text><text x="45" y="79" font-size="15">두 층 바닥 연결, 실제 보행 충돌은 완만한 볼록 경사체. 도식은 폭 방향을 펼쳐 표시.</text>'''
svg+='<g stroke="#6f4f30" stroke-width="8" fill="none"><path d="M 65 435 H 125'
for i in range(10):svg+=f' V {435-(i+1)*13} H {125+(i+1)*27}'
svg+=' H 485'
for i in range(10):svg+=f' V {305-(i+1)*13} H {485+(i+1)*27}'
svg+=' H 930"/></g><g stroke="#80968c" stroke-width="2" stroke-dasharray="6 5"><path d="M 55 435 H 935 M 55 175 H 935 M 420 305 H 480"/></g>'
svg+='<text x="70" y="469" font-size="18">1층 +0.00m</text><text x="775" y="157" font-size="18">2층 +3.60m</text><text x="358" y="337" font-size="17">계단참 +1.80m</text><text x="70" y="508" font-size="17">20단 × 0.18m / 디딤판 0.30m / 각 경로 폭 1.50m / 중앙 계단참 깊이 1.50m</text><text x="70" y="536" font-size="14">단면 제안값이며 건축 법규 검토/시공 도면이 아닙니다. 실제 게임의 머리 간섭·발 디딤은 별도 보행 증거를 따릅니다.</text></g></svg>'
(D/'stair-section.svg').write_text(svg,encoding='utf8')
# Preserve full applicable third-party texts from pinned installed packages.
licenses=R/'docs/licenses';licenses.mkdir(exist_ok=True)
for package,name in [('yjs','Yjs-MIT'),('y-quill','Y-Quill-MIT'),('quill','Quill-BSD-3'),('pdfjs-dist','PDFjs-Apache-2.0'),('@huggingface/transformers','TransformersJS-Apache-2.0'),('onnxruntime-web','ONNX-Runtime-MIT')]:
 folder=R/'node_modules'/package
 found=next((folder/f for f in ['LICENSE','LICENSE.txt','LICENSE.md'] if (folder/f).exists()),None)
 if found:shutil.copyfile(found,licenses/(name+'.txt'))
print('Room program, staircase section and pinned third-party license texts written')
