from pathlib import Path
p=Path(__file__).resolve().parents[1]/'tests/v2-navigation.gd';s=p.read_text(encoding='utf8').replace('[3.8,-30.9]','[2.7,-30.9]');p.write_text(s,encoding='utf8')
