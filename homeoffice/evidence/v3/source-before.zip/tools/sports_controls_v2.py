from pathlib import Path
p=Path(__file__).resolve().parents[1]
f=p/'project.godot';s=f.read_text(encoding='utf8').replace('common/physics_ticks_per_second=60','jolt_physics_3d/simulation/continuous_cd_movement_threshold=0.15\njolt_physics_3d/simulation/continuous_cd_max_penetration=0.02\njolt_physics_3d/simulation/penetration_slop=0.005\ncommon/physics_ticks_per_second=60');f.write_text(s,encoding='utf8')
f=p/'tools/v2_functions.txt';s=f.read_text(encoding='utf8').replace('request_action("kick");return','request_action("kick_start");return')
s=s.replace('func _unhandled_input(event):','func _unhandled_input(event):\n\tif event is InputEventKey and event.keycode==KEY_F and not event.pressed and playing():\n\t\tif players.has(local_id) and players[local_id].holding=="":request_action("kick");return')
s=s.replace('\tif action in ["read","drop","throw"]:', '''	if action=="drop" and p.holding!="" and definitions[p.holding].kind=="basketball":
		actions[id]=order
		var ball=objects[p.holding];release(p,false);ball.linear_velocity=p.direction()*6+Vector3.UP*1.1
		return
	if action in ["read","drop","throw"]:''')
s=s.replace('\tif action=="kick":', '\tif action=="kick_start":\n\t\tp.set_meta("kick_started",Time.get_ticks_msec());return\n\tif action=="kick":')
old='if ball and p.position.distance_to(ball.position)<1.5 and ball.get_meta("owner","")=="" and zone_at(p.position)=="football":ball.linear_velocity=(p.direction()+Vector3.UP*.18).normalized()*11'
new='''if ball and p.position.distance_to(ball.position)<1.5 and ball.get_meta("owner","")=="" and zone_at(p.position)=="football":
			var power=clampf((Time.get_ticks_msec()-int(p.get_meta("kick_started",Time.get_ticks_msec()-500)))/1000.0,0,1.2)
			ball.linear_velocity=(p.direction()+Vector3.UP*.18).normalized()*(5+power*10)
			p.remove_meta("kick_started")'''
assert old in s;s=s.replace(old,new).replace(' · F 차기',' · F 길게 누른 뒤 슛 / 짧게 패스');f.write_text(s,encoding='utf8')
print('CCD thresholds tightened from actual floor penetration; physical passes and charged football kicks')
