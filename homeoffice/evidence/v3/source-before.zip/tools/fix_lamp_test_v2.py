from pathlib import Path
p=Path(__file__).resolve().parents[1]/'tests/v2-living-props.gd';s=p.read_text(encoding='utf8').replace('w.update_living_props(1);w.update_room_lighting(1)','w.update_living_props(1);w.local_id="local";w.update_room_lighting(1)');p.write_text(s,encoding='utf8')
