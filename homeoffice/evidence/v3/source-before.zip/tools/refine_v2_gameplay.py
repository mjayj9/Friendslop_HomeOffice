from pathlib import Path
R=Path(__file__).resolve().parents[1]
p=R/'tools/v2_base.txt';s=p.read_text(encoding='utf8').replace('var weapon_grants={}','var weapon_grants={}\nvar weapon_zones=["game"]\nvar rounds={"basketball":{"phase":"practice","mode":"practice","seconds":0.0},"football":{"phase":"practice","mode":"practice","seconds":0.0},"tag":{"phase":"ready","mode":"targets","seconds":0.0}}\nvar score_labels={}')
s=s.replace('"grants":weapon_grants}', '"grants":weapon_grants,"weaponZones":weapon_zones,"rounds":rounds}')
s=s.replace('weapon_grants=m.get("grants",{})','weapon_grants=m.get("grants",{})\n\t\t\tweapon_zones=m.get("weaponZones",["game"])\n\t\t\trounds=m.get("rounds",rounds)')
s=s.replace('d.state=o.get_meta("state",{}).duplicate(true)','d.state=o.get_meta("state",{}).duplicate(true)\n\t\td.state.erase("reloadUntil")\n\t\td.state.erase("nextShot")')
s=s.replace('var grip=p.eye()+p.direction()*1.05+Vector3(0,-.35,0)','''var grip=p.eye()+p.direction()*.60+Vector3(0,-.38,0)
\t\tif definitions[p.holding].kind=="basketball" and p.get_meta("dribble",false):grip.y=p.position.y+.28+absf(sin(Time.get_ticks_msec()*.009))*.80
\t\tvar desired=Basis.from_euler(Vector3(float(p.command.pitch),float(p.command.yaw),0)).get_rotation_quaternion()
\t\tif definitions[p.holding].kind=="marker":desired=Quaternion(Vector3.DOWN,p.direction())
\t\tvar turn=desired*o.quaternion.inverse()
\t\tif turn.w<0:turn=-turn
\t\to.angular_velocity=(turn.get_axis()*turn.get_angle()*10).limit_length(9)''')
s=s.replace('\t\to.angular_velocity=Vector3.ZERO\n','')
s=s.replace('var pt=hit.point\n\t\t\tvar uv=', 'var pt=objects[p.holding].global_transform*Vector3(0,-.10,0)\n\t\t\tif absf(pt.z-board_body.position.z)>.22:return\n\t\t\tvar uv=')
s=s.replace('"color":"#183b32","width":4})','"color":"#183b32","width":4,"physical":true})')
s=s.replace('if action in ["stroke","undo"]:\n', '''if action in ["stroke","undo"]:
\t\tif data.get("physical",false):
\t\t\tif p.holding=="" or definitions[p.holding].kind!="marker":return
\t\t\tvar tip=objects[p.holding].global_transform*Vector3(0,-.10,0)
\t\t\tif absf(tip.z-board_body.position.z)>.25:return
''')
p.write_text(s,encoding='utf8')
p=R/'tools/v2_functions.txt';s=p.read_text(encoding='utf8')
s=s.replace('zone_at(players[id].position)=="game"','zone_at(players[id].position) in weapon_zones')
s=s.replace('if action=="grant":','''if action=="round":
\t\tif id!=local_id:return
\t\tvar game=String(data.get("game",""))
\t\tif not rounds.has(game):return
\t\tvar op=String(data.get("op",""))
\t\tif op=="prepare":rounds[game]={"phase":"rules","mode":String(data.get("mode","timed")),"seconds":0.0}
\t\tif op=="start":
\t\t\trounds[game].phase="countdown"
\t\t\trounds[game].seconds=3.0
\t\t\tif game=="basketball":basketball_score=[0,0]
\t\t\telif game=="football":football_score=[0,0]
\t\t\telse:tag_score.clear()
\t\tif op=="end":rounds[game].phase="results";rounds[game].seconds=0.0
\t\tif op=="practice":rounds[game].phase="practice"
\t\treturn
\tif action=="weapon_zone":
\t\tif id!=local_id:return
\t\tweapon_zones=["game","free"] if data.get("free",false) else ["game"]
\t\treturn
\tif action=="grant":''')
s=s.replace('func update_living(dt:float):\n', '''func update_living(dt:float):
\tfor game in rounds:
\t\tvar round=rounds[game]
\t\tif round.phase in ["countdown","play"]:
\t\t\tround.seconds=maxf(0,float(round.seconds)-dt)
\t\t\tif round.seconds<=0:
\t\t\t\tif round.phase=="countdown":round.phase="play";round.seconds=120.0
\t\t\t\telse:
\t\t\t\t\tround.phase="results"
\t\t\t\t\tif game=="tag":weapon_grants.clear()
''')
s=s.replace('if previous.y>centre.y and at.y<=centre.y and ball.linear_velocity.y<0:', 'if rounds.basketball.phase in ["practice","play"] and previous.y>centre.y and at.y<=centre.y and ball.linear_velocity.y<0:')
s=s.replace('if crossed:\n','if crossed and rounds.football.phase in ["practice","play"]:\n')
s=s.replace('if not allowed_weapon(id):return\n\tvar p=players[id]', 'if not allowed_weapon(id) or not rounds.tag.phase in ["practice","play"]:return\n\tvar p=players[id]')
s=s.replace('if zone_at(other.position)!="game":return','if not zone_at(other.position) in weapon_zones:return')
s=s.replace('var hit=get_world_3d().direct_space_state.intersect_ray(query)\n\tif not hit.is_empty() and hit.collider in players.values():','var hit=get_world_3d().direct_space_state.intersect_ray(query)\n\temit_toy_effect(muzzle,hit.get("position",muzzle+p.direction()*22))\n\tif not hit.is_empty() and hit.collider.get_meta("object_id","").begins_with("target-"):\n\t\ttag_score[id]=int(tag_score.get(id,0))+1\n\t\treject(id,"타깃 명중 · "+str(tag_score[id])+"점")\n\tif not hit.is_empty() and hit.collider in players.values():')
s=s.replace('if zone=="basketball":label+=','if zone=="game":label+=" · 라운드 "+rounds.tag.phase+" "+str(int(rounds.tag.seconds))+"초"\n\tif zone=="basketball":label+=')
s+='''
func emit_toy_effect(from:Vector3,to:Vector3):
\tshow_toy_effect(from,to)
\tsend({"type":"toy_effect","epoch":epoch,"from":arr(from),"to":arr(to)})

func show_toy_effect(from:Vector3,to:Vector3):
\tvar mesh=MeshInstance3D.new()
\tvar line=ImmediateMesh.new()
\tvar mat=StandardMaterial3D.new()
\tmat.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED
\tmat.albedo_color=Color("ffb950")
\tline.surface_begin(Mesh.PRIMITIVE_LINES,mat)
\tline.surface_add_vertex(from)
\tline.surface_add_vertex(to)
\tline.surface_end()
\tmesh.mesh=line
\tadd_child(mesh)
\tget_tree().create_timer(.09).timeout.connect(mesh.queue_free)
\tvar audio=AudioStreamPlayer3D.new()
\taudio.stream=load("res://assets/audio/toy-pop.wav")
\taudio.position=from
\taudio.volume_db=-15
\taudio.max_distance=22
\tadd_child(audio)
\taudio.play()
\taudio.finished.connect(audio.queue_free)

func setup_game_targets():
\tfor i in range(3):
\t\tvar body=StaticBody3D.new()
\t\tbody.position=Vector3(33.5,1.5,-4+i*2)
\t\tbody.set_meta("object_id","target-"+str(i))
\t\tcollision(body,Vector3.ZERO,Vector3(.10,1.05,1.05))
\t\tvar mesh=MeshInstance3D.new()
\t\tvar cylinder=CylinderMesh.new()
\t\tcylinder.top_radius=.48
\t\tcylinder.bottom_radius=.48
\t\tcylinder.height=.05
\t\tmesh.mesh=cylinder
\t\tmesh.rotation.z=PI/2
\t\tvar mat=StandardMaterial3D.new()
\t\tmat.albedo_color=Color("e99451")
\t\tmesh.material_override=mat
\t\tbody.add_child(mesh)
\t\tadd_child(body)
'''
p.write_text(s,encoding='utf8')
p=R/'tools/v2_base.txt';s=p.read_text(encoding='utf8').replace('\tsetup_presentation()','\tsetup_presentation()\n\tsetup_game_targets()').replace('\t\t"tool":\n','\t\t"toy_effect":show_toy_effect(vec(m.from),vec(m.to))\n\t\t"tool":\n');p.write_text(s,encoding='utf8')
p=R/'web/bridge.mjs';s=p.read_text(encoding='utf8');s+='''
const roundsPanel=document.createElement('div');roundsPanel.innerHTML='<h3>경기 진행 (방장)</h3><select id="gamePick"><option value="basketball">농구</option><option value="football">축구</option><option value="tag">타깃 / 태그</option></select><select id="gameMode"><option value="timed">시간제</option><option value="team">두 팀</option><option value="targets">타깃 연습</option></select><div class="row"><button data-round="prepare">규칙 확인</button><button data-round="start">시작 / 재시작</button><button data-round="end">경기 종료</button><button data-round="practice">자유 연습</button></div><p>3초 준비 뒤 2분 경기입니다. 코트 양쪽 점수로 경쟁합니다. 농구는 위에서 아래 통과, 축구는 골라인 통과가 득점입니다. 태그는 비유혈 놀이이며 사람/구역 승인이 별도로 필요합니다.</p><button id="freeWeapons">자유방 무기 구역 허용 / 해제</button>';$('hostControls').append(roundsPanel);roundsPanel.querySelectorAll('[data-round]').forEach(b=>b.onclick=()=>{if(host)push({type:'action',action:'round',data:{game:$('gamePick').value,mode:$('gameMode').value,op:b.dataset.round}})});$('freeWeapons').onclick=()=>{if(host)push({type:'action',action:'weapon_zone',data:{free:!currentState?.weaponZones?.includes('free')}})};
''';p.write_text(s,encoding='utf8')
p=R/'tools/design_v2.py';s=p.read_text(encoding='utf8').replace("wall('game_s',[20,6],[36,6],openings=[gap(4,2.2)","wall('game_s',[20,6],[36,6],openings=[gap(4,2.2,1,1.7,'window')");p.write_text(s,encoding='utf8')
p=R/'tests/v2-browser-walk.mjs';s=p.read_text(encoding='utf8').replace('await move(0,10.8);await move(0,11);','await move(3,7);await move(0,7);await move(0,11);');p.write_text(s,encoding='utf8')
# Original, generated toy sound; no borrowed game audio.
import wave,struct,math,random
a=R/'assets/audio';a.mkdir(exist_ok=True);random.seed(10)
with wave.open(str(a/'toy-pop.wav'),'wb') as out:
 out.setnchannels(1);out.setsampwidth(2);out.setframerate(22050)
 samples=[]
 for i in range(3308):
  t=i/22050;v=(math.sin(2*math.pi*(620*t-1100*t*t))*.45+random.uniform(-1,1)*.17)*math.exp(-t*36);samples.append(struct.pack('<h',int(v*16000)))
 out.writeframes(b''.join(samples))
print('Physical marker contact, held orientation, round state machines and original toy feedback added')
