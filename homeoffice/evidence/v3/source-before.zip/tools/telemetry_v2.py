from pathlib import Path
p=Path(__file__).resolve().parents[1]
c=p/'tools/v2_base.txt';s=c.read_text(encoding='utf8').replace('\tif snapshot_timer>2 and host:', '\tif bridge and tick%120==0:bridge.performance_sample(JSON.stringify({"fps":Engine.get_frames_per_second(),"frameMs":1000.0/maxf(1,Engine.get_frames_per_second()),"staticMemory":Performance.get_monitor(Performance.MEMORY_STATIC),"drawCalls":Performance.get_monitor(Performance.RENDER_TOTAL_DRAW_CALLS_IN_FRAME),"objects":objects.size(),"players":players.size()}))\n\tif snapshot_timer>2 and host:')
c.write_text(s,encoding='utf8')
c=p/'web/bridge.mjs';s=c.read_text(encoding='utf8').replace('let pendingAttachments=new Map();','let pendingAttachments=new Map();')
s=s.replace("let handoffSwitching=false;","let perfSample={};let handoffSwitching=false;").replace("ready(){loaded=true;","performance_sample:json=>{perfSample=JSON.parse(json)},ready(){loaded=true;").replace("return {host,id,epoch,room,playing,loaded,currentState", "return {performance:perfSample,host,id,epoch,room,playing,loaded,currentState")
c.write_text(s,encoding='utf8')
print('Actual Godot performance monitors exposed read-only')
