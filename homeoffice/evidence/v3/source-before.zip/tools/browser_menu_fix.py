from pathlib import Path
p=Path(__file__).resolve().parents[1]
c=p/'tests/v2-browser-handoff.mjs';s=c.read_text(encoding='utf8').replace("await a.locator('#menuButton').click({force:true})","await a.keyboard.press('Escape')").replace("await b.locator('#menuButton').click({force:true})","await b.keyboard.press('Escape')")
c.write_text(s,encoding='utf8')
