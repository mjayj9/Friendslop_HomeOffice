from pathlib import Path
R=Path(__file__).resolve().parents[1];p=R/'tools/v2_base.txt';s=p.read_text(encoding='utf8')
s=s.replace('var build_kind=""','var build_kind=""\nvar build_angle=0.0\nvar build_point=Vector3.ZERO\nvar build_valid=false')
s=s.replace('update_hint()\n\tboard_cooldown','update_build_preview()\n\tupdate_object_visuals()\n\tupdate_hint()\n\tboard_cooldown')
s=s.replace('\t\t"resume":Input.mouse_mode', '\t\t"build":begin_build(String(e.get("kind","")))\n\t\t"resume":Input.mouse_mode')
s=s.replace('p.holding=s.hold','p.holding=s.hold')
# Delete objects absent from authoritative state after cooking/consumption.
s=s.replace('\t\t\tfor s in m.objects:\n', '\t\t\tvar live_objects=[]\n\t\t\tfor value in m.objects:live_objects.append(value.id)\n\t\t\tfor object_id in objects.keys():\n\t\t\t\tif not object_id in live_objects:objects[object_id].queue_free();objects.erase(object_id);definitions.erase(object_id)\n\t\t\tfor s in m.objects:\n')
p.write_text(s,encoding='utf8')
p=R/'tools/v2_functions.txt';s=p.read_text(encoding='utf8')
s=s.replace('func _unhandled_input(event):\n','''func _unhandled_input(event):
\tif build_kind!="":
\t\tif event is InputEventKey and event.pressed and not event.echo:
\t\t\tif event.keycode==KEY_R:build_angle+=PI/4;return
\t\t\tif event.keycode in [KEY_ESCAPE,KEY_B]:end_build()
\t\tif event is InputEventMouseButton and event.pressed and event.button_index==MOUSE_BUTTON_LEFT and playing():
\t\t\tif build_valid:request_action("place",{"kind":build_kind,"p":arr(build_point),"yaw":build_angle})
\t\t\treturn
''')
s=s.replace('\thint.text=label\n','\tif build_kind!="":label=("클릭 설치" if build_valid else "설치 불가 · 충돌 또는 보호 구역")+" · R 회전 · B 취소"\n\thint.text=label\n')
s=s.replace('\tif action=="rest":','''\tif action=="eat":
\t\tif p.seated!="" and p.holding!="" and definitions[p.holding].kind=="plate":
\t\t\tvar plate=objects[p.holding]
\t\t\tif plate.get_meta("state",{}).get("food",false):plate.set_meta("state",{"food":false,"dirty":true});revision+=1
\t\treturn
\tif action=="rest":''')
s=s.replace('if event.keycode==KEY_Z:request_action("rest");return','if event.keycode==KEY_Z:request_action("eat" if players.has(local_id) and players[local_id].seated!="" and players[local_id].holding!="" and definitions[players[local_id].holding].kind=="plate" else "rest");return')
s=s.replace('\tif p.holding!="":\n\t\tlabel+=','\tif p.seated!="" and p.holding!="" and definitions[p.holding].kind=="plate":label+=" · Z 먹기"\n\tif p.holding!="":\n\t\tlabel+=')
start=s.index('func place_object(')
s=s[:start]+'''func placement_size(kind:String) -> Vector3:
\tvar sizes={"chair":Vector3(.58,1.18,.58),"table":Vector3(2.8,.84,1.2),"sofa":Vector3(2.65,1.15,1.1),"bed":Vector3(1.2,1.3,2.15)}
\treturn sizes.get(kind,Vector3(.48,.48,.48))

func placement_ok(p,kind:String,point:Vector3,angle:float) -> bool:
\tif p.eye().distance_to(point)>4 or point.y < -.25 or point.y>7:return false
\tif zone_at(point) in ["hall","upper_hall","personal-gallery","basketball","football","vestibule"]:return false
\tfor area in layout.protected:
\t\tif area.has("p") and point.distance_to(vec(area.p))<float(area.radius):return false
\tvar floor_ray=PhysicsRayQueryParameters3D.create(point+Vector3.UP*.15,point-Vector3.UP*.25,1)
\tvar ground=get_world_3d().direct_space_state.intersect_ray(floor_ray)
\tif ground.is_empty() or ground.normal.y<.7:return false
\tvar ray=PhysicsRayQueryParameters3D.create(p.eye(),point+Vector3.UP*.3,1,[p.get_rid()])
\tif not get_world_3d().direct_space_state.intersect_ray(ray).is_empty():return false
\tvar q=PhysicsShapeQueryParameters3D.new()
\tvar shape=BoxShape3D.new()
\tshape.size=placement_size(kind)
\tq.shape=shape
\tq.transform=Transform3D(Basis(Vector3.UP,angle),point+Vector3.UP*(shape.size.y/2+.02))
\tq.collision_mask=1|2|4
\tq.exclude=[p.get_rid()]
\treturn get_world_3d().direct_space_state.intersect_shape(q,1).is_empty()

func place_object(id:String,data:Dictionary):
\tvar kind=String(data.get("kind",""))
\tif not kind in ["chair","table","sofa","book","crate","marker","gun","shield","bed","plate"] or not data.get("p") is Array or data.p.size()!=3:return
\tfor n in data.p:
\t\tif not (n is int or n is float) or not is_finite(float(n)) or absf(n)>110:return
\tif not (data.get("yaw") is int or data.get("yaw") is float) or not is_finite(float(data.yaw)):return
\tif objects.size()>=256:return reject(id,"가구 한도 256개입니다")
\tvar p=players[id]
\tif kind in ["gun","shield"] and not allowed_weapon(id):return
\tvar point=vec(data.p)
\tvar angle=snappedf(float(data.yaw),PI/4)
\tif not placement_ok(p,kind,point,angle):return reject(id,"충돌, 거리 또는 보호 구역으로 설치할 수 없습니다")
\tvar object_id="placed-"+str(revision)+"-"+str(objects.size())
\tif kind in ["book","crate","marker","gun","shield","plate"]:point.y+=.25
\tspawn_object({"id":object_id,"kind":kind,"p":arr(point),"yaw":angle,"state":{}})
\trevision+=1

func begin_build(kind:String):
\tif not kind in ["chair","table","sofa","book","crate","marker","gun","shield","bed","plate"]:return
\tend_build()
\tbuild_kind=kind
\tbuild_angle=yaw
\tbuild_preview=model(kind)
\tadd_child(build_preview)
\tfor node in build_preview.find_children("*","MeshInstance3D",true,false):
\t\tvar mat=StandardMaterial3D.new()
\t\tmat.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA
\t\tmat.albedo_color=Color(0.25,.9,.65,.48)
\t\tmat.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED
\t\tnode.material_override=mat

func end_build():
\tbuild_kind=""
\tif build_preview:build_preview.queue_free();build_preview=null

func update_build_preview():
\tif build_kind=="" or not players.has(local_id):return
\tvar p=players[local_id]
\tvar projected=p.position+p.direction()*2.7
\tprojected.y=p.position.y
\tprojected.x=snappedf(projected.x,.25)
\tprojected.z=snappedf(projected.z,.25)
\tbuild_point=projected
\tbuild_valid=placement_ok(p,build_kind,build_point,build_angle)
\tbuild_preview.position=build_point
\tbuild_preview.rotation.y=build_angle
\tfor node in build_preview.find_children("*","MeshInstance3D",true,false):node.material_override.albedo_color=Color(.25,.9,.65,.48) if build_valid else Color(1,.25,.18,.48)

func update_object_visuals():
\tfor id in objects:
\t\tvar o=objects[id]
\t\tvar state=o.get_meta("state",{})
\t\tif definitions[id].kind=="plate":
\t\t\tvar food=o.get_node_or_null("FoodVisual")
\t\t\tif state.get("food",false) and not food:
\t\t\t\tfood=model("meal");food.name="FoodVisual";food.position.y=.1;o.add_child(food)
\t\t\tif food and not state.get("food",false):food.queue_free()
\t\tif definitions[id].kind=="cooker":
\t\t\tvar contents=o.get_node_or_null("CookingVisual")
\t\t\tif state.has("cooking") and not contents:
\t\t\t\tcontents=model("meal");contents.name="CookingVisual";contents.position=Vector3(0,1.14,.15);o.add_child(contents)
\t\t\tif contents:
\t\t\t\tif state.has("cooking"):contents.scale=Vector3.ONE*(1.1 if state.get("ready",false) else .65+.1*sin(Time.get_ticks_msec()*.005))
\t\t\t\telse:contents.queue_free()
'''
p.write_text(s,encoding='utf8')
p=R/'web/bridge.mjs';s=p.read_text(encoding='utf8').replace("action:(action,data)=>push({type:'action',action,data})", "action:(action,data)=>push(action==='build_begin'?{type:'build',kind:data.kind}:{type:'action',action,data})");p.write_text(s,encoding='utf8')
print('Added in-world placement preview/rotation/host geometry checks and visible cooking/plate contents')
