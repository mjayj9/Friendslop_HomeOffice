from pathlib import Path
import json,shutil,hashlib
p=Path(__file__).resolve().parents[1];repo=p.parent/'deployment/Friendslop_HomeOffice'
perf=p/'docs/v2/performance.md';s=perf.read_text(encoding='utf8').replace('75% 렌더 스케일','65% 렌더 스케일');s+='''
## 최종 저사양 옵션 비교

`evidence/v2-graphics.json`: 같은 Intel UHD/D3D11 PC에서 호스트 1920×1080/손님 1280×720 두 창. 호스트 기본 설정 14fps(545 draw calls), 저사양 26~27fps(244 draw calls). 저사양은 65% 렌더 해상도·MSAA 끄기·태양 그림자 끄기·근처 조명 2개이며 방과 가구/물리는 유지한다. 손님은 비교 중 기본 품질이었다. 이는 한 정지 시점의 측정으로 목표 30/60fps 또는 8인 성능 보장이 아니다.

Intel/소프트웨어 WebGL에서는 저사양을 자동 선택하며, 메뉴에서 사용자가 바꾼 값을 기기에 기억한다. 공개 최종 브라우저 시험의 FPS/선택 품질은 pages-validation.json의 해당 표본을 따른다. 이전 8인 시험은 조명/품질 구성과 뷰포트가 다르므로 개선 효과의 정확한 8인 수치로 환산하지 않는다.
''';perf.write_text(s,encoding='utf8')
f=p/'docs/v2/korean-stt-measurement.md';s=f.read_text(encoding='utf8');s+='\n최종 번들 회귀에서 같은 6문장 인식 결과를 확인했다. 기본 품질 1080p 한 브라우저의 해당 실행 FPS 표본은 46~47, 추론은 1.29~1.50초였다. 이전 32~38fps 측정과 코드/조명 구성이 다르며 실제 사람 품질 비교가 아니다.\n';f.write_text(s,encoding='utf8')
f=p/'docs/v2/acceptance-80.md';s=f.read_text(encoding='utf8').replace('실제 localhost 하위 경로 Godot WASM/PCK/GLB/폰트/JS 통과. 공개 Pages 증거는 pages-validation.json 참조(없으면 미검증)','실제 localhost 및 GitHub Pages HTTPS 하위 경로 Godot 초기화, 두 브라우저 공개 시그널링/이동/한글 대화/RTP 통과. WASM/PCK SHA256 일치 · pages-validation.json');f.write_text(s,encoding='utf8')
f=p/'docs/deployment.md';s=f.read_text(encoding='utf8').replace('**실제 배포/브라우저 확인 결과는','2026-09-15 실제 Pages 배포와 두 독립 Chromium의 공개 시그널링·이동·한글 대화·합성 마이크 RTP를 검증했습니다. 서로 다른 WAN 두 PC 시험은 아닙니다. **실제 배포/브라우저 확인 결과는');f.write_text(s,encoding='utf8')
(p/'docs/architecture.md').write_text('''# V2 런타임 구조

Godot 4.6.1 Compatibility 단일 스레드/Jolt 60Hz가 건축·이동·소품·좌석·생활·스포츠·권한의 기준이다. `scripts/v2/world.gd`는 `tools/v2_base.txt`와 `v2_functions.txt`를 `assemble_v2.py`로 조합한 실행 파일이다. `scripts/v2/avatar.gd`는 캐릭터 물리/절차 동작, `scripts/v2/board.gd`는 실제 보드 렌더링이다.

Session은 연결 그룹/epoch/호스트, Zone은 실제 물리적 방이다. `assets/v2/layout.json`에서 도면·방/복도·개인실 확장과 구역을 정의한다. BlenderMCP `art/build_v2.py`는 메시/단순 충돌/anchor/GLB와 `.blend` 원본을 만든다. 네트워크와 무관한 제작 도구이며 런타임은 포트 9876에 접근하지 않는다.

`web/bridge.mjs`는 JavaScriptBridge 이벤트와 PeerJS 1.5.5 binary WebRTC data transport를 중계한다. Godot WebRTCMultiplayerPeer와 PeerJS 호환을 가정하지 않았다. 이동/상태는 혼잡 시 오래된 것을 버릴 수 있는 전송, 행동/협업은 순서 있는 큐, 첨부물은 별도 bulk 큐를 사용한다. 호스트가 입력/거리/가림/점유/구역/점수/권한을 검증한다. 입력 예측과 상태 보정은 있지만 완전한 재적용/원격 소품 보간은 미완료다.

음성은 별도의 실제 RTC media track이며 근거리 밖은 송신 경로를 닫는다. Zone 전체/승인된 Session 전체, 차단/PTT/장치 설정을 구분한다. 변경된 권한과 media signaling의 순서 경합에서 권한 도착 전에는 answer하지 않는다. 신뢰 가능한 호스트·수정하지 않은 클라이언트를 가정하며 암호학적 사적 공간을 보장하지 않는다.

`web/collaboration-source.mjs`는 Yjs+Quill의 동시 보고서/메모/마인드맵이다. `presentation.mjs`는 PDF.js/이미지/페이지·레이저·주석·권한, `arcade.mjs`는 호스트의 실제 미로/러너 규칙, `captions.mjs`와 local-stt/worker는 선택적 한국어 인식이다. UI 입력 중 게임 이동은 막는다.

`save-v2.mjs`는 버전 있는 ZIP 컨테이너 검증과 생성, `handoff.mjs`는 확인 장벽→체크포인트→준비→권위 이전→재연결이다. 강제 종료는 마지막 확인본으로 새 세션을 만들며 무중단 이전과 구분한다. 가구·전체 문서·자료·개인실을 함께 다루는 통합 인수의 잔여 범위는 docs/v2/required-remaining.md를 따른다.

Jolt CCD 바닥 접촉 오차를 실제 드리블로 측정하여 continuous_cd_movement_threshold=.15, continuous_cd_max_penetration=.02, penetration_slop=.005를 사용했다. [Godot 4.6 공식 설정](https://docs.godotengine.org/en/4.6/classes/class_projectsettings.html#class-projectsettings-property-physics-jolt-physics-3d-simulation-continuous-cd-max-penetration)의 의미를 따르며, 자체 충돌 엔진으로 대체하지 않았다.
''',encoding='utf8')
# Copy final, explicitly scoped changes into the already published branch.
files=['scripts/v2/world.gd','tools/v2_base.txt','tools/v2_functions.txt','tools/bundle_stt.mjs','tools/report_stt_v2.py','web/bridge.mjs','web/stt-worker.mjs','docs/character.md','docs/architecture.md','docs/deployment.md','docs/v2/performance.md','docs/v2/acceptance-80.md','docs/v2/korean-stt-measurement.md','tests/v2-pages.mjs','tests/v2-graphics.mjs','evidence/pages-validation.json','evidence/v2-pages-game.png','evidence/v2-graphics.json','evidence/v2-graphics-75percent.json','evidence/v2-graphics-low.png','evidence/v2-graphics-balanced.png','evidence/v2-stt-browser.json','evidence/v2-stt-metrics.json']
for name in files:shutil.copyfile(p/name,repo/'homeoffice'/name)
for name in ['index.html','index.js','index.pck','index.wasm','index.audio.worklet.js','index.audio.position.worklet.js','bridge.mjs','stt-worker.mjs']:
 shutil.copyfile(p/'build'/name,repo/'docs'/name)
for f in repo.rglob('*'):
 if f.is_file() and '.git' not in f.parts and f.suffix in ['.md','.txt','.gd','.mjs','.js','.json','.html','.py']:
  f.write_bytes(f.read_bytes().replace(b'\r\n',b'\n'))
for name in ['homeoffice/scripts/v2/world.gd','homeoffice/tools/v2_base.txt','docs/index.html']:
 f=repo/name;f.write_bytes(f.read_bytes().rstrip()+b'\n')
out=repo/'docs';rows=[{'file':str(f.relative_to(out)).replace('\\','/'),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}for f in out.rglob('*')if f.is_file()]
v={'version':'0.2.0-dev','engine':'4.6.1.stable.official.14d19694e','sourceBranch':'codex/godot-homeoffice-v2','initialGameWeightsExcluded':True,'totalHostedBytes':sum(x['bytes']for x in rows),'files':rows}
for f in [p/'docs/v2/web-build-manifest.json',repo/'homeoffice/docs/v2/web-build-manifest.json']:f.write_text(json.dumps(v,indent=2)+'\n',newline='\n')
print('Final source, quality options, public evidence and SHA manifest staged for publication')
