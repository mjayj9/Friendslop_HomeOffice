from pathlib import Path
R=Path(__file__).resolve().parents[1]
p=R/'tools/v2_base.txt';s=p.read_text(encoding='utf8').replace('ambient_light_energy=.50','ambient_light_energy=.30').replace('sun.light_energy=1.05','sun.light_energy=.62').replace('lamp.light_energy=.55','lamp.light_energy=.32');p.write_text(s,encoding='utf8')
p=R/'art/build_v2.py';s=p.read_text(encoding='utf8')
s=s.replace("if c.name in ['V2_house','V2_grounds']","if c.name.split('.')[0] in ['V2_house','V2_grounds']")
s=s.replace("finish('house')", """# Living detail: original artwork, folded curtains, bookshelf and covered entry.
shelf(-13.3,0,3.3,2.3)
box('art frame',[-13.25,1.9,11.86],[1.7,1.12,.08],'walnut')
box('art paper',[-13.25,1.9,11.80],[1.55,.96,.025],'cloth')
sphere([-13.55,2.02,11.775],[.27,.27,.009],'orange',20,10)
box('art horizon',[-13.15,1.75,11.76],[1.2,.14,.015],'sage')
for z in [4.45,9.55]:
 for i in range(7):
  box('linen curtain',[-14.8+.06*math.sin(i*2),1.85,z+i*.085],[.065,2.45,.095],'cloth')
box('curtain track',[-14.8,3.1,7],[.10,.07,5.9],'metal')
rectslab([-3.6,12,0,14.2],2.95,'walnut',False,.12)
for x in [-3.45,-.15]:cyl('porch column',[x,1.43,14.05],.05,2.86,'metal')
for lo,hi in [(-4.7,-3.0),(-.6,1.2)]:
 for i in range(int((hi-lo)/.15)):
  box('entry timber slat',[lo+i*.15,1.42,12.13],[.085,2.84,.07],'oak')
finish('house')""")
s=s.replace("rectslab(L['site'], -.17,'grass',True,.24)", "rectslab(L['site'], -.17,'grass',True,.24)\nrectslab([-250,-250,250,250],-.22,'grass',False,.02)")
p.write_text(s,encoding='utf8')
print('Reduced overexposed lighting; authored curtain, bookshelf, artwork, porch and continuous landscape')
