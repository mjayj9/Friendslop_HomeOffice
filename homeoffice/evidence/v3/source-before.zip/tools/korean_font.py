from pathlib import Path
import urllib.request
from fontTools.ttLib import TTFont
from fontTools import subset
R=Path(__file__).resolve().parents[1];fonts=R/'assets/fonts';fonts.mkdir(exist_ok=True)
source=R/'.runtime/NotoSansKR.ttf'
if not source.exists():urllib.request.urlretrieve('https://raw.githubusercontent.com/google/fonts/main/ofl/notosanskr/NotoSansKR%5Bwght%5D.ttf',source)
urllib.request.urlretrieve('https://raw.githubusercontent.com/google/fonts/main/ofl/notosanskr/OFL.txt',fonts/'OFL-NotoSansKR.txt')
font=TTFont(source);options=subset.Options();options.name_IDs=['*'];options.name_legacy=True;options.name_languages=['*'];sub=subset.Subsetter(options=options);sub.populate(unicodes=list(range(32,127))+list(range(0xAC00,0xD7A4))+list(range(0x3130,0x318F))+list(range(0x1100,0x1200)));sub.subset(font);font.save(fonts/'NotoSansKR-game.ttf')
p=R/'tools/v2_functions.txt';s=p.read_text(encoding='utf8').replace('label.text=text\n','label.text=text\n\tlabel.font=load("res://assets/fonts/NotoSansKR-game.ttf")\n');p.write_text(s,encoding='utf8')
print('Korean OFL font', (fonts/'NotoSansKR-game.ttf').stat().st_size,'bytes')
