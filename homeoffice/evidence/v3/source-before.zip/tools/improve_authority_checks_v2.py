from pathlib import Path
R=Path(__file__).resolve().parents[1]
p=R/'tests/v2-authority.gd';s=p.read_text(encoding='utf8');s=s.replace('check("Previous epoch action is rejected",w.epoch!=checkpoint.state.epoch)', '''var old_order=w.actions.get("local",-1)
	w.perform("local",{"epoch":checkpoint.state.epoch,"seq":seq+100,"action":"interact","data":{}})
	check("Previous epoch action is rejected without unseating or consuming sequence",w.players.local.seated==chair_id and w.actions.get("local",-1)==old_order)
	var before_command=w.players.local.command.duplicate(true)
	w.handle_packet("local",{"type":"input","epoch":w.epoch,"command":{"x":999.0,"z":0.0,"yaw":0.0,"pitch":0.0,"seq":1000,"jump":false,"run":false}})
	check("Out-of-range client movement cannot replace authoritative input",w.players.local.command==before_command)
	w.handle_packet("local",{"type":"input","epoch":checkpoint.state.epoch,"command":{"x":1.0,"z":0.0,"yaw":0.0,"pitch":0.0,"seq":1001,"jump":false,"run":false}})
	check("Previous epoch movement cannot change new host state",w.players.local.command==before_command)''');p.write_text(s,encoding='utf8')
print('Replaced epoch comparison with actual stale action and malicious movement requests')
