from pathlib import Path
p=Path(__file__).resolve().parents[1]
c=p/'tools/v2_functions.txt';s=c.read_text(encoding='utf8').replace('"roomClaims":room_claims,"tagScore":tag_score}', '"roomClaims":room_claims,"tagScore":tag_score}.duplicate(true)')
s=s.replace('member_slots=checkpoint.memberSlots.duplicate(true)', '''for player in players.values():
			if player.holding!="" and objects.has(player.holding):
				var held=objects[player.holding]
				held.gravity_scale=0;held.add_collision_exception_with(player);player.add_collision_exception_with(held)
		member_slots=checkpoint.memberSlots.duplicate(true)''')
s=s.replace('var p=players[id]\n\tif kind in ["gun","shield"]', 'var p=players[id]\n\tif move_id!="" and p.eye().distance_to(objects[move_id].position)>3.5:return\n\tif kind in ["gun","shield"]')
c.write_text(s,encoding='utf8')
