from pathlib import Path
import re,json
R=Path(__file__).resolve().parents[1];D=R/'docs/v2'
source=(R/'docs/requirements-v2/Friendslop_Godot_HomeOffice_V2_Complete_Architecture_KO.md').read_text(encoding='utf8')
requirements=[];tests=[]
for line in source.splitlines():
 if re.match(r'\| U\d\d \|',line):requirements.append([x.strip() for x in line.strip('|').split('|')])
 if re.match(r'\| T\d\d \|',line):tests.append([x.strip() for x in line.strip('|').split('|')])
assert len(requirements)==56 and len(tests)==80
world='scripts/v2/world.gd';art='art/build_v2.py · assets/v2/';web='web/bridge.mjs'
mapping={}
def set_(ids,status,files,behavior,evidence,remaining):
 for n in ids:mapping[f'U{n:02}']=[status,files,behavior,evidence,remaining]
set_([1,2,4,52],'구현',world+' · '+web,'공유 집, 캐릭터 이동, WebRTC 호스트 세션','evidence/v2-browser-collaboration.json','WAN 두 사람 통화/전체 통합 생활 검증 필수 미완료')
set_([3],'검증완료','artifacts/legacy-before-godot-20260914.zip · artifacts/homeoffice-p1-before-v2-20260914.zip','기존 Firebase/Three.js와 P1/Blender 보존','P1 ZIP CRC 검증 + 기존 artifact-audit.json','신규 원격 배포는 별도 저장소')
set_([5,6],'구현','web/save-v2.mjs · '+world,'V2 전체 가구/개인실/문/보드/Yjs/첨부물 단일 파일','evidence/v2-shared.homeworld','최신 전체 첨부물 왕복·임시 세계 복원 검증 필수 미완료')
set_([7,32,53,56],'구현','assets/v2/layout.json · '+art,'2층 본관, 외피, 계단, 별동, 코트, 개인실 갤러리','site-plan.svg · ground-floor.svg · upper-floor.svg · evidence/v2-navigation.json','전체 실제 화면/동선/재질/생활 디테일 품질 검증 필수 미완료')
set_([8],'구현','scripts/v2/avatar.gd · '+world,'Jolt 60Hz, 제한 집기, CCD 공, 계단 경사 충돌, 문턱 보정','evidence/v2-navigation.json','고속 림/벽, 저천장, 예측/원격물체 보간 정밀 검사 필수 미완료')
set_([9,10,11],'구현','assets/characters/ · art/prepare_character.py','제공 GLB 5개 확인, 남자 모델과 신규 간이 리깅/절차 동작','docs/character-audit.json · art/male-character.blend','원본에 애니메이션/스킨 없음. 전체 동작과 손/발 IK 필수 미완료')
set_([12,23,24,31,45],'구현',world+' · assets/v2/gun.glb · assets/v2/shield.glb','별도 출입 승인, 사용자/구역별 무기 검증, 발사/재장전/방향 방패','컴파일 실행만; 기능 인수 미실행','라운드/효과/정밀 그립/권한회수 공격 테스트 필수 미완료')
set_([13,43,44],'구현',world+' · assets/v2/grounds.glb','독립 코트, CCD 공, 충전 슛/킥, 교차선 기반 점수, 밖으로 나간 공 복귀','실제 보행 코트 접근 시험; 득점 인수 미실행','드리블·경기 모드·중복 득점·실제 슛 감각 검증 필수 미완료')
set_([14,15,16,17],'구현',web,'근거리/Zone/세션 모드, 방장 범위/방송 허가, 실제 트랙 제한','P1 synthetic RTP 증거는 V2 완료 근거 아님','V2 실제 두 사람 마이크, 벽/문/층 감쇠 정밀화, 차단 경합 필수 미완료')
set_([18,19],'제약','web/captions.mjs','ko-KR provider probe, local 우선/외부 동의, 중간·확정 자막 경로','실제 사람 인식 시험 미실행','한국어 provider 실측 비교·CER/WER·FPS·마이크 품질 필수 미완료. 정확도 주장 없음')
set_([20,21,22,25,26,27,28,29,30],'구현',world+' · web/activities.mjs · assets/v2/manifest.json','가구 미리보기/회전/호스트 설치, 좌석, 책, 마카, 상자 계약','V2 대부분 컴파일만; P1 검증과 별도','전체 catalog 이동/삭제, 수납, 실제 펜촉/그립 및 점유 경합 필수 미완료')
set_([33,34],'구현',world+' · scripts/board.gd','회의실 좌석, 3D 보드/확대 획 공유/작성자 Undo','V2 컴파일; 전체 보드 검증 미실행','도형·한글 텍스트·선택/이동·실제 펜촉 필수 미완료')
set_([35,36,37],'구현','web/collaboration-source.mjs · web/collaboration.mjs','Yjs/Quill 보고서, 메모/그룹/투표, 마인드맵 노드/연결/이동','evidence/v2-browser-collaboration.json','한국어 Undo·재접속·표·경합/복원 확장 인수 필수 미완료')
set_([38,39],'구현','web/presentation.mjs · '+world+' · web/collaboration-source.mjs','PDF.js/이미지 업로드, 페이지/발표권한, 실제 3D스크린, 의제/결론/손들기/타이머','코드 연결; 최신 브라우저 발표 시험 미실행','레이저/주석/질문·발표 자료 큐 스트레스·전체 회의 시나리오 필수 미완료')
set_([40,41],'구현',world+' · assets/v2/office_left.glb · assets/v2/gallery.glb','append-only 슬롯/개인실/복도 끝벽/독립 문·책상','엔진 8실 좌표 불변 + 실제 2브라우저/2실','재접속 신원/동시 동일명 슬롯·2/4/8 실제 브라우저 보행/조명 검증 필수 미완료')
set_([42],'구현',world+' · assets/v2/layout.json','자유방과 일반 가구, 무기 허가 별도 검증','전체 보행 진행 중','자유방 모든 협업도구 접속 및 배치 검증 필수 미완료')
set_([46,47],'구현','web/activities.mjs · assets/v2/arcade.glb','사용자 확인: 미로 수집/적 회피. 자체 미로게임과 공룡 러너','사용자 의미 확인. 실제 게임 루프 시험 미실행','기계 입장·관전·결과·나가기·호스트 점수 검증 필수 미완료')
set_([48,49,50,51],'구현',world+' · scripts/v2/avatar.gd · '+art,'침대/소파 상태, 재료/조리/담기/식사/정리와 시각 상태','최신 생활 인수 미실행','전체 동작/그립, 중복 소비, 소파 탄성, 두 요리 경로 검증 필수 미완료')
set_([54,55],'구현','project.godot · export_presets.cfg · art/build_v2.py','4.6.1 stable 및 matching nothreads templates, 실제 BlenderMCP 제작','evidence/v2-export.log · evidence/v2-browser-smoke.log · art/moyeo-v2.blend','최신 Pages 배포·1080p 2~8인 성능 필수 미완료')
rows=['# U01~U56 원문 요구 추적표','', '상태는 미착수/설계/구현/검증완료/제약이다. `구현`은 인수 통과를 뜻하지 않는다. 각 행의 남은 항목은 모두 **필수 미완료**이며 범위에서 제외하지 않았다. P1 시험은 V2 전체 완료 근거로 사용하지 않는다.','', '| ID | 원문 요구 | 상태 | 구현 파일/에셋 | 실제 동작 | 검증 근거 | 남은 문제 |','|---|---|---|---|---|---|---|']
for u in requirements:rows.append('| '+' | '.join([u[0],u[1],*mapping.get(u[0],['미착수','','','','필수 미완료'])])+' |')
(D/'requirements-traceability.md').write_text('\n'.join(rows)+'\n',encoding='utf8')
out=['# T01~T80 인수 테스트','', '실행 환경과 증거를 개별 기록한다. 한 요구의 일부 자동 시험 통과를 전체 인수 완료로 확장하지 않는다.','', '| ID | 분야 | 원문 시험 | 실제 결과/근거 |','|---|---|---|---|']
evidence={'T01':'실제 Chromium 진입 확인 / evidence/v2-entry-game.png','T03':'이전 소스 및 P1 ZIP 보존, Firebase 작업 없음','T04':'Godot 4.6.1 및 matching nothreads template 실제 export; BlenderMCP 실행과 GLB 확인','T05':'같은 layout.json에서 도면과 모델 생성. 변경/치수 최종 화면 대조 미완료','T14':'엔진 8실 + 실제 2브라우저 2실 통과. 4/8브라우저 미실행','T15':'엔진 첫 개인실 책상 좌표 불변 통과. 사람/소품 전체 회귀 미실행','T19':'제공 5 GLB 검사; 스킨/애니메이션 클립 없음. 간이 신규 리깅 원본 별도','T22':'실제 2브라우저 한글 조합 중 W 입력 이동 차단 통과. 아케이드 등 전체 미실행','T46':'실제 2브라우저 메모 공유 통과. 그룹/투표/타이머/복원 전체 미실행','T47':'실제 2브라우저 노드 공유 통과. 연결/이동/삭제/복원 전체 미실행','T48':'두 Chromium CDP 한글 조합 동시 commit 수렴 통과. 사람 IME·Undo·재접속 추가 미실행','T64':'독립 Chromium 2프로세스 actual WebRTC/로컬 signaling 성공; WAN 미실행','T70':'가구/개인실/보드/Yjs 실제 다운로드. 최신 첨부물 전체 왕복 미실행','T77':'V2 WASM/PCK 실제 localhost 하위 경로 로딩 통과. Pages 미실행','T80':'56개 모두 이 표에 보존. 전체 제품 필수 미완료'}
for t in tests:out.append('| '+' | '.join(t[:3]+[evidence.get(t[0],'미실행 · 필수 인수 미완료')])+' |')
(D/'acceptance-80.md').write_text('\n'.join(out)+'\n',encoding='utf8')
print('56 requirements and 80 tests retained with honest partial evidence')
