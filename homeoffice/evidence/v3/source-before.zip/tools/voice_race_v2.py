from pathlib import Path
p=Path(__file__).resolve().parents[1];f=p/'web/bridge.mjs';s=f.read_text(encoding='utf8')
s=s.replace("const item={call,active:true};outgoing.set(who,item);", "const item={call,active:true,started:performance.now()};outgoing.set(who,item);")
s=s.replace("const out=outgoing.get(who);", "let out=outgoing.get(who);if(out&&performance.now()-out.started>3000&&!out.call.peerConnection?.remoteDescription){callStop(out.call);outgoing.delete(who);out=null;}")
s=s.replace("function receiveVoice(call){\n if(!isMember", "async function receiveVoice(call){\n // Signaling and the host policy use different channels. Never answer before permission arrives.\n for(let n=0;n<15&&isMember(call.peer)&&!blocked.has(call.peer)&&!audible(call.peer);n++)await new Promise(resolve=>setTimeout(resolve,100));\n if(!isMember")
f.write_text(s,encoding='utf8')
print('Wait for host policy before answering; retry unanswered RTC negotiation after bounded timeout')
