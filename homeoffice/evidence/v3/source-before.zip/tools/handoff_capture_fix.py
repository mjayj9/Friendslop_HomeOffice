from pathlib import Path
p=Path(__file__).resolve().parents[1]
c=p/'web/handoff.mjs';s=c.read_text(encoding='utf8').replace("const checkpoint=JSON.parse(json);checkpoint.world", "try{const checkpoint=JSON.parse(json);checkpoint.world").replace("checkpoint},transaction.target)}", "checkpoint},transaction.target);console.info('HANDOFF_OFFER_SENT')}catch(e){cancel('체크포인트 생성 실패: '+e.message);console.info('HANDOFF_CAPTURE_ERROR',e.stack)}}")
c.write_text(s,encoding='utf8')
