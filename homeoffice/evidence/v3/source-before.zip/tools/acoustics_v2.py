from pathlib import Path
R=Path(__file__).resolve().parents[1];p=R/'tools/v2_base.txt';s=p.read_text(encoding='utf8').replace('"rounds":rounds}', '"rounds":rounds,"voiceOcclusion":acoustic_links()}');p.write_text(s,encoding='utf8')
p=R/'tools/v2_functions.txt';s=p.read_text(encoding='utf8');s+='''
func acoustic_links() -> Dictionary:
\tvar links={}
\tvar ids=players.keys()
\tfor i in range(ids.size()):
\t\tfor j in range(i+1,ids.size()):
\t\t\tvar a=players[ids[i]]
\t\t\tvar b=players[ids[j]]
\t\t\tif a.position.distance_to(b.position)>26:continue
\t\t\tvar q=PhysicsRayQueryParameters3D.create(a.eye(),b.eye(),1,[a.get_rid(),b.get_rid()])
\t\t\tvar hit=get_world_3d().direct_space_state.intersect_ray(q)
\t\t\tvar gain=1.0
\t\t\tif not hit.is_empty():gain=.22 if doors.has(hit.collider.get_meta("object_id","")) else .10
\t\t\tif absf(a.position.y-b.position.y)>2.5:gain=minf(gain,.08)
\t\t\tlinks[String(ids[i])+"|"+String(ids[j])]=gain
\t\t\tlinks[String(ids[j])+"|"+String(ids[i])]=gain
\treturn links
''';p.write_text(s,encoding='utf8')
p=R/'web/bridge.mjs';s=p.read_text(encoding='utf8').replace("voiceModes={};","voiceModes={},blocksByPeer={};const blocked=new Set();")
s=s.replace("  if(host&&m.type==='voice-settings')", "  if(host&&m.type==='voice-block'){if(typeof m.peer==='string'&&activePeers.has(m.peer)){const list=new Set(blocksByPeer[c.peer]||[]);m.block?list.add(m.peer):list.delete(m.peer);blocksByPeer[c.peer]=[...list]}return}\n  if(host&&m.type==='voice-settings')")
s=s.replace("broadcastAllowed=new Set(m.broadcast||[]);return", "broadcastAllowed=new Set(m.broadcast||[]);blocksByPeer=m.blocks||{};return")
s=s.replace("broadcast:[...broadcastAllowed]}", "broadcast:[...broadcastAllowed],blocks:blocksByPeer}")
s=s.replace("function voiceScope(sender,receiver){", "function voiceScope(sender,receiver){if((blocksByPeer[receiver]||[]).includes(sender)||receiver===id&&blocked.has(sender))return false;")
s=s.replace("function audible(who,outbound=false){", "function audible(who,outbound=false){if(outbound?(blocksByPeer[who]||[]).includes(id):blocked.has(who))return false;")
s=s.replace("if(!isMember(call.peer)||", "if(!isMember(call.peer)||blocked.has(call.peer)||!audible(call.peer)||")
s=s.replace("const occluded=me.zone!==p.zone||Math.abs(me.p[1]-p.p[1])>2", "const acoustic=currentState.voiceOcclusion?.[id+'|'+who]??(me.zone!==p.zone?.id?.zone?.id?.zone?.id?.zone?.id?.zone?.id?0.22:1);const occluded=acoustic<1")
# Replace generated fallback with the actual zone comparison (no schema traversal).
s=s.replace("me.zone!==p.zone?.id?.zone?.id?.zone?.id?.zone?.id?.zone?.id", "me.zone!==p.zone")
s=s.replace("(occluded?.22:1)", "acoustic")
s=s.replace("label.append(slider);$('volumes').append(label)", "const block=document.createElement('button');block.textContent='상대 차단 / 해제';block.onclick=()=>{blocked.has(who)?blocked.delete(who):blocked.add(who);blocksByPeer[id]=[...blocked];if(!host)net({type:'voice-block',peer:who,block:blocked.has(who)});if(blocked.has(who)){incoming.get(who)?.call.close();incoming.delete(who)}gateVoice();updateSpatial()};label.append(slider,block);$('volumes').append(label)")
p.write_text(s,encoding='utf8')
print('Host physics raycast wall/door/floor acoustics and explicit per-peer block routing connected')
