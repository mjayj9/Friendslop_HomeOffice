from pathlib import Path
import re
R=Path(__file__).resolve().parents[1];S=R/'scripts/v2';S.mkdir(parents=True,exist_ok=True)
s=(R/'scripts/world.gd').read_text(encoding='utf8')
s=s.replace('res://scripts/avatar.gd','res://scripts/v2/avatar.gd')
s=s.replace('var bridge','var layout={}\nvar v2_manifest={}\nvar doors={}\nvar door_states={}\nvar room_slots=[]\nvar member_slots={}\nvar module_nodes=[]\nvar room_end:StaticBody3D\nvar weapon_grants={}\nvar tag_score={}\nvar game_clock=0.0\nvar ball_previous={}\nvar basketball_score=[0,0]\nvar football_score=[0,0]\nvar game_results={}\nvar build_kind=""\nvar build_preview:Node3D\nvar bridge',1)
def func(name,code):
 global s
 pattern=rf'(?ms)^func {name}\(.*?(?=^func |\Z)'
 assert re.search(pattern,s),name
 s=re.sub(pattern,lambda _:code.strip()+'\n\n',s,count=1)
func('model','''func model(kind:String) -> Node3D:
	var path="res://assets/v2/"+kind+".glb"
	if not ResourceLoader.exists(path):path="res://assets/environment/"+kind+".glb"
	return load(path).instantiate()''')
func('setup_environment','''func setup_environment():
	layout=JSON.parse_string(FileAccess.get_file_as_string("res://assets/v2/layout.json"))
	v2_manifest=JSON.parse_string(FileAccess.get_file_as_string("res://assets/v2/manifest.json"))
	for k in v2_manifest.assets:manifest.assets[k]=v2_manifest.assets[k]
	for kind in ["house","grounds"]:add_architecture(kind,Vector3.ZERO)
	var env=WorldEnvironment.new()
	var e=Environment.new()
	e.background_mode=Environment.BG_SKY
	var sky=Sky.new()
	var sky_mat=ProceduralSkyMaterial.new()
	sky_mat.sky_top_color=Color("5f94b0")
	sky_mat.sky_horizon_color=Color("c8d9d5")
	sky_mat.ground_horizon_color=Color("c8d9d5")
	sky.sky_material=sky_mat
	e.sky=sky
	e.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR
	e.ambient_light_color=Color("e3e4d8")
	e.ambient_light_energy=.50
	e.tonemap_mode=Environment.TONE_MAPPER_FILMIC
	env.environment=e
	add_child(env)
	var sun=DirectionalLight3D.new()
	sun.rotation_degrees=Vector3(-48,-35,0)
	sun.light_color=Color("fff0d3")
	sun.light_energy=1.05
	sun.shadow_enabled=true
	sun.directional_shadow_max_distance=75
	add_child(sun)
	for r in layout.rooms:
		if not r.ceiling:continue
		var q=r.rect
		var lamp=OmniLight3D.new()
		lamp.position=Vector3((q[0]+q[2])/2,float(r.y)+2.9,(q[1]+q[3])/2)
		lamp.light_color=Color("ffe2b6")
		lamp.light_energy=.55
		lamp.omni_range=7
		lamp.distance_fade_enabled=true
		lamp.distance_fade_begin=15
		lamp.distance_fade_length=8
		add_child(lamp)
	for d in layout.doors:make_door(d)
	door=Node3D.new()
	add_child(door)
	# door is a compatibility placeholder for the previous V1 state field.
	make_label("모여집",Vector3(-1.8,2.8,12.14),0,.08)
	for r in layout.rooms:
		if r.ceiling:make_label(r.name,Vector3(float(r.rect[0])+.35,float(r.y)+2.55,float(r.rect[1])+.16),0,.032)
''')
func('default_furniture','''func default_furniture():
	for d in layout.furniture:spawn_object(d)''')
func('spawn_object','''func spawn_object(d:Dictionary):
	if objects.has(d.id):return
	var kind=String(d.kind)
	var movable=kind in ["crate","book","marker","basketball","football","gun","shield","plate","pan","ingredient","meal"]
	var body:PhysicsBody3D=RigidBody3D.new() if movable else StaticBody3D.new()
	body.name=d.id
	body.set_meta("object_id",d.id)
	body.set_meta("owner","")
	body.set_meta("occupant","")
	body.set_meta("seats",{})
	body.set_meta("state",d.get("state",{}).duplicate(true))
	body.collision_layer=4 if movable else 1
	body.collision_mask=1|2|4
	body.position=vec(d.p)
	body.rotation.y=float(d.yaw)
	body.add_child(model(kind))
	if movable:
		if kind in ["basketball","football","ingredient","meal"]:
			var c=CollisionShape3D.new()
			var shape=SphereShape3D.new()
			shape.radius=.24 if kind=="basketball" else (.22 if kind=="football" else .13)
			c.shape=shape
			body.add_child(c)
		else:
			var sizes={"crate":Vector3(.44,.44,.44),"book":Vector3(.24,.075,.32),"marker":Vector3(.03,.19,.03),"plate":Vector3(.4,.04,.4),"pan":Vector3(.5,.10,.42),"gun":Vector3(.12,.3,.45),"shield":Vector3(.7,.92,.16)}
			collision(body,Vector3.ZERO,sizes[kind])
		body.mass=2.4 if kind=="crate" else (.62 if kind=="basketball" else .4)
		body.continuous_cd=true
		body.linear_damp=.08 if kind in ["basketball","football"] else .5
		body.angular_damp=.3 if kind in ["basketball","football"] else 2
		var physics=PhysicsMaterial.new()
		physics.friction=.65
		physics.bounce=.75 if kind=="basketball" else (.56 if kind=="football" else .08)
		body.physics_material_override=physics
		body.freeze=not host
	elif kind=="chair":
		collision(body,Vector3(0,.26,0),Vector3(.53,.52,.53))
		collision(body,Vector3(0,.84,.24),Vector3(.54,.60,.08))
	else:
		for c in manifest.assets[kind].collisions:add_shape(body,c)
	add_child(body)
	objects[d.id]=body
	definitions[d.id]=d.duplicate(true)
	if not definitions[d.id].has("state"):definitions[d.id].state={}
''')
func('add_player','''func add_player(id:String):
	if players.has(id) or players.size()>=8:return
	var a=Avatar.new()
	a.actor_id=id
	a.local_player=id==local_id
	a.position=vec(layout.spawn)+Vector3(0,0,-players.size()*.75)
	add_child(a)
	players[id]=a
	inputs[id]=-1
	actions[id]=-1
	if a.local_player:a.camera.current=true
	if host:assign_room(id)
''')
# Board front is on the meeting room north wall, not the old two-room coordinate.
s=s.replace('Vector3(9.5,1.76,-4.71)','vec(layout.board)').replace('(pt.x-7.77)','(pt.x-(float(layout.board[0])-1.73))').replace('(2.60-pt.y)','(float(layout.board[1])+.84-pt.y)')
s=s.replace('Vector3(2.8,1.7,3.8)','Vector3(-6.3,1.7,10)').replace('Vector3(-1,.9,-1.5)','Vector3(-11,1,6)')
s=s.replace('Vector3(1,0,3.4)','vec(layout.spawn)')
s=s.replace('var zone="MEETING ROOM" if p.position.x>6 else "LIVING ROOM"','var zone=zone_at(p.position)')
s=s.replace('"run":enabled and Input.is_physical_key_pressed(KEY_SHIFT),','"run":enabled and Input.is_physical_key_pressed(KEY_SHIFT),"crouch":enabled and (Input.is_physical_key_pressed(KEY_C) or Input.is_physical_key_pressed(KEY_CTRL)),')
s=s.replace('"paused":frozen}', '"paused":frozen,"doors":door_states,"roomSlots":room_slots,"basketballScore":basketball_score,"footballScore":football_score,"grants":weapon_grants}')
s=s.replace('for p in players.values():ps.append(p.state())','for p in players.values():\n\t\tvar state=p.state()\n\t\tstate.zone=zone_at(p.position)\n\t\tps.append(state)')
s=s.replace('"occupant":o.get_meta("occupant")}', '"occupant":o.get_meta("occupant"),"state":o.get_meta("state")}')
s=s.replace('a.simulate(dt)\n\t\tupdate_held(dt)','a.simulate(dt)\n\t\tupdate_sports(dt)\n\t\tupdate_living(dt)\n\t\tupdate_held(dt)')
s=s.replace('door.rotation.y=move_toward(door.rotation.y,0.0 if door_open else -PI/2,dt*2)','update_doors(dt)')
s=s.replace('"door":door_open,"paused"','"door":door_open,"paused"')
s=s.replace('door_open=m.door','door_open=m.door\n\t\t\tdoor_states=m.get("doors",{})\n\t\t\tif m.get("roomSlots",[]).size()>room_slots.size():\n\t\t\t\troom_slots=m.roomSlots\n\t\t\t\trebuild_rooms()\n\t\t\tbasketball_score=m.get("basketballScore",[0,0])\n\t\t\tfootball_score=m.get("footballScore",[0,0])\n\t\t\tweapon_grants=m.get("grants",{})')
s=s.replace('p.holding=s.hold','p.holding=s.hold\n\t\t\t\tp.posture=s.get("posture","standing")\n\t\t\t\tp.seat_index=s.get("seatIndex",0)')
s=s.replace('objects[s.id].set_meta("occupant",s.occupant)','objects[s.id].set_meta("occupant",s.occupant)\n\t\t\t\t\tobjects[s.id].set_meta("state",s.get("state",{}))')
s=s.replace('if p.seated!="":objects[p.seated].set_meta("occupant","")','if p.seated!="":clear_seat(p)')
func('save_world','''func save_world() -> Dictionary:
	var os=[]
	for id in definitions:
		var d=definitions[id].duplicate(true)
		var o=objects[id]
		d.p=arr(o.position)
		d.yaw=o.rotation.y
		d.state=o.get_meta("state",{}).duplicate(true)
		os.append(d)
	return {"schemaVersion":2,"worldId":world_id,"assetPack":2,"layoutVersion":2,"roomSlots":room_slots,"objects":os,"doors":door_states,"board":strokes,"revision":revision,"results":{"basketball":basketball_score,"football":football_score},"settings":{"maxPlayers":8}}
''')
func('restore_world','''func restore_world(w:Dictionary):
	for o in objects.values():remove_child(o);o.queue_free()
	objects.clear()
	definitions.clear()
	room_slots=w.get("roomSlots",[]).duplicate(true)
	member_slots.clear()
	rebuild_rooms()
	for d in w.objects:spawn_object(d)
	strokes=w.board.duplicate(true)
	door_states=w.get("doors",{}).duplicate(true)
	if door_states.has("game-gate"):door_states["game-gate"]=false
	weapon_grants.clear()
	world_id=w.worldId
	revision=int(w.revision)
	basketball_score=w.get("results",{}).get("basketball",[0,0])
	football_score=w.get("results",{}).get("football",[0,0])
	for p in players.values():
		p.holding=""
		p.seated=""
		p.posture="standing"
		p.position=vec(layout.spawn)
		if host:assign_room(p.actor_id)
	refresh_board()
''')
# Remaining interaction implementation lives in a separate, inherited game script.
(S/'world_base.gd').write_text(s,encoding='utf8')
(R/'scenes/main.tscn').write_text('[gd_scene load_steps=2 format=3]\n\n[ext_resource type="Script" path="res://scripts/v2/world.gd" id="1"]\n\n[node name="MoyeoHouse" type="Node3D"]\nscript = ExtResource("1")\n',encoding='utf8')
print('V2 host world base generated; previous world.gd preserved')
