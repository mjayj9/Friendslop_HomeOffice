from pathlib import Path
p=Path(__file__).resolve().parents[1]
c=p/'web/captions.mjs';s=c.read_text(encoding='utf8').replace("if(API?.available)try{", "if(navigator.userAgent.includes('HeadlessChrome'))result.onDevice='자동 headless 조회 제약';else if(API?.available)try{")
c.write_text(s,encoding='utf8')
