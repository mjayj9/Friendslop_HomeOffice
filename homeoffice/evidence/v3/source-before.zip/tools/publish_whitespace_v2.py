from pathlib import Path
import json,hashlib
p=Path(__file__).resolve().parents[1];r=p.parent/'deployment/Friendslop_HomeOffice'
f=r/'.gitattributes';f.write_text(f.read_text()+'*.pdf binary\ndocs/licenses/** -whitespace\nhomeoffice/docs/licenses/** -whitespace\nhomeoffice/assets/fonts/*.txt -whitespace\nhomeoffice/docs/requirements-v2/** -whitespace\n',newline='\n')
for path in ['docs/index.html','homeoffice/art/build_assets.py','homeoffice/export_presets.cfg','homeoffice/scripts/v2/world.gd','homeoffice/scripts/world.gd','homeoffice/tests/browser-2p.mjs','homeoffice/tests/browser-life.mjs','homeoffice/tools/v2_base.txt']:
 f=r/path;f.write_bytes(f.read_bytes().rstrip()+b'\n')
out=r/'docs';rows=[{'file':str(f.relative_to(out)).replace('\\','/'),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}for f in out.rglob('*')if f.is_file()]
f=r/'homeoffice/docs/v2/web-build-manifest.json';v=json.loads(f.read_text());v['files']=rows;v['totalHostedBytes']=sum(x['bytes']for x in rows)
for f in [f,p/'docs/v2/web-build-manifest.json']:f.write_text(json.dumps(v,indent=2)+'\n',newline='\n')
