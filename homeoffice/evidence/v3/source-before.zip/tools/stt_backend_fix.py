from pathlib import Path
p=Path(__file__).resolve().parents[1]
c=p/'tools/bundle_stt.mjs';s=c.read_text(encoding='utf8').replace("['ort-wasm-simd-threaded.mjs'","['ort-wasm-simd-threaded.asyncify.mjs','ort-wasm-simd-threaded.asyncify.wasm','ort-wasm-simd-threaded.mjs'")
c.write_text(s,encoding='utf8')
