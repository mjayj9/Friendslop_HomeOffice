from pathlib import Path
R=Path(__file__).resolve().parents[1]
p=R/'tests/v2-multiplayer-scale.mjs';s=p.read_text(encoding='utf8');s=s.replace('v2-multiplayer-scale.json','v2-multiplayer-scale-low.json').replace('v2-eight-players.png','v2-eight-players-low.png').replace('v2-eight-rooms.homeworld','v2-eight-rooms-low.homeworld')
s=s.replace('const browsers=[],pages=[],results=[],samples=[];','const browsers=[],pages=[],results=[],samples=[],errors=[];')
s=s.replace('pages.push(p);await p.goto',"pages.push(p);p.on('pageerror',e=>errors.push(e.message));p.on('console',m=>{if(m.type()==='error')errors.push(m.text())});await p.goto")
s=s.replace('samples.push({players:i+1,host:',"samples.push({players:i+1,quality:(await diag(pages[0])).graphicsQuality,host:")
s=s.replace('samples.push({players:8,host:',"samples.push({players:8,quality:(await diag(pages[0])).graphicsQuality,host:")
s=s.replace("results,samples}","results,samples,errors}")
(R/'tests/v2-multiplayer-scale-low.mjs').write_text(s,encoding='utf8')
print('Separate final low-quality 8-player measurement preserves earlier baseline evidence')
