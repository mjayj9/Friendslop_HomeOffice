from pathlib import Path
p=Path(__file__).resolve().parents[1]
c=p/'web/captions.mjs';s=c.read_text(encoding='utf8');s="import {createLocalSTT} from './local-stt.mjs';\n"+s
s=s.replace('identity,notify})','identity,notify,stream})')
s=s.replace('<option value="browser">','<option value="whisper">Whisper tiny · 로컬 모델 (별도 다운로드)</option><option value="browser">')
s=s.replace('<button id="sttProbe">','<button id="sttDownload">선택형 로컬 모델 다운로드</button><button id="sttProbe">')
s=s.replace('<p class="fine">원음/전사는 저장하지 않습니다.', '<p class="fine">로컬 모델 다운로드는 Hugging Face에서 가중치를 받는 동작입니다. 음성은 보내지 않습니다. 기기 메모리와 CPU를 사용하며 첫 준비는 오래 걸릴 수 있습니다. Whisper 경로는 문장 단위 최종 자막을 제공합니다.<br>원음/전사는 저장하지 않습니다.')
s=s.replace('const API=window.SpeechRecognition', '''const local=createLocalSTT({stream,canTransmit,notify,result:m=>{if(!enabled||!canTransmit())return;send({type:'caption',...m});show({speaker:identity(),...m})}});
 $('sttDownload').onclick=()=>local.load();
 const API=window.SpeechRecognition''')
s=s.replace('function stop(){generation++;','function stop(){if($(\'sttMode\').value===\'whisper\')local.stop();generation++;')
s=s.replace('const support=await probe();if(!API)return;','''if($('sttMode').value==='whisper'){enabled=await local.start();$('sttToggle').textContent=enabled?'자막 인식 끄기':'자막 인식 켜기';return}const support=await probe();if(!API)return;''')
s=s.replace('function tick(){if(!enabled',"function tick(){if($('sttMode').value==='whisper')return;if(!enabled")
s=s.replace("$('sttMode').onchange=()=>{enabled=false;stop();", "$('sttMode').onchange=()=>{enabled=false;local.stop();stop();")
s=s.replace("measuredAccuracy:null}","measuredAccuracy:null,local:local.diagnostics()}")
c.write_text(s,encoding='utf8')
c=p/'web/bridge.mjs';s=c.read_text(encoding='utf8').replace('canTransmit:()=>transmitting(),identity:()=>id,notify:s=>status(s)', 'canTransmit:()=>transmitting(),identity:()=>id,stream:()=>micStream,notify:s=>status(s)')
c.write_text(s,encoding='utf8')
print('Explicit opt-in local speech provider connected; no external speech fallback')
