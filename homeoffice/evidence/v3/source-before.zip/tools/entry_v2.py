from pathlib import Path
p=Path(__file__).resolve().parents[1]
c=p/'tools/v2_base.txt';s=c.read_text(encoding='utf8').replace('var weapon_grants={}','var entry_grants={}\nvar weapon_grants={}')
s=s.replace('if host:assign_room(id)','if host:\n\t\tentry_grants[id]=id==local_id\n\t\tassign_room(id)')
s=s.replace('\t\t\ta.simulate(dt)','\t\t\tvar before=a.position\n\t\t\ta.simulate(dt)\n\t\t\tif zone_at(a.position) in ["game","arcade"] and not allowed_entry(id):\n\t\t\t\ta.position=before;a.velocity=Vector3.ZERO\n\t\t\t\tif Time.get_ticks_msec()-int(a.get_meta("entry_notice",0))>2000:reject(id,"방장의 게임방 출입 허가가 필요합니다");a.set_meta("entry_notice",Time.get_ticks_msec())')
s=s.replace('"grants":weapon_grants,','"entryGrants":entry_grants,"grants":weapon_grants,')
s=s.replace('\t\t\tweapon_grants=m.get("grants",{})','\t\t\tentry_grants=m.get("entryGrants",{})\n\t\t\tweapon_grants=m.get("grants",{})')
s=s.replace('\tweapon_grants.clear()','\tentry_grants.clear()\n\tweapon_grants.clear()')
c.write_text(s,encoding='utf8')
c=p/'tools/v2_functions.txt';s=c.read_text(encoding='utf8').replace('return weapon_grants.get(id,false) and players.has(id)','return allowed_entry(id) and weapon_grants.get(id,false) and players.has(id)')
s=s.replace('if action=="round":','''if action=="entry_grant":
		if id!=local_id or not players.has(String(data.get("peer",""))):return
		var who=String(data.peer)
		entry_grants[who]=bool(data.get("allow",false))
		if not entry_grants[who]:
			weapon_grants[who]=false
			var other=players[who]
			if other.holding!="" and definitions[other.holding].kind in ["gun","shield"]:release(other,false)
			if zone_at(other.position) in ["game","arcade"]:other.position=Vector3(18.7,0,0);other.velocity=Vector3.ZERO
		return
	if action=="round":''')
s=s.replace('\t\tweapon_grants=state.grants.duplicate(true)','\t\tentry_grants=state.get("entryGrants",{}).duplicate(true)\n\t\tweapon_grants=state.grants.duplicate(true)')
s+='\n\nfunc allowed_entry(id:String) -> bool:\n\treturn id==local_id or entry_grants.get(id,false)\n'
c.write_text(s,encoding='utf8')
c=p/'web/bridge.mjs';s=c.read_text(encoding='utf8').replace("row.append(name,weapon,broadcast);", "const entry=document.createElement('button');entry.textContent='게임방 출입 허가 / 회수';entry.onclick=()=>push({type:'action',action:'entry_grant',data:{peer:p.id,allow:!currentState?.entryGrants?.[p.id]}});row.append(name,entry,weapon,broadcast);")
c.write_text(s,encoding='utf8')
print('Host validates game-annex entry per user, including open-gate crossing and immediate revocation')
