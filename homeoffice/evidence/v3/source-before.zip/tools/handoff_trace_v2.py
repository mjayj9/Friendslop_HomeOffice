from pathlib import Path
p=Path(__file__).resolve().parents[1]
c=p/'web/handoff.mjs';s=c.read_text(encoding='utf8').replace("function cancel(reason){","function cancel(reason){console.info('HANDOFF_CANCEL',reason);").replace("async function begin(target){","async function begin(target){console.info('HANDOFF_BEGIN',target);").replace("if(!m.type.startsWith('handoff-'))return false;","if(!m.type.startsWith('handoff-'))return false;console.info('HANDOFF_RECEIVE',m.type,sender);").replace("function captured(json){","function captured(json){console.info('HANDOFF_CAPTURED',json.length);")
c.write_text(s,encoding='utf8')
c=p/'tests/v2-browser-handoff.mjs';s=c.read_text(encoding='utf8').replace("p.on('pageerror',e=>errors.push(e.message));","p.on('pageerror',e=>errors.push(e.message));p.on('console',m=>{if(m.text().startsWith('HANDOFF'))console.log(i,m.text())});")
c.write_text(s,encoding='utf8')
c=p/'web/bridge.mjs';s=c.read_text(encoding='utf8').replace("$('canvas').requestPointerLock?.();","$('canvas').requestPointerLock?.()?.catch(()=>{});")
c.write_text(s,encoding='utf8')
