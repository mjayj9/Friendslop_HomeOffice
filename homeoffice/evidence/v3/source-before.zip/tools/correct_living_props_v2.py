from pathlib import Path
import json
R=Path(__file__).resolve().parents[1]
for name in ['tools/v2_functions.txt','tools/living_functions_v2.txt']:
 p=R/name;p.write_text(p.read_text(encoding='utf8').replace('var item_id=p.holding;var item_kind','var item_id=String(p.holding);var item_kind'),encoding='utf8')
p=R/'assets/v2/layout.json';d=json.loads(p.read_text(encoding='utf8'));drawer=next(x for x in d['furniture'] if x['id']=='living-drawer');drawer.update(p=[-13.6,0,10.75],yaw=1.57079632679);p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
p=R/'tools/living_layout_v2.py';s=p.read_text(encoding='utf8').replace("[-5.7, 0, 6.35]","[-13.6, 0, 10.75]").replace("'yaw': -1.57079632679","'yaw': 1.57079632679");p.write_text(s,encoding='utf8')
p=R/'tests/v2-living-props.gd';s=p.read_text(encoding='utf8').replace('a.holding=book.name','a.holding=String(book.name)');p.write_text(s,encoding='utf8')
print('Moved drawer out of sofa obstruction, normalized item IDs')
