from pathlib import Path
p=Path(__file__).resolve().parents[1]
c=p/'scripts/v2/avatar.gd';s=c.read_text(encoding='utf8').replace('var lying:Node3D','var nickname="친구"\nvar name_label:Label3D\nvar lying:Node3D')
s=s.replace('\tcamera.far=125','''	name_label=Label3D.new()
	name_label.font=load("res://assets/fonts/NotoSansKR-game.ttf")
	name_label.font_size=40;name_label.pixel_size=.003
	name_label.position.y=2.0;name_label.billboard=BaseMaterial3D.BILLBOARD_ENABLED
	name_label.no_depth_test=false;name_label.visible=not local_player
	add_child(name_label)
	camera.far=125''').replace('\tsuper.animate(dt)','\tsuper.animate(dt)\n\tname_label.text=nickname').replace('\ts.posture=posture','\ts.displayName=nickname\n\ts.posture=posture')
c.write_text(s,encoding='utf8')
c=p/'tools/v2_base.txt';s=c.read_text(encoding='utf8').replace('yaw-=event.relative.x*.002','yaw-=event.relative.x*(float(bridge.look_sensitivity()) if bridge else .002)').replace('pitch-event.relative.y*.002','pitch-event.relative.y*(float(bridge.look_sensitivity()) if bridge else .002)')
s=s.replace('\t\t"handoff_freeze":','\t\t"profile":\n\t\t\tif host:set_profile(String(e.id),String(e.get("name","친구")))\n\t\t"handoff_freeze":')
s=s.replace('\t\t\t\tvar p=players[s.id]\n','\t\t\t\tvar p=players[s.id]\n\t\t\t\tp.nickname=String(s.get("displayName","친구"))\n')
s=s.replace('''			if m.get("roomSlots",[]).size()>room_slots.size():
				room_slots=m.roomSlots
				rebuild_rooms()''','''			if m.get("roomSlots",[])!=room_slots:
				var extended=m.roomSlots.size()>room_slots.size()
				room_slots=m.roomSlots
				if extended:rebuild_rooms()
				else:update_room_names()''')
c.write_text(s,encoding='utf8')
c=p/'tools/v2_functions.txt';s=c.read_text(encoding='utf8').replace('module_nodes.append(label)\n\tvar lamp','label.set_meta("room_index",index)\n\tlabel.text=room_slots[index].label\n\tmodule_nodes.append(label)\n\tvar lamp')
s+='''

func set_profile(id:String,value:String):
	if not players.has(id):return
	var clean=value.strip_edges().left(24).replace("\\n"," ").replace("<","").replace(">","")
	if clean.is_empty():clean="친구"
	players[id].nickname=clean
	var index=int(member_slots.get(id,-1))
	if index>=0 and index<room_slots.size():room_slots[index].label=clean+"의 작업실";update_room_names();revision+=1

func update_room_names():
	for node in module_nodes:
		if node is Label3D and node.has_meta("room_index"):
			var index=int(node.get_meta("room_index"))
			if index<room_slots.size():node.text=room_slots[index].label
'''
c.write_text(s,encoding='utf8')
c=p/'web/bridge.mjs';s=c.read_text(encoding='utf8');s="import {createSocial} from './social.mjs';\n"+s
s=s.replace("function entered(){context", "function entered(){setTimeout(()=>{if(host)push({type:'profile',id,name:social.name()});else net({type:'profile',epoch,name:social.name()})},350);context")
s=s.replace("if(m.type.startsWith('asset-')", "if(m.type==='profile'){if(host&&m.epoch===epoch&&typeof m.name==='string'&&m.name.length<=24)push({type:'profile',id:c.peer,name:m.name});return}\n  if(m.type==='chat'){if(m.epoch===epoch)social.receive(c.peer,m);return}\n  if(m.type.startsWith('asset-')",1)
s=s.replace('is_playing(){return playing}','is_playing(){return playing}').replace('pen_color:()=>',"look_sensitivity:()=>Number($('sensitivity').value)/10000,pen_color:()=>")
s+='''
const social=createSocial({send(m,to,sender){if(to==='relay'){for(const[who,c]of connections)if(who===sender||voiceScope(sender,who))sendRaw(c,{...m,epoch})}else net({...m,epoch})},isHost:()=>host,id:()=>id,scope:voiceScope,pause(){playing=false;ptt=false;gateVoice();document.exitPointerLock?.()},resume,notify:status,profile(name,who=id){if(name!==null)return;return currentState?.players.find(p=>p.id===who)?.displayName||'친구'}});
const preferences=document.createElement('div');preferences.innerHTML='<hr><h3>시점 · 조작</h3><label>마우스 감도 <input id="sensitivity" type="range" min="5" max="50" value="20"></label><p class="fine">카메라 흔들림과 강제 FOV 변화는 사용하지 않습니다. WASD 이동 · Shift 달리기 · C 웅크리기 · Space 점프 · E 사용 · F 읽기/축구 차기 · R 재장전/드리블 · Z 눕기/먹기 · B 가구 설치 · G 가구 이동 · Delete 가구 철거. Esc로 포인터락을 해제합니다.</p>';$('menu').querySelector('.panel').append(preferences);
'''
c.write_text(s,encoding='utf8')
c=p/'web/homeoffice.css';s=c.read_text(encoding='utf8')+'''\n#textChat{position:fixed;z-index:80;left:24px;bottom:30px;width:min(520px,90vw);padding:22px;background:#f5f0e8;color:#203b33;border-radius:18px;box-shadow:0 15px 60px #0008}#chatLines{height:190px;overflow:auto;text-align:left}#chatForm{display:flex;gap:10px}#chatText{flex:1}#displayName{max-width:210px;margin:8px}\n''';c.write_text(s,encoding='utf8')
print('Shared participant names, persistent room labels, scoped Korean text chat and camera sensitivity added')
