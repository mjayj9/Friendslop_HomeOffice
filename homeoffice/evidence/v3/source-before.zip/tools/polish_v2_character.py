from pathlib import Path
R=Path(__file__).resolve().parents[1]
p=R/'tools/v2_functions.txt';s=p.read_text(encoding='utf8').replace('Vector3(.9,0,0)]','Vector3(0,0,.95),Vector3(.9,0,0),Vector3(-.9,0,0)]');p.write_text(s,encoding='utf8')
p=R/'scripts/v2/avatar.gd';s=p.read_text(encoding='utf8').replace('var posture="standing"','var lying:Node3D\nvar hands:Node3D\nvar hand_skeleton:Skeleton3D\nvar posture="standing"')
s=s.replace('\tcommand.crouch=false','''\tcommand.crouch=false
\tlying=load("res://assets/characters/male-lying.glb").instantiate()
\tadd_child(lying)
\tlying.visible=false
\thands=load("res://assets/characters/male-arms.glb").instantiate()
\thands.rotation.y=PI
\tadd_child(hands)
\thand_skeleton=find_skeleton(hands)
\thands.visible=false''')
s=s.replace('\tstanding.rotation.x=0','\tlying.visible=not local_player and posture in ["lying","sleeping"]\n\thands.visible=local_player and holding!="" and not posture in ["lying","sleeping"]\n\tif hands.visible and hand_skeleton:\n\t\tfor side in ["L","R"]:\n\t\t\tvar upper=hand_skeleton.find_bone("UpperArm."+side)\n\t\t\tvar fore=hand_skeleton.find_bone("Forearm."+side)\n\t\t\tif upper>=0:hand_skeleton.set_bone_pose_rotation(upper,Quaternion(Vector3.RIGHT,-1.12))\n\t\t\tif fore>=0:hand_skeleton.set_bone_pose_rotation(fore,Quaternion(Vector3.RIGHT,-.40))\n\tstanding.rotation.x=0')
s=s.replace('\t\tstanding.visible=not local_player\n\t\tsitting.visible=false\n\t\tstanding.rotation.x=PI/2\n\t\tstanding.position=Vector3(0,.74,.65)','\t\tstanding.visible=false\n\t\tsitting.visible=false')
p.write_text(s,encoding='utf8')
print('Safe chair exit alternatives and original-male first-person arms/bed pose connected')
