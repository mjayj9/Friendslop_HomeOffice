from pathlib import Path
p=Path(__file__).resolve().parents[1]
b=p/'web/bridge.mjs';s=b.read_text(encoding='utf8')
start=s.index("$('restore').onclick=");end=s.index('\nfunction observeState',start)
s=s[:start]+'''let restoreBackup=null;
$('restore').onclick=async()=>{if(!pendingWorld||!host||connections.size||restoreBackup)return;const candidate=pendingWorld,files=pendingAttachments;$('restore').disabled=true;try{await new Promise((resolve,reject)=>{restoreBackup={resolve,reject};push({type:'export'})});collaboration.restore(candidate.collaboration);presentation.restore(candidate.presentation,files);arcade.restore({records:candidate.results.arcade||[]});push({type:'restore',world:candidate});pendingWorld=null;$('importPreview').hidden=true;resume();status('공간을 복원했습니다. 좌석·손 점유와 옛 권한은 초기화했습니다.')}catch(e){status('현재 세계를 보존했습니다: '+e.message)}finally{restoreBackup=null;$('restore').disabled=false}};
'''+s[end:]
old="download(await encodeWorld(world,presentation.attachments),'모여집.homeworld')}catch(e){status('내보내기 실패: '+e.message)}"
new="download(await encodeWorld(world,presentation.attachments),'모여집.homeworld');restoreBackup?.resolve()}catch(e){restoreBackup?.reject(e);status('내보내기 실패: '+e.message)}"
assert old in s;s=s.replace(old,new)
b.write_text(s,encoding='utf8')
b=p/'web/local-stt.mjs';s=b.read_text(encoding='utf8')
s=s.replace("notify('로컬 인식 런타임 오류: '+e.message);busy=false", "notify('로컬 인식 런타임 오류: '+e.message);busy=false;ready=false;worker?.terminate();worker=null")
s=s.replace("if(m.type==='error'){busy=false;notify('로컬 인식 실패: '+m.error)}", "if(m.type==='error'){busy=false;if(!ready){worker?.terminate();worker=null}notify('로컬 인식 실패: '+m.error)}")
b.write_text(s,encoding='utf8')
(p/'tools/build.ps1').write_text('''param([string]$Godot = "$PSScriptRoot/../.runtime/godot/Godot_v4.6.1-stable_win64_console.exe")
$ErrorActionPreference = 'Stop'
$projectRoot = (Resolve-Path -LiteralPath "$PSScriptRoot/..").Path
$version = & $Godot --version
if ($version -notmatch '^4\\.6\\.1\\.stable') { throw "Expected Godot 4.6.1 stable, received $version" }
New-Item -ItemType Directory -Path "$projectRoot/build" -Force | Out-Null
& $Godot --headless --path $projectRoot --editor --import --quit
if ($LASTEXITCODE -ne 0) { throw 'Godot import failed' }
& $Godot --headless --path $projectRoot --export-release Web "$projectRoot/build/index.html"
if ($LASTEXITCODE -ne 0) { throw 'Godot export failed' }
Get-ChildItem -LiteralPath "$projectRoot/web" -File | Where-Object { $_.Extension -in '.mjs','.css' -or $_.Name -eq 'peerjs.min.js' -or $_.Name -like '*.LEGAL.txt' } | Copy-Item -Destination "$projectRoot/build"
Copy-Item -LiteralPath "$projectRoot/web/onnx" -Destination "$projectRoot/build" -Recurse -Force
New-Item -ItemType File -Path "$projectRoot/build/.nojekyll" -Force | Out-Null
Get-ChildItem -LiteralPath "$projectRoot/build" -File | Select-Object Name,Length
''',encoding='utf8-sig')
print('Import backup now completes before replacing documents; STT load can retry; build script pinned and copies optional runtime.')
