from pathlib import Path
R=Path(__file__).resolve().parents[1]
p=R/'tools/v2_functions.txt';p.write_text(p.read_text(encoding='utf8').replace('key_event(event,"right")ELETE','key_event(event,"remove")'),encoding='utf8')
p=R/'web/bridge.mjs';s=p.read_text(encoding='utf8');start=s.index(' hint(s){');end=s.index('\n',start);s=s[:start]+" hint(s){$('interaction').textContent=keyBindings.hint(s)},"+s[end:];p.write_text(s,encoding='utf8')
print('Fixed physical Delete matching and configured key hints')
