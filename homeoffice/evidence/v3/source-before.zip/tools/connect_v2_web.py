from pathlib import Path
R=Path(__file__).resolve().parents[1];p=R/'web/bridge.mjs';s=p.read_text(encoding='utf8')
s="import {createCollaboration} from './collaboration.mjs';\nimport {createActivities} from './activities.mjs';\nimport {createCaptions} from './captions.mjs';\n"+s
s=s.replace("let activePeers=new Set()", "const collabAllowed=new Set();\nlet voiceMode='near',voiceMax=24,broadcastAllowed=new Set(),voiceModes={};\nlet activePeers=new Set()")
needle='function status(s)'
prefix="""const collaboration=createCollaboration({send:m=>{if(id)net({...m,epoch})},notify:s=>status(s),identity:()=>id});
const activities=createActivities({action:(action,data)=>push({type:'action',action,data}),close:resume,identity:()=>id,send:m=>{if(id)net({...m,epoch})},notify:s=>status(s)});
const captions=createCaptions({send:m=>{if(host)relayCaption(id,m);else net({...m,epoch})},canTransmit:()=>transmitting(),identity:()=>id,notify:s=>status(s)});
function canCollaborate(who){const a=currentState?.players.find(p=>p.id===who);return !!a&&(a.zone==='meeting'||a.zone==='resources'||a.zone==='free'||a.zone==='dining'||a.zone==='living'||a.zone==='reading'||a.zone?.startsWith('office-'))}
function voiceScope(sender,receiver){const a=currentState?.players.find(p=>p.id===sender),b=currentState?.players.find(p=>p.id===receiver);if(!a||!b)return false;const mode=sender===id?voiceMode:(voiceModes[sender]||'near');if(mode==='session'&&broadcastAllowed.has(sender))return true;if(mode==='zone')return a.zone===b.zone;return Math.hypot(...a.p.map((v,i)=>v-b.p[i]))<Math.min(voiceMax,sender===id?range:(rangeByPeer[sender]||8))}
function relayCaption(sender,m){if(m.epoch&&m.epoch!==epoch||typeof m.text!=='string'||m.text.length>400||!Number.isSafeInteger(m.sequence)||typeof m.utterance!=='string'||m.utterance.length>80)return;const out={type:'caption',epoch,speaker:sender,text:m.text,sequence:m.sequence,utterance:m.utterance,final:!!m.final};if(sender!==id&&voiceScope(sender,id))captions.show(out);for(const[who,c]of connections)if(who!==sender&&voiceScope(sender,who))sendRaw(c,out)}
"""
s=s.replace(needle,prefix+needle)
s=s.replace("if(host)push({type:'join',id:c.peer});", "if(host){push({type:'join',id:c.peer});setTimeout(()=>sendRaw(c,{type:'collab-sync',epoch,...collaboration.snapshot()}),800)}")
needle="  if(host&&m.type==='voice-settings')"
start=s.index(needle);end=s.index("  if(!host&&['welcome'",start)
s=s[:start]+"""  if(m.type.startsWith('collab')){if(m.epoch!==epoch)return;if(host&&!canCollaborate(c.peer))return;if(collaboration.receive(m)&&host)net({type:'collab',epoch,update:m.update});return}
  if(m.type==='caption'){if(m.epoch!==epoch)return;if(host)relayCaption(c.peer,m);else if(voiceScope(m.speaker,id))captions.show(m);return}
  if(m.type==='arcade-progress'||m.type==='arcade-result'){if(m.epoch!==epoch)return;if(host){const a=currentState?.players.find(p=>p.id===c.peer);if(a?.zone==='arcade'&&Number.isFinite(m.score)&&m.score>=0&&m.score<1e7)net({...m,speaker:c.peer})}else if(m.type==='arcade-result')status('친구 아케이드 결과 · '+m.score+'점');return}
  if(host&&m.type==='voice-settings'){if(typeof m.range==='number'&&Number.isFinite(m.range))rangeByPeer[c.peer]=Math.min(voiceMax,Math.max(2,m.range));if(['near','zone','session'].includes(m.mode))voiceModes[c.peer]=m.mode;return}
  if(!host&&m.type==='voice-ranges'){rangeByPeer=m.ranges;voiceModes=m.modes||{};voiceMax=m.max||24;broadcastAllowed=new Set(m.broadcast||[]);return}
"""+s[end:]
s=s.replace("function resume(){menuVisible", "function resume(){collaboration.hide();activities.hide();menuVisible")
start=s.index('function openTool(mode)');end=s.index('const pages=',start)
s=s[:start]+"""function openTool(mode){playing=false;ptt=false;gateVoice();document.exitPointerLock?.();$('tool').hidden=false;collaboration.hide();activities.hide();$('book').hidden=mode!=='book';$('whiteboard').hidden=mode!=='board';$('boardTools').hidden=mode!=='board';$('toolTitle').textContent=({book:'잠깐, 책 한 권',board:'함께 그리는 보드',report:'함께 만드는 회의',catalog:'가구 놓기',runner:'작은 공룡 달리기',maze:'정원 미로'})[mode]||'함께 만드는 회의';if(mode==='book')renderPage();else if(mode==='board')renderBoard();else if(['catalog','runner','maze'].includes(mode))activities.open(mode);else collaboration.open(mode)}
"""+s[end:]
s=s.replace('const max=outbound?range:(rangeByPeer[who]||8);', "const mode=outbound?voiceMode:(voiceModes[who]||'near');if(mode==='session'&&broadcastAllowed.has(outbound?id:who))return true;if(mode==='zone')return me.zone===other.zone;const max=Math.min(voiceMax,outbound?range:(rangeByPeer[who]||8));")
s=s.replace("const occluded=(me.p[0]>6)!==(p.p[0]>6)&&!currentState.door", "const occluded=me.zone!==p.zone||Math.abs(me.p[1]-p.p[1])>2")
s=s.replace("Math.max(0,1-d/(rangeByPeer[who]||8))*(occluded?.22:1)", "((voiceModes[who]==='session'&&broadcastAllowed.has(who))||voiceModes[who]==='zone'?1:Math.max(0,1-d/(rangeByPeer[who]||8)))*(voiceModes[who]==='session'?1:(occluded?.22:1))")
s=s.replace("net({type:'voice-settings',range})", "net({type:'voice-settings',range,mode:voiceMode})")
s=s.replace("net({type:'voice-ranges',ranges:rangeByPeer})", "voiceModes[id]=voiceMode;net({type:'voice-ranges',ranges:rangeByPeer,modes:voiceModes,max:voiceMax,broadcast:[...broadcastAllowed]})")
s=s.replace("function stopTransmit(){ptt=false;", "function stopTransmit(){ptt=false;captions.stop();")
s=s.replace("const world=JSON.parse(json);lastWorld=validateWorld(world)", "const world=JSON.parse(json);world.collaboration=collaboration.snapshot();lastWorld=validateWorld(world)")
s=s.replace("push({type:'restore',world:pendingWorld});pendingWorld=null", "collaboration.restore(pendingWorld.collaboration);push({type:'restore',world:pendingWorld});pendingWorld=null")
s=s.replace("send(json,to){let m;try{m=JSON.parse(json)}catch{return}net(m,to)}", "send(json,to){let m;try{m=JSON.parse(json)}catch{return}if(m.world)m.world.collaboration=collaboration.snapshot();net(m,to)}")
s=s.replace("if(!host&&m.type==='welcome'){epoch=m.epoch;", "if(!host&&m.type==='welcome'){epoch=m.epoch;if(m.world.collaboration)collaboration.restore(m.world.collaboration);")
s=s.replace('diagnostics(){return {host,id,epoch,room,playing,loaded,currentState,boardStrokes,','diagnostics(){return {host,id,epoch,room,playing,loaded,currentState,boardStrokes,collaboration:collaboration.diagnostics(),stt:captions.diagnostics(),')
# Host controls are real validated events. No client role bit is used as authority.
s += """
const controls=document.createElement('div');controls.innerHTML='<hr><h3>방장 · 대화 설정</h3><label>내 음성 범위 <select id="voiceMode"><option value="near">근거리</option><option value="zone">현재 물리적 방 전체</option><option value="session">세션 전체 방송 (승인 필요)</option></select></label><div id="hostControls"><label>발화 상한 <input id="voiceMax" type="number" min="2" max="24" value="24"></label><button id="toggleGameGate">게임방 문 승인 / 잠금</button><div id="memberPermissions"></div><button id="exportEnd">공간 내보내고 세션 종료</button></div>';$('menu').querySelector('.panel').append(controls);
$('voiceMode').onchange=()=>{voiceMode=$('voiceMode').value;voiceModes[id]=voiceMode;if(!host)net({type:'voice-settings',range,mode:voiceMode});gateVoice()};
$('voiceMax').onchange=()=>{if(host)voiceMax=Math.max(2,Math.min(24,+$('voiceMax').value))};
$('toggleGameGate').onclick=()=>{if(host)push({type:'action',action:'game_gate',data:{open:!currentState?.doors?.['game-gate']}})};
let permissionSignature='';setInterval(()=>{$('hostControls').hidden=!host;if(!host)return;const signature=JSON.stringify(currentState?.players.map(p=>p.id)||[]);if(signature===permissionSignature)return;permissionSignature=signature;$('memberPermissions').replaceChildren();for(const p of currentState?.players||[]){const row=document.createElement('div');row.className='row';const name=document.createElement('span');name.textContent=p.id===id?'나 (방장)':p.id.slice(-6);const weapon=document.createElement('button');weapon.textContent='무기 허가 / 회수';weapon.onclick=()=>push({type:'action',action:'grant',data:{peer:p.id,allow:!currentState?.grants?.[p.id]}});const broadcast=document.createElement('button');broadcast.textContent='전체 방송 허가 / 회수';broadcast.onclick=()=>{broadcastAllowed.has(p.id)?broadcastAllowed.delete(p.id):broadcastAllowed.add(p.id);status('전체 방송 권한을 변경했습니다')};row.append(name,weapon,broadcast);$('memberPermissions').append(row)}},500);
$('exportEnd').onclick=()=>{if(!host)return;push({type:'export'});status('파일 다운로드 후 세션 종료를 선택하세요. 파일 보관을 확인해야 합니다.');const b=document.createElement('button');b.textContent='다운로드한 파일 확인 · 세션 연결 종료';b.onclick=()=>{stopTransmit();for(const c of connections.values())c.close();peer?.destroy();peer=null;playing=false;b.remove();status('세션 연결을 종료했습니다. 브라우저는 그대로 열려 있습니다.')};$('hostControls').append(b)};
"""
p.write_text(s,encoding='utf8')
p=R/'web/shell.html';s=p.read_text(encoding='utf8').replace('href="homeoffice.css"','href="homeoffice.css"><link rel="stylesheet" href="quill.css"');p.write_text(s,encoding='utf8')
p=R/'web/homeoffice.css';s=p.read_text(encoding='utf8');s+='''\n#collaboration{color:#273d34;background:#f4f1e7;padding:12px;border-radius:12px}.tabs{display:flex;gap:8px;margin-bottom:14px}.tabs button{padding:9px 14px}.ql-toolbar{background:#e3e9dc}.ql-container{height:320px;background:white;color:#213c30;font-size:17px}.ql-editor{min-height:280px}#cardsPane #cardSpace{position:relative;height:540px;overflow:auto;background:#e6e8dc}.idea-card{position:absolute;width:185px;min-height:112px;padding:8px;box-shadow:0 3px 10px #0002;color:#273d34}.idea-card textarea{width:100%;height:55px;background:transparent;color:#273d34;border:0;padding:4px;font:15px inherit}.idea-card button{padding:4px 8px;margin:3px;font-size:12px}.card-handle{cursor:grab;font-size:12px}.mindlines{position:absolute;width:100%;height:100%;pointer-events:none}#meetingPane textarea{display:block;width:96%;background:white;color:#263e32;margin:8px 0}#activities canvas{max-width:100%;max-height:60vh}.catalog-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}.tool-panel{max-height:93vh;overflow:auto}#captions{position:fixed;bottom:75px;left:20%;width:60%;pointer-events:none;text-align:center;color:white;z-index:9}#captions>div{background:#13231de8;border-radius:5px;margin:5px;padding:8px 14px}#captions .interim{opacity:.72}#menu .panel{max-height:90vh;overflow:auto}\n''';p.write_text(s,encoding='utf8')
p=R/'scripts/v2/avatar.gd';s=p.read_text(encoding='utf8').replace('\tsuper.simulate(dt)\n', '''\tvar before=global_position
\tvar was_floor=is_on_floor()
\tsuper.simulate(dt)
\tvar desired=Vector3(velocity.x,0,velocity.z)*dt
\tif was_floor and desired.length()>.001 and Vector2(position.x-before.x,position.z-before.z).length()<desired.length()*.7:
\t\tvar up=Vector3.UP*.25
\t\tvar raised=global_transform
\t\traised.origin=before
\t\tif not test_move(raised,up):
\t\t\traised.origin+=up
\t\t\tif not test_move(raised,desired*2):
\t\t\t\traised.origin+=desired*2
\t\t\t\tvar landing=KinematicCollision3D.new()
\t\t\t\tif test_move(raised,-Vector3.UP*.28,landing) and landing.get_normal().y>.70:
\t\t\t\t\tglobal_position=raised.origin+landing.get_travel()
''');p.write_text(s,encoding='utf8')
print('Connected real collaboration, two arcade games, voice scopes, optional Korean STT and safe step-up')
