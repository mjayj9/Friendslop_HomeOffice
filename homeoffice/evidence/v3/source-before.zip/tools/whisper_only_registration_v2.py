from pathlib import Path
p=Path(__file__).resolve().parents[1]
f=p/'tools/bundle_stt.mjs';s=f.read_text(encoding='utf8');needle="await fs.mkdir(path.join(root,'web/onnx')"
at=s.index(needle)
s=s[:at]+'''// This worker only runs the pinned Whisper ASR model. It does not offer image/text generation.
// Drop the unused mistral3 auto-model registration. GitHub correctly remains enabled; the
// upstream 32-character public class name in this entry triggered its generic API-key pattern.
const workerFile=path.join(root,'web/stt-worker.mjs');
const output=await fs.readFile(workerFile,'utf8');
await fs.writeFile(workerFile,output.replace(/\\["mistral3",\\s*"[^"]+"\\],?/g,''));
'''+s[at:];f.write_text(s,encoding='utf8')
f=p/'docs/v2/push-protection-review.md';s=f.read_text(encoding='utf8');s+='''
줄 구분 후 재시도에서도 동일 오류가 발생했고 GitHub가 지목한 정확한 30918행은 `mistral3`의 공개 시각 모델 클래스 등록이었다. 이 게임은 해당 시각 모델을 사용하지 않으므로 재현 가능한 번들 스크립트에서 그 사용하지 않는 등록 항목을 제거했다. 비밀 문자열을 분할/인코딩한 것이 아니며 사용 가능한 Whisper ASR 경로는 유지했다. 저장소 보호를 해제하거나 탐지 허용 링크를 사용하지 않았다.
''';f.write_text(s,encoding='utf8')
