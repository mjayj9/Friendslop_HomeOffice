from pathlib import Path
R=Path(__file__).resolve().parents[1]
p=R/'tools/design_v2.py';s=p.read_text(encoding='utf8').replace("gap(5,5,1,1.7,'window')","gap(5,2.2)").replace('gap(19,3)])','gap(22.5,2.2)])').replace("doors=[dict(id='front-door'","doors=[dict(id='terrace-door',p=[-11.1,0,12],yaw=0,width=2.2,open=True,secure=False),dict(id='front-door'").replace('spawn=[-1.8,0,10.6]','spawn=[-.4,0,11.0]');p.write_text(s,encoding='utf8')
p=R/'art/build_v2.py';s=p.read_text(encoding='utf8').replace('radius=.24\n for i in range(24)','radius=.43\n for i in range(24)')
s=s.replace("rail([-4.96,5.5]", "rail([-4.96,5.5]")
# A solid sloping underside below each flight, leaving the treads/risers legible.
needle="rectslab([-4.9,5.7,-1.5,7.2],1.8,'oak',True,.18)"
added="""for side in range(2):
 xc=-4.15+side*1.8;za,zb=(10.2,7.2) if side==0 else (7.2,10.2);y0=side*1.8;y1=(side+1)*1.8
 poly('walnut',[(xc+dx,yy,zz) for zz,yy in [(za,y0-.10),(zb,y1-.10)] for dx in [-.74,.74] for yy in [yy-.14,yy]],[(0,4,5,1),(2,3,7,6),(0,2,6,4),(1,5,7,3),(0,1,3,2),(4,6,7,5)])
for z in [-8,-2,4,10]:
 box('hall beam',[-1.8,3.15,z],[6.4,.18,.14],'oak')
 cyl('hall light',[-.05,2.9,z],.20,.09,'white')
"""
s=s.replace(needle,added+needle);p.write_text(s,encoding='utf8')
print('Fixed terrace access, stair/living clearance, stair underside and playable hoop radius')
