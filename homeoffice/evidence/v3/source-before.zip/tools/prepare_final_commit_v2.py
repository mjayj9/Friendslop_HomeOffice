from pathlib import Path
import subprocess,json,hashlib
R=Path(__file__).resolve().parents[1];repo=R.parent/'deployment/Friendslop_HomeOffice'
# Keep exact tracked source when only newline normalization changed it.
changed=subprocess.check_output(['git','diff','--name-only','-z'],cwd=repo).decode('utf8').split('\0')
for name in changed:
 f=repo/name
 if not name or not f.is_file() or f.suffix not in ['.md','.json','.mjs','.js','.css','.gd','.txt','.cfg','.godot','.tscn','.log']:continue
 before=subprocess.check_output(['git','show','HEAD:'+name],cwd=repo)
 current=f.read_bytes()
 norm=lambda b:b.replace(b'\r\n',b'\n').rstrip(b'\n')
 if norm(before)==norm(current):f.write_bytes(before)
 else:f.write_bytes(current.replace(b'\r\n',b'\n').rstrip(b'\n')+b'\n')
p=repo/'README.md';s=p.read_text(encoding='utf8').replace('같은 PC의 8개 브라우저에서 호스트 6~7fps로 성능 목표에 못 미쳤습니다.','같은 PC의 8개 브라우저에서 이전 기본 설정 6~7fps, 최신 저사양 설정 12~14fps로 성능 목표에 못 미쳤습니다.');p.write_text(s,encoding='utf8',newline='\n')
# Trim extra generated export blank line without changing configuration.
p=repo/'homeoffice/export_presets.cfg';p.write_bytes(p.read_bytes().replace(b'\r\n',b'\n').rstrip()+b'\n')
out=repo/'docs';files=[{'file':f.relative_to(out).as_posix(),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}for f in out.rglob('*')if f.is_file()]
v={'version':'0.2.0-dev','engine':'4.6.1.stable.official.14d19694e','sourceBranch':'codex/godot-homeoffice-v2','initialGameWeightsExcluded':True,'totalHostedBytes':sum(x['bytes']for x in files),'files':files}
for p in [R/'docs/v2/web-build-manifest.json',repo/'homeoffice/docs/v2/web-build-manifest.json']:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8',newline='\n')
print('Final public snapshot: synthetic local corpus excluded; meaningful diffs preserved')
