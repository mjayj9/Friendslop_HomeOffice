from pathlib import Path
p=Path(__file__).resolve().parents[1]
c=p/'web/bridge.mjs';s=c.read_text(encoding='utf8').replace("['state','voice-ranges','arcade-progress'].includes(m.type)","['input','state','voice-ranges','arcade-progress'].includes(m.type)")
c.write_text(s,encoding='utf8')
print('Latest input sent without waiting behind document/file queues')
