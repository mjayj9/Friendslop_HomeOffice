from pathlib import Path
import hashlib,json
p=Path(__file__).resolve().parents[1];repo=p.parent/'deployment/Friendslop_HomeOffice'
(repo/'.gitattributes').write_text('* text=auto eol=lf\n*.glb binary\n*.blend binary\n*.pck binary\n*.wasm binary\n*.png binary\n*.jpg binary\n*.ttf binary\n*.homeworld binary\n*.webm binary\n*.wav binary\n',newline='\n')
for f in repo.rglob('*'):
 if f.is_file() and '.git' not in f.parts and f.suffix in ['.md','.txt','.gd','.uid','.tscn','.godot','.cfg','.py','.ps1','.js','.mjs','.css','.html','.json','.svg','.yml','.log','.import']:
  b=f.read_bytes();f.write_bytes(b.replace(b'\r\n',b'\n'))
out=repo/'docs';rows=[{'file':str(f.relative_to(out)).replace('\\','/'),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}for f in out.rglob('*')if f.is_file()]
report={'version':'0.2.0-dev','engine':'4.6.1.stable.official.14d19694e','sourceBranch':'codex/godot-homeoffice-v2','initialGameWeightsExcluded':True,'totalHostedBytes':sum(f['bytes']for f in rows),'files':rows}
for f in [p/'docs/v2/web-build-manifest.json',repo/'homeoffice/docs/v2/web-build-manifest.json']:f.write_text(json.dumps(report,indent=2)+'\n',newline='\n')
print('Public tree normalized to LF; SHA256 manifest updated. Hosted bytes:',report['totalHostedBytes'])
