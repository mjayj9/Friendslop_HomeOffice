from pathlib import Path
p=Path(__file__).resolve().parents[1];f=p/'web/bridge.mjs';s=f.read_text(encoding='utf8')
s=s.replace("performance_sample:json=>{perfSample=JSON.parse(json)},ready(){loaded=true;", "performance_sample:json=>{perfSample=JSON.parse(json)},ready(){try{const gl=$('canvas').getContext('webgl2'),ext=gl?.getExtension('WEBGL_debug_renderer_info'),renderer=ext?gl.getParameter(ext.UNMASKED_RENDERER_WEBGL):'',saved=localStorage.getItem('moyeo-graphics');$('graphicsQuality').value=['balanced','low'].includes(saved)?saved:(/Intel|SwiftShader|llvmpipe/i.test(renderer)?'low':'balanced')}catch{}loaded=true;")
s=s.replace("performance:perfSample,host,id", "performance:perfSample,graphicsQuality:$('graphicsQuality').value,host,id")
s+="\n$('graphicsQuality').onchange=()=>{try{localStorage.setItem('moyeo-graphics',$('graphicsQuality').value)}catch{}};\n"
f.write_text(s,encoding='utf8')
