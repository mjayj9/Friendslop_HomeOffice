from pathlib import Path
p=Path(__file__).resolve().parents[1]
f=p/'tools/v2_base.txt';s=f.read_text(encoding='utf8');old='\t\tif definitions[p.holding].kind=="basketball" and p.get_meta("dribble",false):grip.y=p.position.y+.28+absf(sin(Time.get_ticks_msec()*.009))*.80'
new='''		if definitions[p.holding].kind=="basketball" and p.get_meta("dribble",false):
			# Jolt gravity and restitution produce the bounce. The hand only pushes downward at its reachable height.
			o.gravity_scale=1
			var offset=grip-o.position;offset.y=0
			if offset.length()>1.8 or zone_at(p.position)!="basketball":release(p,false);continue
			o.apply_central_force((offset*30-Vector3(o.linear_velocity.x,0,o.linear_velocity.z)*8).limit_length(20)*o.mass)
			if o.position.y-p.position.y>.78 and o.linear_velocity.y>0:o.apply_central_impulse(Vector3.DOWN*(o.linear_velocity.y+5.5)*o.mass)
			o.linear_velocity=o.linear_velocity.limit_length(8)
			o.sleeping=false
			continue'''
assert old in s;s=s.replace(old,new)
s=s.replace('\to.set_meta("owner","")\n\to.gravity_scale=1','\tp.set_meta("dribble",false)\n\to.set_meta("owner","")\n\to.gravity_scale=1')
f.write_text(s,encoding='utf8')
f=p/'tools/v2_functions.txt';s=f.read_text(encoding='utf8');old='p.set_meta("dribble",not bool(p.get_meta("dribble",false)))'
s=s.replace(old,old+'\n\t\t\t\to.gravity_scale=1 if p.get_meta("dribble",false) else 0\n\t\t\t\tif p.get_meta("dribble",false):o.linear_velocity.y=-5.5')
s=s.replace('p.set_meta("charge_started",Time.get_ticks_msec())','p.set_meta("charge_started",Time.get_ticks_msec())\n\t\t\tif definitions[p.holding].kind=="basketball":p.set_meta("dribble",false);objects[p.holding].gravity_scale=0')
f.write_text(s,encoding='utf8')
print('Basketball dribble now uses Jolt gravity, physical floor restitution and bounded hand impulse')
