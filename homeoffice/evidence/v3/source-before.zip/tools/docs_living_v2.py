from pathlib import Path
import json
R=Path(__file__).resolve().parents[1]
def edit(name,fn):
 p=R/name;p.write_text(fn(p.read_text(encoding='utf8')),encoding='utf8')
edit('README.md',lambda s:s.replace('수납/서랍/조명, 팀 경기 규칙','수납을 포함한 장시간 통합 인수, 팀 경기 규칙').replace('## 내보내고 다시 만나기','Esc 메뉴의 **키 재설정**에서 이동·상호작용·음성·아케이드 키를 바꾸고 기본값으로 복원할 수 있습니다. Esc는 항상 탈출 키입니다.\n\n거실의 수납함/서랍장은 E로 열고, 손에 든 책·마카·접시 등을 E로 넣습니다. 빈손으로 E를 누르면 마지막으로 넣은 물건을 꺼냅니다. R은 열기/닫기입니다. 물건이 들었거나 열린 가구는 이동/철거할 수 없습니다. 스탠드 조명은 E로 켜고 끕니다. 모두 호스트 동기화와 파일 저장에 연결되어 있습니다.\n\n## 내보내고 다시 만나기').replace('`art/male-character-v2.blend`입니다.','`art/male-character-v2.blend`, `art/v2-living-props.blend`입니다.').replace('Blender 원본은','건축을 다시 생성할 때 `python tools/design_v2.py` 다음 `python tools/living_layout_v2.py`를 실행하고, Blender의 `art/build_v2.py` 다음 `art/living_props_v2.py`를 실행합니다. 최종 저장소의 에셋을 사용하는 경우 이 재제작은 필요하지 않습니다.\n\nBlender 원본은'))
edit('docs/v2/required-remaining.md',lambda s:s.replace('수납형 상자·서랍·개별 조명 사용, ','수납형 상자·서랍·개별 조명의 장시간 생활 검수, ').replace('완전한 예측 재적용/원격 소품 보간','완전한 예측 재적용/원격 소품 보간의 지연·손실 시험').replace('사용자 키 재설정 전체 UI가 남았다.','키 재설정 UI와 물리 키 반영·재접속 보존을 구현했다. 모든 브라우저·배열·접근성 조합의 검수가 남았다.'))
edit('docs/architecture.md',lambda s:s.replace('완전한 재적용/원격 소품 보간은 미완료다.','원격 소품의 위치/회전 보간을 적용했다. 완전한 입력 재적용과 지연·손실 인수는 미완료다.')+'\n`key-bindings.mjs`의 로컬 물리 키 설정을 Godot에 전달하며, UI 상태에서 눌렸던 키는 release 전에 재개하지 않는다. `setup_living_prop/use_storage/update_living_props`는 뚜껑·서랍·조명과 수납 사물을 연결한다. 수납된 물건은 같은 ID를 유지한 채 물리 동작을 멈추고, 꺼낼 때 호스트가 소유권과 충돌을 복원한다.\n')
(R/'docs/save-format.md').write_text('''# 공간 파일 V2

`.homeworld`는 압축 없는 ZIP 컨테이너다. `manifest.json`, `world.json`, `attachments/<sha256>`를 담는다. 호스트의 확정된 세계와 Yjs 업데이트, 자료 수신 완료 시점을 모은다. 원음, 동의 없는 전사, 실행 코드, 로그인 토큰은 포함하지 않는다.

- 구조 스키마: [world-v2.schema.json](../schemas/world-v2.schema.json), [manifest-v2.schema.json](../schemas/manifest-v2.schema.json).
- 실행 시 검사: [save-v2.mjs](../web/save-v2.mjs), [presentation-view.mjs](../web/presentation-view.mjs), Yjs 후보 문서 검증과 PDF/이미지 파싱.
- 파일 최대 32MiB, world 물건 256개, 개인실 8개, 보드 512개, 발표 자료 64개/개별 16MiB. 임의 압축 방식이나 경로는 허용하지 않는다.

구조 스키마만으로 가져오기를 승인하지 않는다. 실행 검증은 CRC와 SHA256, ZIP 경로/중복/크기, ID 유일성, 개인실 순서/배정 관계, 허용 에셋, 수치, 발표 자료 참조/실제 바이트를 확인한다. 수납함은 최대 4개, 서랍은 2개이며 책·마카·접시 등 허용 종류만 보관한다. 중복 보관·중첩 가구·존재하지 않는 물건·스포츠 공이나 무기의 수납 우회를 거절한다.

수납 상태는 `objects[].state.contents`의 물건 ID 배열과 `open`에 저장한다. 스탠드의 전원은 `state.on`이다. 물건은 컨테이너 안에서도 원래 ID와 내용/재질 에셋 참조를 유지한다. 꺼내면 host ownership과 물리가 복원된다. 파일에 peer ID나 점유를 기록하여 재사용하지 않는다.

가져오기는 후보 파일/문서/자료 검증 → 포함 내용 미리보기 → 현재 공간 백업 다운로드 → 복원 순서다. 파일 검증 실패가 현재 세계를 교체하지 않는다. 임시 물리 세계에서 모든 가구 배치 충돌을 전수 검사하는 단계는 필수 미완료다. 다른 사용자는 복원한 호스트의 새 초대 코드에 참가한다.
''',encoding='utf8')
(R/'docs/v2/living-props-and-input.md').write_text('''# 수납·조명·입력 보완

BlenderMCP의 실제 연결/씬 조회 뒤 `art/living_props_v2.py`를 실행했다. 기존 Blender 씬/파일을 보존하고 `art/v2-living-props.blend`와 storage/storage_lid/drawer/drawer_slide/floor_lamp GLB를 별도 생성했다. asset manifest의 단순 충돌체와 lid_hinge/drawer_track/handle/interior/switch/bulb anchor는 미터 단위다. 수납함 몸체는 1.24×0.72×0.9m, 서랍장은 0.96×0.86×0.66m, 조명은 약 0.5×1.7×0.5m다.

뚜껑과 서랍은 실제 분리 메시/AnimatableBody3D로 움직인다. 동시 꺼내기는 호스트가 순서대로 판정하여 한 물건이 두 손에 들어가지 않는다. 보관 중 물건은 freeze/충돌 중지되며 열린 용기 안에 실제 모델을 표시한다. 저장/복원은 원래 ID와 내용 참조를 보존한다. 스탠드는 실제 OmniLight와 전원 상태를 연동한다. 서랍의 첫 위치가 소파에 막힌 것을 실제 ray/이동 시험에서 발견하여 거실 남서 모서리로 옮겼다.

`evidence/v2-living-props.json`은 실제 Godot/Jolt의 위치 고정 인수이며 사람 플레이 영상과 구분한다. `storage-save.test.mjs`는 엔진이 내보낸 상태의 컨테이너 왕복과 중복/중첩/금지 참조 거절을 검사한다. 키 재설정과 두 브라우저 실제 점유 시험은 `tests/v2-bindings-ownership.mjs`다. 최종 통과 여부는 해당 evidence JSON을 따른다.

`web/key-bindings.mjs`는 22개 키를 설정하고 중복을 거절하며 기기에 보존한다. Godot는 동일 물리 키 설정으로 이동/상호작용을 실행한다. 메뉴/문서에서 눌린 키는 keyup까지 재사용하지 않고, 아주 빠른 keyup→keydown도 이벤트에서 처리한다. Esc는 항상 취소/메뉴이며 마우스 조준과 클릭은 고정이다. 원격 소품은 호스트 상태의 위치/회전을 보간하며 큰 오차에서 보정한다. 완전한 클라이언트 입력 재적용/고지연 인수는 남았다.
''',encoding='utf8')
p=R/'package.json';v=json.loads(p.read_text(encoding='utf8'));v['scripts']['test']='node --test tests/save-v2.test.mjs tests/storage-save.test.mjs tests/arcade-rules.test.mjs';v['scripts']['test:browser']='cd .. && node homeoffice/tests/v2-browser-walk.mjs';v['scripts']['test:connection']='cd .. && node homeoffice/tests/v2-bindings-ownership.mjs';p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
edit('deployment/github-pages.yml',lambda s:s.replace('name: Godot Homeoffice Pages (manual)','name: Godot Homeoffice V2 Pages (optional manual example)').replace('node --test homeoffice/tests/save.test.mjs','node --test homeoffice/tests/save-v2.test.mjs homeoffice/tests/storage-save.test.mjs homeoffice/tests/arcade-rules.test.mjs').replace('--editor --import\n','--editor --import --quit\n').replace('--script tests/host_physics.gd','--script res://tests/v2-living-props.gd').replace('Web build/index.html','Web "$GITHUB_WORKSPACE/homeoffice/build/index.html"').replace('cp homeoffice/web/*.mjs homeoffice/web/*.css homeoffice/web/peerjs.min.js homeoffice/build/','cp homeoffice/web/*.mjs homeoffice/web/*.css homeoffice/web/peerjs.min.js homeoffice/web/*.LEGAL.txt homeoffice/build/\n          cp -r homeoffice/web/onnx homeoffice/build/'))
print('Korean instructions and remaining work updated to actual new implementation')
