from pathlib import Path
p=Path(__file__).resolve().parents[1]/'scripts/v2/avatar.gd'
s=p.read_text(encoding='utf8').replace('\tcommand.x=original_x','''\tfor i in range(get_slide_collision_count()):
\t\tvar hit=get_slide_collision(i)
\t\tvar body=hit.get_collider()
\t\tif body is RigidBody3D and body.get_meta("owner","")=="":
\t\t\tvar force=-hit.get_normal()
\t\t\tforce.y=0
\t\t\tbody.apply_central_impulse(force.limit_length(1)*minf(body.mass,1.5)*dt*7)
\tcommand.x=original_x''')
p.write_text(s,encoding='utf8')
p=Path(__file__).resolve().parents[1]/'tests/v2-navigation.gd';s=p.read_text(encoding='utf8').replace('[-7,30]','[-7,29]');p.write_text(s,encoding='utf8')
