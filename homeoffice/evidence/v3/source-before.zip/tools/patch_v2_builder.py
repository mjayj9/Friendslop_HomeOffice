from pathlib import Path
p=Path(__file__).resolve().parents[1]/'art/build_v2.py'
s=p.read_text(encoding='utf8').replace("def wall(data):", "def gap(at,width=1.8,sill=0,height=2.5,kind='passage'):return dict(at=at,width=width,sill=sill,height=height,kind=kind)\ndef wall(data):")
p.write_text(s,encoding='utf8')
