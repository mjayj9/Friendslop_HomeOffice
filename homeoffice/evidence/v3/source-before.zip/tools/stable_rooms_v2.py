from pathlib import Path
R=Path(__file__).resolve().parents[1];p=R/'tools/v2_base.txt';s=p.read_text(encoding='utf8').replace('var member_slots={}','var member_slots={}\nvar member_identity={}\nvar room_claims={}\nvar room_fill:StaticBody3D')
s=s.replace('local_id=e.id\n\t\t\tepoch', 'local_id=e.id\n\t\t\tmember_identity[local_id]=String(e.get("clientId",local_id))\n\t\t\tepoch')
s=s.replace('if host:\n\t\t\t\tadd_player(e.id)','if host:\n\t\t\t\tmember_identity[e.id]=String(e.get("clientId",e.id))\n\t\t\t\tadd_player(e.id)')
s=s.replace('member_slots.clear()\n\trebuild_rooms()', 'member_slots.clear()\n\troom_claims.clear()\n\trebuild_rooms()')
p.write_text(s,encoding='utf8')
p=R/'tools/v2_functions.txt';s=p.read_text(encoding='utf8').replace('var index=-1\n\tfor i in range(room_slots.size()):','var client_key=member_identity.get(id,id)\n\tvar index=int(room_claims.get(client_key,-1))\n\tif index in used:index=-1\n\tfor i in range(room_slots.size()):\n\t\tif index>=0:break')
s=s.replace('member_slots[id]=index','member_slots[id]=index\n\troom_claims[client_key]=index')
s=s.replace('\tmodule_nodes.append(label)\n', '''\tmodule_nodes.append(label)
\tvar lamp=OmniLight3D.new()
\tlamp.position=Vector3(x,6.4,z-2.7)
\tlamp.light_color=Color("ffe3b9")
\tlamp.light_energy=.55
\tlamp.omni_range=5.5
\tlamp.distance_fade_enabled=true
\tlamp.distance_fade_begin=12
\tlamp.distance_fade_length=5
\tadd_child(lamp)
\tmodule_nodes.append(lamp)
''')
s=s.replace('func update_room_end():\n', '''func update_room_end():
\tif room_fill:
\t\tremove_child(room_fill);room_fill.queue_free();room_fill=null
\tif room_slots.size()%2==1:
\t\troom_fill=StaticBody3D.new()
\t\troom_fill.position=Vector3(1.4,3.6,-12-floorf(room_slots.size()/2.0)*5.4-2.7)
\t\tcollision(room_fill,Vector3(0,1.3,0),Vector3(.16,2.6,1.65))
\t\tvar panel=MeshInstance3D.new()
\t\tvar shape=BoxMesh.new()
\t\tshape.size=Vector3(.16,2.6,1.65)
\t\tpanel.mesh=shape
\t\tpanel.position.y=1.3
\t\troom_fill.add_child(panel)
\t\tadd_child(room_fill)
''')
p.write_text(s,encoding='utf8')
p=R/'web/bridge.mjs';s=p.read_text(encoding='utf8').replace('const params=new URLSearchParams(location.search);',"const params=new URLSearchParams(location.search);\nlet clientIdentity;try{clientIdentity=localStorage.getItem('moyeo-client-id')||crypto.randomUUID();localStorage.setItem('moyeo-client-id',clientIdentity)}catch{clientIdentity=crypto.randomUUID()}")
s=s.replace("push({type:'join',id:c.peer})", "push({type:'join',id:c.peer,clientId:typeof c.metadata?.clientId==='string'&&c.metadata.clientId.length<80?c.metadata.clientId:c.peer})")
s=s.replace("{type:'start',host:true,id,epoch}", "{type:'start',host:true,id,epoch,clientId:clientIdentity}").replace("{type:'start',host:false,id,epoch:''}", "{type:'start',host:false,id,epoch:'',clientId:clientIdentity}")
s=s.replace("{reliable:true,serialization:'json'}", "{reliable:true,serialization:'json',metadata:{clientId:clientIdentity}}")
p.write_text(s,encoding='utf8')
print('Stable per-session room claims and unbuilt-side corridor closure added')
