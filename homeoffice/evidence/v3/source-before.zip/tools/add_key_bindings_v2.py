from pathlib import Path
R=Path(__file__).resolve().parents[1]
def edit(path,fn):
 p=R/path;p.write_text(fn(p.read_text(encoding='utf8')),encoding='utf8')
def bridge(s):
 s="import {createBindings} from './key-bindings.mjs';\n"+s
 s=s.replace('function isMember(who)',"const keyBindings=createBindings({changed:bindings=>push({type:'bindings',bindings})});\nfunction isMember(who)")
 s=s.replace("e.code==='KeyV'","keyBindings.match(e,'talk')").replace("e.code==='KeyM'&&playing","keyBindings.match(e,'mute')&&playing&&!e.repeat")
 s=s.replace('ready(){try{',"ready(){push({type:'bindings',bindings:keyBindings.godot()});try{")
 s=s.replace('window.Homeoffice={',"window.Homeoffice={\n key_matches:(e,action)=>keyBindings.match(e,action),key_label:action=>keyBindings.label(action),")
 s=s.replace("hint(text){$('interaction').textContent=text}","hint(text){$('interaction').textContent=keyBindings.hint(text)}")
 s=s.replace('diagnostics(){return {presentation:', 'diagnostics(){return {keyBindings:keyBindings.snapshot(),presentation:')
 return s
edit('web/bridge.mjs',bridge)
edit('web/social.mjs',lambda s:s.replace("e.code==='Enter'&&panel.hidden","window.Homeoffice?.key_matches(e,'chat')&&panel.hidden").replace("button.textContent='대화 · Enter'","button.textContent='텍스트 대화'"))
edit('web/arcade.mjs',lambda s:s.replace("const keys={Space:'jump',ArrowUp:mode==='runner'?'jump':'up',ArrowDown:'down',ArrowLeft:'left',ArrowRight:'right'};if(keys[e.code]){e.preventDefault();if(!e.repeat)act(keys[e.code])}","const keys={jump:'jump',look_up:mode==='runner'?'jump':'up',look_down:'down',look_left:'left',look_right:'right'};const action=Object.keys(keys).find(k=>window.Homeoffice?.key_matches(e,k));if(action){e.preventDefault();if(!e.repeat)act(keys[action])}"))
edit('web/homeoffice.css',lambda s:s+'\n.bindings-grid{display:grid;grid-template-columns:1fr 1fr;gap:6px 16px}.bindings-grid label{display:flex;justify-content:space-between;align-items:center;font-size:13px}.bindings-grid button{padding:6px 10px;min-width:75px}#keyBindings{margin-top:18px}#keyBindings summary{cursor:pointer;font-weight:700}\n')
keys={'KEY_W':'forward','KEY_S':'back','KEY_A':'left','KEY_D':'right','KEY_SPACE':'jump','KEY_SHIFT':'run','KEY_C':'crouch','KEY_E':'interact','KEY_Q':'drop','KEY_F':'read','KEY_R':'secondary','KEY_Z':'rest','KEY_B':'build','KEY_G':'move','KEY_DELETE':'remove','KEY_LEFT':'look_left','KEY_RIGHT':'look_right','KEY_UP':'look_up','KEY_DOWN':'look_down'}
def base(s):
 s=s.replace('var sunlight:', 'var key_bindings={'+','.join('"'+v+'":'+k for k,v in keys.items())+'}\nvar blocked_keys={}\nvar last_jump_down=false\nvar sunlight:',1)
 for k,a in keys.items():s=s.replace('Input.is_physical_key_pressed('+k+')','key_down("'+a+'")').replace('event.keycode=='+k+':','key_event(event,"'+a+'"):')
 s=s.replace('(key_down("crouch") or Input.is_physical_key_pressed(KEY_CTRL))','key_down("crouch")')
 s=s.replace('and not p.command.jump','and not last_jump_down')
 s=s.replace('\t\tvar enabled=playing()','\t\tvar enabled=playing()\n\t\tfor code in blocked_keys.keys():\n\t\t\tif not Input.is_physical_key_pressed(code):blocked_keys.erase(code)\n\t\tif not enabled:\n\t\t\tfor code in key_bindings.values():\n\t\t\t\tif Input.is_physical_key_pressed(code):blocked_keys[code]=true')
 s=s.replace('\t\tp.command=cmd','\t\tlast_jump_down=key_down("jump")\n\t\tp.command=cmd')
 s=s.replace('\t\t"resume":Input.mouse_mode=', '\t\t"bindings":\n\t\t\tfor action in key_bindings:\n\t\t\t\tvar code=OS.find_keycode_from_string(String(e.get("bindings",{}).get(action,"")))\n\t\t\t\tif code!=KEY_NONE and code!=KEY_ESCAPE:key_bindings[action]=code\n\t\t"resume":Input.mouse_mode=')
 s+='\nfunc key_down(action:String) -> bool:\n\tvar code=int(key_bindings.get(action,KEY_NONE))\n\treturn not blocked_keys.has(code) and Input.is_physical_key_pressed(code)\n\nfunc key_event(event:InputEventKey,action:String) -> bool:\n\treturn event.physical_keycode==int(key_bindings.get(action,KEY_NONE)) and not blocked_keys.has(event.physical_keycode)\n'
 return s
edit('tools/v2_base.txt',base)
def extension(s):
 for k,a in keys.items():s=s.replace('event.keycode=='+k,'key_event(event,"'+a+'")')
 s=s.replace('event.keycode in [KEY_ESCAPE,KEY_B]','(event.keycode==KEY_ESCAPE or key_event(event,"build"))')
 return s
edit('tools/v2_functions.txt',extension)
print('Rebindable physical keys and UI focus release gate added')
