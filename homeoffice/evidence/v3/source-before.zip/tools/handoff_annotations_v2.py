from pathlib import Path
p=Path(__file__).resolve().parents[1];f=p/'tests/v2-browser-handoff.mjs';s=f.read_text(encoding='utf8')
s=s.replace("pass('New host exports report and byte-complete PDF after transfer');", "assert.deepEqual(roundtrip.world.presentationView,pdf.world.presentationView);pass('New host exports report, byte-complete PDF, current page and annotations after transfer');")
f.write_text(s,encoding='utf8')
