from pathlib import Path
p=Path(__file__).resolve().parents[1]
f=p/'tests/v2-browser-arcade-voice.mjs';s=f.read_text(encoding='utf8');s=s.replace("await a.locator('#voiceMode').selectOption('session');", "await a.locator('#memberPermissions button').filter({hasText:'전체 방송 허가 / 회수'}).first().click({force:true});await a.locator('#voiceMode').selectOption('session');")
f.write_text(s,encoding='utf8')
