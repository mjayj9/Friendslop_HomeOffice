from pathlib import Path
R=Path(__file__).resolve().parents[1]
p=R/'tools/v2_functions.txt';s=p.read_text(encoding='utf8').replace('func _unhandled_input(event):\n','func _unhandled_input(event):\n\tif event is InputEventKey and not event.pressed:\n\t\tblocked_keys.erase(event.physical_keycode)\n\t\tif key_event(event,"jump"):last_jump_down=false\n',1);p.write_text(s,encoding='utf8')
print('Key release event clears UI suppression even between physics ticks')
