from pathlib import Path
import shutil,json,hashlib
p=Path(__file__).resolve().parents[1];repo=p.parent/'deployment/Friendslop_HomeOffice'
assert (repo/'.git').exists()
# Copy only this Godot project, never the old Firebase project or personal archives.
ignore=shutil.ignore_patterns('.godot','.runtime','node_modules','build','releases','.git','*.blend1','*.blend2','__pycache__')
for folder in ['assets','scripts','scenes','web','art','docs','tests']:
 shutil.copytree(p/folder,repo/'homeoffice'/folder,dirs_exist_ok=True,ignore=ignore)
tools=['assemble_v2.py','v2_base.txt','v2_functions.txt','design_v2.py','bundle_stt.mjs','bundle_collaboration.mjs','serve.mjs','build.ps1','synthesize_stt.ps1','report_stt_v2.py']
(repo/'homeoffice/tools').mkdir(parents=True,exist_ok=True)
for f in tools:shutil.copyfile(p/'tools'/f,repo/'homeoffice/tools'/f)
for f in ['project.godot','export_presets.cfg','package.json','package-lock.json','README.md']:
 shutil.copyfile(p/f,repo/'homeoffice'/f)
# Reference instructions remain quoted reference material, not active repo instructions.
ag=repo/'homeoffice/docs/reference-source/AGENTS.md'
if ag.exists():
 target=ag.with_name('AGENTS.reference.txt');shutil.copyfile(ag,target);ag.unlink()
ev=repo/'homeoffice/evidence';ev.mkdir(exist_ok=True)
for f in (p/'evidence').iterdir():
 if f.is_file() and (f.name.startswith('v2-') or f.name=='reference-site.png') and f.suffix in ['.json','.png','.homeworld','.log','.jpg']:
  if any(t in f.name for t in ['failure','before-heartbeat','input-probe','contact-review','review']):continue
  shutil.copyfile(f,ev/f.name)
videos=list((p/'evidence/v2-walk-video').glob('*.webm'))
if videos:
 (ev/'v2-walk-video').mkdir(exist_ok=True);latest=max(videos,key=lambda f:f.stat().st_mtime)
 shutil.copyfile(latest,ev/'v2-walk-video/continuous-game-walk.webm')
out=repo/'docs';out.mkdir(exist_ok=True)
for f in (p/'build').iterdir():
 if f.is_file() and f.name not in ['.gdignore'] and not f.name.endswith('.import'):
  shutil.copyfile(f,out/f.name)
shutil.copytree(p/'build/onnx',out/'onnx',dirs_exist_ok=True)
shutil.copytree(p/'docs/licenses',out/'licenses',dirs_exist_ok=True)
shutil.copyfile(p/'docs/third-party-notices.md',out/'third-party-notices.md')
(out/'.nojekyll').touch()
manifest=[{'file':str(f.relative_to(out)).replace('\\','/'),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}for f in out.rglob('*')if f.is_file()]
report={'version':'0.2.0-dev','engine':'4.6.1.stable.official.14d19694e','sourceBranch':'codex/godot-homeoffice-v2','initialGameWeightsExcluded':True,'totalHostedBytes':sum(f['bytes']for f in manifest),'files':manifest}
for target in [p/'docs/v2/web-build-manifest.json',repo/'homeoffice/docs/v2/web-build-manifest.json']:target.write_text(json.dumps(report,indent=2),encoding='utf8')
(repo/'README.md').write_text('''# Friendslop HomeOffice · 모여집

[웹에서 실행](https://mjayj9.github.io/Friendslop_HomeOffice/) · [한국어 실행·조작 안내](homeoffice/README.md) · [필수 미완료](homeoffice/docs/v2/required-remaining.md)

Godot 4.6.1/GDScript 기반의 2층 집+오피스 멀티플레이 게임입니다. **개발 빌드이며 원문 전체 완료가 아닙니다.** 기존 main을 보존한 `codex/godot-homeoffice-v2` 브랜치입니다.

![실제 Godot 웹 거실](homeoffice/evidence/v2-game-living.png)

독립 브라우저 2/4/8명 연결·개인실, 실제 이동/소품/생활, Yjs 동시 한글 보고서, PDF/레이저/주석, 음성 범위, 아케이드, 파일 복원과 정상 방장 이전을 개발·검증했습니다. 각각의 부분 시험과 남은 필수 작업은 [56개 원문](homeoffice/docs/v2/requirements-traceability.md), [80개 인수 기록](homeoffice/docs/v2/acceptance-80.md)에 구분했습니다.

같은 PC의 8개 브라우저에서 호스트 6~7fps로 성능 목표에 못 미쳤습니다. 실제 사람 마이크/STT·정밀 캐릭터 동작·수납/조명·팀 경기 규칙·전체 통합 인수 등이 남아 있습니다. 캡처는 실제 Godot 웹 화면이며 Blender 프리뷰는 art에 별도 있습니다.

![실제 Godot 웹 외관](homeoffice/evidence/v2-game-exterior.png)

- [연속 보행 영상](homeoffice/evidence/v2-walk-video/continuous-game-walk.webm)
- [층별 도면/공간 프로그램](homeoffice/docs/v2/space-program.md)
- [실제 성능 기록](homeoffice/docs/v2/performance.md)
- [한국어 합성 음성 측정](homeoffice/docs/v2/korean-stt-measurement.md)
- [라이선스 고지](homeoffice/docs/third-party-notices.md)

`homeoffice/`는 실행 가능한 소스·실제 에셋·Blender 원본·브리지·시험, `docs/`는 GitHub Pages용 Godot 웹 export입니다. Firebase·기존 프로젝트·기존 서비스 설정을 변경하지 않았습니다.
''',encoding='utf8')
(repo/'.gitignore').write_text('**/.godot/\n**/.runtime/\n**/node_modules/\n**/build/\n**/__pycache__/\n*.blend1\n*.blend2\n.env\n.env.*\n',encoding='utf8')
print(json.dumps({'copiedFiles':sum(1 for f in repo.rglob('*')if f.is_file() and '.git' not in f.parts),'hostedBytes':report['totalHostedBytes'],'maxFileBytes':max(f['bytes']for f in manifest)},indent=2))
