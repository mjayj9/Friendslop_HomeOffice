from pathlib import Path
p=Path(__file__).resolve().parents[1]
c=p/'web/stt-worker-source.mjs';s=c.read_text(encoding='utf8').replace("revision,dtype:'q8',device:'wasm'", "revision,dtype:'q8',device:'wasm',session_options:{graphOptimizationLevel:'disabled'}")
c.write_text(s,encoding='utf8')
c=p/'web/arcade-rules.mjs';s=c.read_text(encoding='utf8').replace("phase:'rules',score:0", "phase:'rules',recorded:false,score:0");c.write_text(s,encoding='utf8')
c=p/'web/arcade.mjs';s=c.read_text(encoding='utf8').replace('return {open,hide,receive,','return {open,hide,suspend(){root.hidden=true},receive,');c.write_text(s,encoding='utf8')
c=p/'web/bridge.mjs';s=c.read_text(encoding='utf8').replace("pause(){playing=false;stopTransmit();collaboration.hide();activities.hide();presentation.hide();arcade.hide();", "pause(){playing=false;stopTransmit();collaboration.hide();activities.hide();presentation.hide();arcade.suspend();")
c.write_text(s,encoding='utf8')
