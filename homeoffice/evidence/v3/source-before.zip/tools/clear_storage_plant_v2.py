from pathlib import Path
import json
R=Path(__file__).resolve().parents[1]
p=R/'assets/v2/layout.json';d=json.loads(p.read_text(encoding='utf8'));next(x for x in d['furniture'] if x['id']=='living-storage').update(p=[-5.85,0,8.15],yaw=-1.57079632679);p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf8')
p=R/'tools/living_layout_v2.py';s=p.read_text(encoding='utf8').replace("'p': [-5.85, 0, 4.4], 'yaw': 0","'p': [-5.85, 0, 8.15], 'yaw': -1.57079632679");p.write_text(s,encoding='utf8')
p=R/'tests/v2-living-props.gd';s=p.read_text(encoding='utf8').replace('box.position+Vector3(0,0,1.5)','box.global_transform*Vector3(0,0,1.5)').replace('box.position+Vector3(.65,0,1.5)','box.global_transform*Vector3(.65,0,1.5)');p.write_text(s,encoding='utf8')
p=R/'tests/v2-bindings-ownership.mjs';s=p.read_text(encoding='utf8').replace('await wa.move(-5.85,7.9);await wa.move(-5.85,5.95);await wa.aim(-5.85,.52,4.4)','await wa.move(-7.4,8.15);await wa.aim(-5.85,.52,8.15)');p.write_text(s,encoding='utf8')
p=R/'docs/v2/living-props-and-input.md';s=p.read_text(encoding='utf8');s+='\n실제 게임 캡처에서 수납함과 기존 장식 화분의 겹침을 발견해 수납함을 (-5.85, 0, 8.15)로 옮기고 서쪽을 향하도록 회전했다. 기존 화분과 소파는 보존했다. 서랍장은 (-13.6, 0, 10.75)에서 동쪽을 향한다. 구조·문·동선 설계는 유지한다.\n';p.write_text(s,encoding='utf8')
print('Moved chest clear of built-in plant based on actual gameplay screenshot')
