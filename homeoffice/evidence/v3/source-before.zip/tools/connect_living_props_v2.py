from pathlib import Path
import json
R=Path(__file__).resolve().parents[1]
def edit(name,fn):
 p=R/name;p.write_text(fn(p.read_text(encoding='utf8')),encoding='utf8')
def base(s):
 s=s.replace('\tbody.add_child(model(kind))','\tbody.add_child(model(kind))\n\tsetup_living_prop(body,kind)')
 s=s.replace('\tupdate_room_lighting(dt)','\tupdate_living_props(dt)\n\tupdate_room_lighting(dt)')
 # Interpolate remote rigid props, retaining authoritative collision/simulation on host.
 s=s.replace('\t\tif Time.get_ticks_msec()-last_snapshot_ms>2500:', '\t\tfor o in objects.values():\n\t\t\tif o is RigidBody3D and o.has_meta("remote_position") and o.get_meta("stored_in","")=="":\n\t\t\t\tvar goal:Vector3=o.get_meta("remote_position")\n\t\t\t\to.position=goal if o.position.distance_to(goal)>1.6 else o.position.lerp(goal,1-exp(-dt*20))\n\t\t\t\to.quaternion=o.quaternion.slerp(Quaternion.from_euler(o.get_meta("remote_rotation")),1-exp(-dt*20))\n\t\tif Time.get_ticks_msec()-last_snapshot_ms>2500:')
 s=s.replace('\t\t\t\t\tobjects[s.id].position=vec(s.p)\n\t\t\t\t\tobjects[s.id].rotation=vec(s.r)', '\t\t\t\t\tif objects[s.id] is RigidBody3D:\n\t\t\t\t\t\tobjects[s.id].set_meta("remote_position",vec(s.p));objects[s.id].set_meta("remote_rotation",vec(s.r))\n\t\t\t\t\telse:\n\t\t\t\t\t\tobjects[s.id].position=vec(s.p);objects[s.id].rotation=vec(s.r)')
 return s
edit('tools/v2_base.txt',base)
def ext(s):
 s=s.replace('if action=="secondary":\n', 'if action=="secondary":\n\t\tvar focused=target(p).get("id","")\n\t\tif definitions.has(focused) and definitions[focused].kind in ["storage","drawer"]:use_storage(p,focused,true);return\n')
 s=s.replace('\tif kind in ["chair","sofa","bed"]:', '\tif kind in ["storage","drawer"]:use_storage(p,target_id);return\n\tif kind=="floor_lamp":\n\t\tvar st=o.get_meta("state",{});st.on=not st.get("on",true);o.set_meta("state",st);revision+=1;return\n\tif kind in ["chair","sofa","bed"]:',1)
 s=s.replace('"counter":"E 음식 담기"','"counter":"E 음식 담기","storage":"E 열기 / 넣기 / 꺼내기 · R 뚜껑","drawer":"E 열기 / 넣기 / 꺼내기 · R 서랍","floor_lamp":"E 조명 켜기 / 끄기"')
 s=s.replace('"bed","plate"]','"bed","plate","storage","drawer","floor_lamp"]')
 s=s.replace('"plate","gun","shield"]:return','"plate","gun","shield","storage","drawer","floor_lamp"]:return')
 s=s.replace('"bed":Vector3(1.2,1.3,2.15)','"bed":Vector3(1.2,1.3,2.15),"storage":Vector3(1.28,1.65,1.05),"drawer":Vector3(.96,.86,1.10),"floor_lamp":Vector3(.5,1.7,.5)')
 s=s.replace('if object.get_meta("owner","")!="" or', 'if not object.get_meta("state",{}).get("contents",[]).is_empty() or object.get_meta("state",{}).get("open",false):return true\n\tif object.get_meta("stored_in","")!="":return true\n\tif object.get_meta("owner","")!="" or')
 # Nested floor lamps require global coordinates, unlike previous root room lights.
 s=s.replace('a.position.distance_squared_to(eye)<b.position.distance_squared_to(eye)','a.global_position.distance_squared_to(eye)<b.global_position.distance_squared_to(eye)')
 s=s.replace('light.position.distance_to(eye)<16','light.global_position.distance_to(eye)<16\n\t\tvar furniture=String(light.get_meta("furniture",""))\n\t\tif objects.has(furniture):active=active and objects[furniture].get_meta("state",{}).get("on",true)')
 s+='\n'+(R/'tools/living_functions_v2.txt').read_text(encoding='utf8')
 return s
edit('tools/v2_functions.txt',ext)
edit('web/activities.mjs',lambda s:s.replace("plate:'접시'","plate:'접시',storage:'수납함',drawer:'서랍장',floor_lamp:'스탠드 조명'"))
edit('web/save-v2.mjs',lambda s:s.replace("'gun','shield','arcade'","'gun','shield','arcade','storage','drawer','floor_lamp'").replace("'open','contents'","'open','on','contents'").replace("'ready','open'","'ready','open','on'").replace("return structuredClone(w);",'''const contained=new Set();for(const o of w.objects){const contents=o.state.contents||[];if(contents.length&&!['storage','drawer'].includes(o.kind))bad('수납 사물이 아닙니다');if(contents.length>(o.kind==='drawer'?2:4))bad('수납 용량 초과');for(const id of contents){const item=w.objects.find(i=>i.id===id);const allowed=o.kind==='storage'?['book','marker','crate','plate','pan','ingredient','meal']:['book','marker','plate','ingredient','meal'];if(contained.has(id)||!allowed.includes(item.kind))bad('중복 또는 허용하지 않는 수납 참조');contained.add(id)}}
 return structuredClone(w);'''))
p=R/'assets/v2/layout.json';layout=json.loads(p.read_text(encoding='utf8'))
furniture=layout['furniture']
for d in [{'id':'living-storage','kind':'storage','p':[-5.85,0,4.4],'yaw':0,'state':{'open':False,'contents':[]}},{'id':'living-drawer','kind':'drawer','p':[-5.7,0,6.35],'yaw':1.57079632679,'state':{'open':False,'contents':[]}},{'id':'living-lamp','kind':'floor_lamp','p':[-13.7,0,4.15],'yaw':0,'state':{'on':True}}]:
 furniture.append(d)
p.write_text(json.dumps(layout,ensure_ascii=False,indent=2),encoding='utf8')
print('Connected storage, drawer, lamp, persistence and remote prop smoothing')
