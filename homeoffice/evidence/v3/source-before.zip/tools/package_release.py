from pathlib import Path
import zipfile,json,hashlib
base=Path(__file__).resolve().parents[1]
out=base/'releases';out.mkdir(exist_ok=True)
def archive(name,files,relative):
 p=out/name
 with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for f in files:z.write(f,f.relative_to(relative))
 return {'file':name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
web=[p for p in (base/'build').iterdir() if p.is_file() and p.suffix!='.import' and p.name!='.gdignore']
excluded={'.runtime','.godot','node_modules','build','releases'}
files=[p for p in base.rglob('*') if p.is_file() and not any(s in excluded for s in p.relative_to(base).parts) and p.suffix not in ['.blend1','.log','.import'] and not p.name.startswith(('life-failure','probe','two-player-review'))]
releases=[archive('moyeo-house-web-0.1.0.zip',web,base/'build'),archive('moyeo-house-project-0.1.0.zip',files,base.parent)]
(out/'release-manifest.json').write_text(json.dumps(releases,indent=2),encoding='utf8')
print(json.dumps(releases,indent=2))
