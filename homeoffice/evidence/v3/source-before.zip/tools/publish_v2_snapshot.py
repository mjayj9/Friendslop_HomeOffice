"""Copy the reviewed Godot project/build into the isolated GitHub checkout.
Does not push, delete old source or touch external services.
"""
from pathlib import Path
import shutil,json,hashlib
R=Path(__file__).resolve().parents[1];repo=R.parent/'deployment/Friendslop_HomeOffice'
assert (repo/'.git').is_dir()
ignored={'.git','.runtime','.godot','node_modules','__pycache__','releases','build'}
for folder in ['assets','art','docs','web','scripts','scenes','tests','schemas']:
 for f in (R/folder).rglob('*'):
  if not f.is_file() or any(x in ignored for x in f.relative_to(R).parts) or f.suffix in ['.blend1','.blend2','.pyc']:continue
  rel=f.relative_to(R)
  if f.name=='AGENTS.md':rel=rel.with_name('AGENTS.reference.txt')
  target=repo/'homeoffice'/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,target)
for name in ['project.godot','export_presets.cfg','package.json','package-lock.json','README.md']:
 shutil.copyfile(R/name,repo/'homeoffice'/name)
for name in ['assemble_v2.py','v2_base.txt','v2_functions.txt','living_functions_v2.txt','design_v2.py','living_layout_v2.py','bundle_stt.mjs','bundle_collaboration.mjs','serve.mjs','build.ps1','synthesize_stt.ps1','report_stt_v2.py']:
 shutil.copyfile(R/'tools'/name,repo/'homeoffice/tools'/name)
for f in (R/'evidence').iterdir():
 if not f.is_file() or not (f.name.startswith('v2-') or f.name=='pages-validation.json') or f.suffix not in ['.json','.png','.jpg','.log','.homeworld']:continue
 if any(x in f.name for x in ['failure','before-heartbeat','input-probe','contact-review','review']):continue
 shutil.copyfile(f,repo/'homeoffice/evidence'/f.name)
for f in (R/'build').rglob('*'):
 if not f.is_file() or f.suffix=='.import' or f.name=='.gdignore':continue
 target=repo/'docs'/f.relative_to(R/'build');target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,target)
shutil.copytree(R/'schemas',repo/'docs/schemas',dirs_exist_ok=True)
for f in repo.rglob('*'):
 if f.is_file() and '.git' not in f.parts and f.suffix in ['.md','.txt','.gd','.mjs','.js','.json','.html','.py','.css','.yml','.ps1']:
  data=f.read_bytes().replace(b'\r\n',b'\n');f.write_bytes(data.rstrip()+b'\n')
out=repo/'docs';files=[{'file':f.relative_to(out).as_posix(),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in out.rglob('*') if f.is_file()]
manifest={'version':'0.2.0-dev','engine':'4.6.1.stable.official.14d19694e','sourceBranch':'codex/godot-homeoffice-v2','initialGameWeightsExcluded':True,'totalHostedBytes':sum(x['bytes']for x in files),'files':files}
for target in [R/'docs/v2/web-build-manifest.json',repo/'homeoffice/docs/v2/web-build-manifest.json']:target.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8')
readme=repo/'README.md';readme.write_text(readme.read_text(encoding='utf8').replace('수납/조명·팀 경기 규칙','수납을 포함한 통합 생활 인수·팀 경기 규칙'),encoding='utf8')
print(json.dumps({'hostedBytes':manifest['totalHostedBytes'],'files':len(files),'copiedTo':str(repo)},ensure_ascii=False))
