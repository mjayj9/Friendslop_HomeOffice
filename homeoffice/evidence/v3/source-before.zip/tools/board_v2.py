from pathlib import Path
p=Path(__file__).resolve().parents[1]
c=p/'tools/v2_base.txt';s=c.read_text(encoding='utf8').replace('preload("res://scripts/board.gd")','preload("res://scripts/v2/board.gd")').replace('var strokes=[]','var board_history={}\nvar strokes=[]')
s=s.replace('"color":"#183b32","width":4,"physical":true','"color":String(bridge.pen_color()) if bridge else "#183b32","width":float(bridge.pen_width()) if bridge else 4,"physical":true')
s=s.replace('\tstrokes=w.board.duplicate(true)','\tboard_history.clear()\n\tstrokes=w.board.duplicate(true)')
s=s.replace('''			if operation.has("add"):
				var exists=false
				for stroke in strokes:
					if stroke.id==operation.add.id:exists=true
				if not exists:strokes.append(operation.add)
			if operation.has("remove"):
				strokes=strokes.filter(func(stroke):return stroke.id!=operation.remove)''','''			if operation.has("remove"):strokes=strokes.filter(func(stroke):return stroke.id!=operation.remove)
			if operation.has("add"):strokes.append(operation.add)''')
c.write_text(s,encoding='utf8')
c=p/'tools/v2_functions.txt';s=c.read_text(encoding='utf8').replace('if action in ["stroke","undo","read","drop","throw"]:', '''if action in ["stroke","undo","board_update","board_delete"]:
		actions[id]=order
		if data is Dictionary:board_action(id,order,action,data)
		return
	if action in ["read","drop","throw"]:''')
s+='''

func board_action(id:String,order:int,action:String,data:Dictionary):
	var player=players[id]
	if player.eye().distance_to(board_body.position)>4.2:return reject(id,"보드 가까이에서 사용할 수 있습니다")
	var ray=PhysicsRayQueryParameters3D.create(player.eye(),board_body.position,1,[player.get_rid()])
	var hit=get_world_3d().direct_space_state.intersect_ray(ray)
	if not hit.is_empty() and hit.collider!=board_body:return
	var before={}
	var after={}
	var index=-1
	if action=="stroke":
		if not valid_stroke(data) or strokes.size()>=512:return
		if data.get("physical",false):
			if player.holding=="" or definitions[player.holding].kind!="marker":return
			if absf((objects[player.holding].global_transform*Vector3(0,-.10,0)).z-board_body.position.z)>.25:return
		after={"id":id+":"+str(order),"author":id,"points":data.points,"color":data.color,"width":data.width,"version":1}
		if data.get("kind","")=="text":
			if not data.get("text") is String or data.text.length()>160:return
			after.kind="text";after.text=data.text;after.fontSize=28
	elif action=="undo":
		if not board_history.has(id) or board_history[id].is_empty():return
		var entry=board_history[id].pop_back()
		var reference=entry.after if not entry.after.is_empty() else entry.before
		for i in range(strokes.size()):
			if strokes[i].id==reference.id:index=i;break
		if not entry.after.is_empty() and (index<0 or strokes[index].get("version",0)!=entry.after.get("version",0)):return reject(id,"다른 참가자가 수정한 항목은 Undo로 덮어쓰지 않습니다")
		if entry.after.is_empty() and index>=0:return
		before=entry.after;after=entry.before
	else:
		for i in range(strokes.size()):
			if strokes[i].id==data.get("id",""):index=i;break
		if index<0 or strokes[index].get("version",0)!=data.get("version",-1):return reject(id,"보드 항목이 변경되었습니다. 다시 선택해 주세요")
		before=strokes[index].duplicate(true)
		if action=="board_update":
			after=before.duplicate(true);after.points=data.get("points",[])
			if not valid_stroke(after):return
			after.version=int(before.get("version",0))+1
	if action!="undo":
		if not board_history.has(id):board_history[id]=[]
		board_history[id].append({"before":before,"after":after})
		if board_history[id].size()>80:board_history[id].pop_front()
	var operation={}
	if not before.is_empty():
		strokes=strokes.filter(func(s):return s.id!=before.id)
		operation.remove=before.id
	if not after.is_empty():strokes.append(after);operation.add=after
	refresh_board()
	send({"type":"board","epoch":epoch,"operation":operation})
	revision+=1
'''
c.write_text(s,encoding='utf8')
c=p/'web/save-v2.mjs';s=c.read_text(encoding='utf8').replace("keys(s,['id','author','points','color','width']);", "keys(s,['id','author','points','color','width'],['kind','text','fontSize','version']);if(s.kind!==undefined&&(s.kind!=='text'||typeof s.text!=='string'||s.text.length>160||s.fontSize!==28))bad();if(s.version!==undefined&&(!Number.isSafeInteger(s.version)||s.version<0))bad();")
c.write_text(s,encoding='utf8')
c=p/'web/bridge.mjs';s=c.read_text(encoding='utf8');s="import {createBoardTools} from './board-tools.mjs';\n"+s
start=s.index('function renderBoard()');end=s.index('\nfunction point',start)
s=s[:start]+"function renderBoard(){boardTools.render()}"+s[end:]
s=s.replace('status,menu:showMenu,','pen_color:()=>$(\'color\').value,pen_width:()=>Number($(\'width\').value),status,menu:showMenu,')
s+='\nconst boardTools=createBoardTools({strokes:()=>boardStrokes,action:(action,data)=>push({type:"action",action,data})});\n'
c.write_text(s,encoding='utf8')
print('Whiteboard Korean text, shapes, selection/move/delete and author undo added')
