from pathlib import Path
p=Path(__file__).resolve().parents[1]
c=p/'tools/v2_base.txt';s=c.read_text(encoding='utf8').replace('var build_kind=""','var build_move_id=""\nvar build_kind=""').replace('body.set_meta("object_id",d.id)','body.set_meta("object_id",d.id)\n\tbody.set_meta("kind",kind)')
c.write_text(s,encoding='utf8')
c=p/'tools/v2_functions.txt';s=c.read_text(encoding='utf8')
s=s.replace('"kind":build_kind,"p":arr(build_point),"yaw":build_angle','"kind":build_kind,"p":arr(build_point),"yaw":build_angle,"objectId":build_move_id')
s=s.replace('if event.keycode==KEY_Z:request_action', '''if event.keycode==KEY_G:
			var object_id=target(players[local_id]).get("id","")
			if objects.has(object_id):begin_build(definitions[object_id].kind,object_id)
			return
		if event.keycode==KEY_DELETE:request_action("remove_object");return
		if event.keycode==KEY_Z:request_action''')
s=s.replace('if action=="place":place_object(id,data);return','''if action=="place":place_object(id,data);return
	if action=="remove_object":
		var object_id=target(p).get("id","")
		if not objects.has(object_id) or not definitions[object_id].kind in ["chair","table","sofa","bed","book","crate","marker","plate","gun","shield"]:return
		if object_in_use(object_id):return reject(id,"사용 중인 가구와 소품은 철거할 수 없습니다")
		var o=objects[object_id]
		remove_child(o);o.queue_free();objects.erase(object_id);definitions.erase(object_id);revision+=1
		return''')
s=s.replace('if p.seated!="" and definitions[p.seated].kind=="sofa":p.posture="lying";return','''if p.seated!="" and definitions[p.seated].kind=="sofa":
			var sofa=objects[p.seated]
			if sofa.get_meta("seats",{}).size()>1:return reject(id,"소파가 비어 있을 때 누울 수 있습니다")
			p.posture="lying";sofa.set_meta("lying",id);p.position=sofa.position;p.seat_yaw=sofa.rotation.y+PI/2
			return''')
s=s.replace('o.set_meta("seats",seats)\n\t\to.set_meta("occupant","")','o.set_meta("seats",seats)\n\t\tif o.get_meta("lying","")==p.actor_id:o.set_meta("lying","")\n\t\to.set_meta("occupant",seats.values()[0] if not seats.is_empty() else "")')
s=s.replace('if seats.has(str(seat_index)) or (kind=="bed"', 'if o.get_meta("lying","")!="" or seats.has(str(seat_index)) or (kind=="bed"')
s=s.replace('func placement_ok(p,kind:String,point:Vector3,angle:float)', 'func placement_ok(p,kind:String,point:Vector3,angle:float,move_id:String="")')
s=s.replace('var ray=PhysicsRayQueryParameters3D.create(p.eye(),point+Vector3.UP*.3,1,[p.get_rid()])','var excluded=[p.get_rid()]\n\tif objects.has(move_id):excluded.append(objects[move_id].get_rid())\n\tvar ray=PhysicsRayQueryParameters3D.create(p.eye(),point+Vector3.UP*.3,1,excluded)')
s=s.replace('q.exclude=[p.get_rid()]','q.exclude=excluded')
s=s.replace('var kind=String(data.get("kind",""))\n\tif not kind', 'var kind=String(data.get("kind",""))\n\tvar move_id=String(data.get("objectId",""))\n\tif move_id!="" and (not objects.has(move_id) or definitions[move_id].kind!=kind or object_in_use(move_id)):return reject(id,"사용 중이거나 없는 가구는 옮길 수 없습니다")\n\tif not kind')
s=s.replace('if not placement_ok(p,kind,point,angle):','if not placement_ok(p,kind,point,angle,move_id):')
s=s.replace('spawn_object({"id":object_id,"kind":kind,"p":arr(point),"yaw":angle,"state":{}})','''if move_id!="":
		objects[move_id].position=point;objects[move_id].rotation.y=angle
		if objects[move_id] is RigidBody3D:objects[move_id].linear_velocity=Vector3.ZERO;objects[move_id].angular_velocity=Vector3.ZERO
		definitions[move_id].p=arr(point);definitions[move_id].yaw=angle
	else:spawn_object({"id":object_id,"kind":kind,"p":arr(point),"yaw":angle,"state":{}})''')
s=s.replace('func begin_build(kind:String):','func begin_build(kind:String,move_id:String=""):').replace('build_kind=kind\n\tbuild_angle','build_kind=kind\n\tbuild_move_id=move_id\n\tbuild_angle').replace('func end_build():\n\tbuild_kind=""','func end_build():\n\tbuild_kind=""\n\tbuild_move_id=""').replace('placement_ok(p,build_kind,build_point,build_angle)','placement_ok(p,build_kind,build_point,build_angle,build_move_id)')
s+='''

func object_in_use(object_id:String) -> bool:
	var object=objects.get(object_id)
	if not object:return true
	if object.get_meta("owner","")!="" or not object.get_meta("seats",{}).is_empty():return true
	for player in players.values():
		if player.seated==object_id or player.holding==object_id:return true
	return false
'''
c.write_text(s,encoding='utf8')
c=p/'scripts/v2/avatar.gd';s=c.read_text(encoding='utf8').replace('var before=global_position','var falling_speed=velocity.y\n\tvar before=global_position').replace('for i in range(get_slide_collision_count()):','''for i in range(get_slide_collision_count()):''').replace('var body=hit.get_collider()','''var body=hit.get_collider()
		if not was_floor and falling_speed < -3 and hit.get_normal().y>.7 and body and body.get_meta("kind","")=="sofa":velocity.y=clampf(-falling_speed*.38,1.0,4.0)''')
c.write_text(s,encoding='utf8')
print('Safe furniture move/delete and exclusive sofa lying, bounded sofa landing response added')
