from pathlib import Path
p=Path(__file__).resolve().parents[1]
c=p/'web/bridge.mjs';s=c.read_text(encoding='utf8')
s=s.replace('{c.close();return}\n  connections.set(c.peer,c);', "{c.send({type:'session-reject',reason:connections.size>=7?'이 집의 정원은 8명입니다.':'방장 이전 중이거나 이미 연결된 참가자입니다.'});setTimeout(()=>c.close(),400);return}\n  connections.set(c.peer,c);")
s=s.replace("if(m.type==='profile'){", "if(m.type==='session-reject'&&!host){$('loading').textContent=m.reason;status(m.reason);return}\n  if(m.type==='profile'){")
s=s.replace("c.on('close',()=>{if(c.retired)return;connections.delete", "c.on('close',()=>{if(c.retired||connections.get(c.peer)!==c)return;connections.delete")
c.write_text(s,encoding='utf8')
