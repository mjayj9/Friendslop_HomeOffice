from pathlib import Path
R=Path(__file__).resolve().parents[1]
p=R/'web/bridge.mjs';s=p.read_text(encoding='utf8').replace("from './save.mjs'","from './save-v2.mjs'")
s=s.replace("if(me)$('zone').textContent=me.p[0]>6?'회의실':'거실'", "if(me)$('zone').textContent=({hall:'현관 · 계단',living:'거실',dining:'식당',kitchen:'주방',meeting:'회의실',free:'자유 작업방',game:'태그 · 사격',arcade:'아케이드',sleep:'수면실',reading:'독서 휴식',upper_hall:'2층 갤러리',garden:'마당',basketball:'농구',football:'축구','personal-gallery':'개인실 복도'})[me.zone]||me.zone")
s=s.replace('f.size>8*1024*1024','f.size>32*1024*1024').replace('8MB','32MB')
p.write_text(s,encoding='utf8')
p=R/'web/shell.html';s=p.read_text(encoding='utf8').replace('<span>01 거실</span><span>02 회의실</span><span>첫 생활 공간 · P1</span>','<span>2층 집 + 오피스</span><span>정원과 게임 별동</span><span>V2 · 필수 기능 구현 중</span>');p.write_text(s,encoding='utf8')
p=R/'project.godot';s=p.read_text(encoding='utf8').replace('Homeoffice P1','Homeoffice V2').replace('config/version="0.1.0"','config/version="0.2.0-dev"');p.write_text(s,encoding='utf8')
# Preserve authored save positions while rebuilding only the office shell.
p=R/'tools/v2_functions.txt';s=p.read_text(encoding='utf8').replace('func add_room(index:int):','func add_room(index:int,furnish:bool=true):').replace('if not objects.has(d.id):spawn_object(d)','if furnish and not objects.has(d.id):spawn_object(d)').replace('for i in range(room_slots.size()):add_room(i)','for i in range(room_slots.size()):add_room(i,false)');p.write_text(s,encoding='utf8')
p=R/'tools/v2_base.txt';s=p.read_text(encoding='utf8').replace('"id":id,"p":arr(o.position),"r":arr(o.rotation)','"id":id,"kind":definitions[id].kind,"p":arr(o.position),"r":arr(o.rotation)')
s=s.replace('for s in m.objects:\n\t\t\t\tif objects.has(s.id):','for s in m.objects:\n\t\t\t\tif not objects.has(s.id):spawn_object({"id":s.id,"kind":s.kind,"p":s.p,"yaw":s.r[1],"state":s.get("state",{})})\n\t\t\t\tif objects.has(s.id):')
s=s.replace('p.queue_free()\n\t\t\t\tplayers.erase(e.id)','p.queue_free()\n\t\t\t\tplayers.erase(e.id)\n\t\t\t\tmember_slots.erase(e.id)')
p.write_text(s,encoding='utf8')
