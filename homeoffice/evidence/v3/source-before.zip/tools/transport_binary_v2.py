from pathlib import Path
p=Path(__file__).resolve().parents[1]
c=p/'web/bridge.mjs';s=c.read_text(encoding='utf8').replace("serialization:'json'","serialization:'binary'")
c.write_text(s,encoding='utf8')
c=p/'web/local-stt.mjs';s=c.read_text(encoding='utf8').replace('let worker,ready=false','let wasTransmitting=false;let worker,ready=false').replace("if(samples||silence){generation++;parts=[];samples=0;silence=0}return}","if(wasTransmitting||samples||silence){generation++;parts=[];samples=0;silence=0}wasTransmitting=false;return}wasTransmitting=true;")
c.write_text(s,encoding='utf8')
print('PeerJS binary serialization uses library chunk/reassembly above its JSON 16300-byte limit')
