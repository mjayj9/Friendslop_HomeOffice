from pathlib import Path
import json,runpy,shutil
p=Path(__file__).resolve().parents[1];d=p/'docs/v2';x=runpy.run_path(str(p/'tools/write_v2_traceability.py'));m=x['mapping'];req=x['requirements'];tests=x['tests']
def update(ids,files,behavior,evidence,remaining,status='구현'):
 for n in ids:m[f'U{n:02}']=[status,files,behavior,evidence,remaining]
update([5,6],'web/save-v2.mjs · web/presentation-view.mjs · scripts/v2/world.gd','확정 세계+Yjs+원본 PDF+페이지 주석 단일 ZIP, 검증 미리보기, 백업 후 복원','v2-browser-handoff.json · v2-after-handoff.homeworld · save-v2.test.mjs','전체 생활/수납/모든 자산을 함께 담은 통합 인수, 임시 물리 세계의 배치 검증 필수 미완료')
update([7,32,53,56],'assets/v2/layout.json · art/build_v2.py · art/materials_v2.py','2층 본관/천장/지붕/계단/별동/두 코트/개인실 갤러리, 나무·천·타일 자체 텍스처','site-plan.svg · ground-floor.svg · upper-floor.svg · space-program.md · stair-section.svg · v2-browser-walk.json','손에 물건을 든 두 사람 교행, 모든 방 미술 품질과 외관 완성도 검수 필수 미완료')
update([8],'scripts/v2/avatar.gd · scripts/v2/world.gd · project.godot','Jolt 60Hz, 계단/문턱, 제한 집기, CCD와 실제 중력/반발 드리블','v2-navigation.json · v2-dribble.json','고속 림/벽 반복·저천장·원격 소품 보간·예측 재적용 정밀 검사 필수 미완료')
update([10],'assets/characters/quaternius_cc0-male-character-*.glb · docs/character-inspection.json','이미 제공된 남자 GLB 5개 존재 확인; 중복 업로드 요청 생략','실제 파일 검사 및 docs/character-inspection.json','없음: 사용자 최신 지시의 제공 파일 우선 확인을 따름','검증완료')
update([12,23,24,31,45],'scripts/v2/world.gd · assets/v2/gun.glb · assets/v2/shield.glb','출입 승인/무기 승인 구분, 구역/탄약/재장전/벽/방패 방향, 회수','v2-interactions.json: 실제 엔진 허가·회수·회의실 거절','사람 상대 라운드, 그립·조준·반동/피격 품질, 위조 요청/방패 각도 전체 시험 필수 미완료')
update([13,43,44],'scripts/v2/world.gd · assets/v2/grounds.glb','독립 코트, 실제 중력 드리블, 패스/충전 슛, 열린 림/선 교차 점수, 공 복귀','v2-dribble.json · v2-interactions.json · 실제 코트 보행 화면','실제 브라우저 슛 감각/팀 배정·팀 경기 규칙/공 경합·림 고속 시험 필수 미완료')
update([14,15,16,17],'web/bridge.mjs · scripts/v2/world.gd','근거리/Zone/세션, 거리 상한/방송 승인, 실제 범위 밖 media 종료, 가림 감쇠','v2-browser-arcade-voice.json: 실제 RTC/합성 마이크','두 사람 실제 마이크 청취, 음질/에코/장치 교체/autoplay/차단 경합 시험 필수 미완료')
update([18,19],'web/captions.mjs · web/local-stt.mjs · web/stt-worker-source.mjs','한국어 Whisper tiny q8 WASM 실제 로컬 인식, 마이크 VAD, 화자/범위/중복/늦은 결과 처리','korean-stt-measurement.md · v2-stt-browser.json · v2-stt-metrics.json','실제 사람/여러 마이크 CER/WER·확정 지연, ko-KR 언어팩 비교, 인식 품질 목표 필수 미완료','제약')
update([20,21,22,25,26,27,28,29,30],'scripts/v2/world.gd · web/activities.mjs · assets/v2/manifest.json','B 카탈로그/미리보기/회전/설치, G 이동/Delete 제거, 좌석/책/마카/상자','v2-authority.json 점유 가구 보호 · v2-interactions.json 좌석/물건 · V2 웹 이동','수납형 상자/서랍/조명 일반 사용·정밀 그립·동시 점유 다중 브라우저 인수 필수 미완료')
update([33,34],'scripts/v2/board.gd · scripts/v2/world.gd · web/board-tools.mjs','3D 마카 펜촉 검증과 확대 UI의 선/도형/한글/색/이동/삭제/작성자 Undo','v2-authority.json: 실제 엔진 보드 12개 권위/체크포인트 시험','두 실제 브라우저의 물리 펜촉/동시 획/확대 UI 전체 인수 필수 미완료')
update([38,39],'web/presentation.mjs · web/presentation-view.mjs · web/collaboration-source.mjs','PDF/이미지 실제 발표, 페이지/발표권한, 공유 레이저/주석/저장, 의제/손들기/타이머/결론','v2-browser-presentation.json 8항목 · v2-browser-handoff.json 주석/PDF 왕복','별도 질문 큐, 전체 의제→토론→투표→보고서→할 일 회의 시나리오 필수 미완료')
update([40,41],'scripts/v2/world.gd · assets/v2/office_left.glb · assets/v2/gallery.glb','연결 복도 끝의 개인실 생성, 안정 슬롯, 기존 책상/방 불변, 퇴장해도 보존','v2-multiplayer-scale.json: 실제 2/4/8 브라우저·동일 이름·8→4 퇴장 / v2-eight-rooms.homeworld','재입장 전체 경합, 8인 개인실 보행/음향/확장 전후 영상 세부 검수 필수 미완료')
update([42],'scripts/v2/world.gd · assets/v2/layout.json','자유방 연결, 일반 가구 배치/협업, 별도 무기 구역 승인','v2-navigation.json 실제 엔진 연속 보행','모든 협업 도구를 자유방에서 함께 쓰는 전체 시험 필수 미완료')
update([46,47],'web/arcade.mjs · web/arcade-rules.mjs · assets/v2/arcade.glb','사용자 확인대로 자체 미로 수집/적 회피, 자체 공룡 러너, 호스트 게임 규칙/결과/재시작','v2-browser-arcade-voice.json: 실제 기계 접근/수집/점프/실패/재시작/원위치, arcade-rules.test.mjs','두 사람이 기계 앞에서 관전/사용권 경합, 미로 끝까지 클리어, 경기 중 호스트 이전 인수 필수 미완료')
update([48,49,50,51],'scripts/v2/world.gd · scripts/v2/avatar.gd · assets/v2/','소파 좌석/눕기/제한 탄성, 침대 눕기/취침/기립, 재료→조리→담기→운반→식사→정리','v2-interactions.json 20항목 실제 Godot 엔진; 직접 시험 위치 사용','여러 사람 브라우저 전체 생활 동작/손·소품/중복 소비/소파 탄성 미술 인수 필수 미완료')
update([54,55],'project.godot · export_presets.cfg · art/*.blend · tools/build.ps1','확인된 Godot 4.6.1 stable+matching templates, Compatibility 단일 스레드, BlenderMCP 실제 제작','v2-export.log · v2-browser-walk.json · art/moyeo-v2.blend · art/v2-blender-exterior-preview.png','GitHub Pages 별도 실측 기록 참조. 2~8인 목표 성능·미술 전체 품질 필수 미완료')
rows=['# U01~U56 원문 요구 추적표','', '2026-09-15. `구현`은 일부 실행 경로가 있다는 뜻이며 전체 인수 통과가 아니다. **필수 미완료는 범위에서 제외하지 않았다.** 시험 파일은 `evidence/`, 도면은 `docs/v2/` 기준.','', '| ID | 원문 요구 | 상태 | 구현 파일/에셋 | 실제 동작 | 검증 근거 | 남은 문제 |','|---|---|---|---|---|---|---|']
for u in req:rows.append('| '+' | '.join([u[0],u[1],*m[u[0]]])+' |')
(d/'requirements-traceability.md').write_text('\n'.join(rows)+'\n',encoding='utf8')
e=x['evidence'];e.update({
'T02':'참고 사이트 실제 Chromium 시작 화면과 README/코드 검토. 원작 다중 플레이/마이크 감각 미확인 · docs/reference-analysis.md',
'T05':'같은 layout.json 도면/모델, space-program.md와 stair-section.svg. 전체 시각 대조는 부분 검증',
'T06':'부분 통과 · v2-navigation.json 엔진 연속 보행, v2-browser-walk.json 실제 브라우저 주요 공간',
'T07':'실제 게임 실내 캡처의 천장/외피 존재 확인. 모든 틈새 검수 미완료',
'T08':'실제 브라우저 계단→2층→개인실/수면/독서 연속 보행. 모든 머리 간섭 코스 미완료',
'T09':'실제 엔진 모든 필수 Zone 연속 보행 통과; 실제 브라우저 주요 공간 영상. 욕실/보조실 전수 영상 미완료',
'T10':'목적별 실제 가구/마감/창/조명 에셋. 최종 미술 인수 미완료',
'T12':'실제 브라우저 두 코트와 별동 개별 접근. 동시 경기 간섭 미실행',
'T13':'Blender 프리뷰 art/v2-blender-exterior-preview.png와 실제 evidence/v2-game-*.png 및 v2-walk-video 구분. 모든 동선 영상 검수 미완료',
'T14':'통과 · v2-multiplayer-scale.json: 독립 Chromium 2/4/8, 실제 WebRTC와 개인실 수 일치',
'T15':'부분 통과 · 실제 2→4→8 첫 책상 좌표 불변. 모든 사람/소품 전수 비교 미완료',
'T16':'엔진 모듈/끝벽/이름표/충돌/조명/Zone 생성 확인. 8인 실제 음향 인수 미완료',
'T17':'부분 통과 · 실제 동일 이름 8명 각각 고유 슬롯. 재입장 경합 전수 미실행',
'T18':'부분 통과 · 실제 8→4 퇴장 후 8실 보존/다운로드, v2-eight-rooms.homeworld',
'T21':'실제 전신 GLB와 로컬 손 모델, 자기 머리 숨김. 전체 자세 관통/그립 미완료',
'T22':'부분 통과 · CDP 한글 조합 중 W 이동 차단, 실제 아케이드 종료 위치 불변',
'T23':'실제 보고서/발표/아케이드 닫기→이동. 모든 상태 전이/키 재설정 미완료',
'T25':'호스트 거리/가림/보호 위치 검사 코드. 악성/경합 전수 시험 미완료',
'T28':'v2-authority.json 점유 의자 보호 통과, 8인 퇴장 정리 통과. 동시 가구 삭제 브라우저 인수 미완료',
'T29':'계단/문턱 엔진 및 브라우저 보행 통과. 경사/저천장/모서리 반복 코스 미완료',
'T30':'부분 통과 · v2-dribble.json 바닥 반발 최소 Y .2352, 반지름 .24. 고속 벽/림 전수 미실행',
'T31':'부분 통과 · 실제 중력 드리블 7초/5회 반발/최대 6.81m/s. 소파/집기 스트레스 미완료',
'T32':'실제 다중 브라우저 이동, 오래된 입력 큐 수정. 원격 소품 부드러운 보간/예측 재적용 미완료',
'T33':'부분 통과 · 실제 거리 이탈 트랙 종료. 벽/문/층 ray 감쇠 구현, 실제 사람 청취 미실행',
'T34':'부분 통과 · v2-browser-arcade-voice.json 승인된 전체 방송 거리 밖 연결 성공. Zone 전체 반복 시험 미완료',
'T35':'부분 통과 · 발화자 범위 밖 실제 media 종료. 차단/음소거 우회 전수 미실행',
'T38':'부분 통과 · 실제 합성 마이크 종료 후 트랙 정리. STT 늦은 결과/모든 종료 경합 미실행',
'T39':'부분 검증 · Whisper tiny q8 WASM 실제 한국어 인식. headless 언어팩 조회 충돌 제약; 실제 Chrome/Edge ko-KR 팩 미검증',
'T40':'제약 · 6개 합성 문장 CER 17.2%/WER 29.7% 및 추론/FPS 실측. 실제 사람/마이크 시험 미완료',
'T41':'provider 중간/확정·sequence/generation·표시 설정 구현. 실제 사람 화자/지연 전수 미완료',
'T43':'로컬 모델 실제 로딩/실패 안내/재시도, 자동 외부 전환 없음. 미지원 브라우저 전수 미실행',
'T44':'3D/DOM 동일 상태 연결, 실제 엔진 한글/이동/삭제 시험. 실제 펜촉 브라우저 인수 미완료',
'T45':'v2-authority.json 작성자 Undo가 타인 수정 덮어쓰기 거부 통과. 두 브라우저 전수 미실행',
'T49':'부분 통과 · 실제 두 브라우저 PDF/페이지/권한/레이저/주석 공유, 파일·방장 이전 왕복. 손들기·타이머 포함 전체 회의 미완료',
'T50':'PPTX 미지원 명시, PowerPoint→PDF 안내; 실제 2쪽 PDF 렌더링 통과',
'T51':'실제 늦은 참가자 PDF 원본 수신. chunk/별도 bulk 큐 구현, 취소/재시도/음성 동시 스트레스 미완료',
'T52':'부분 통과 · 실제 엔진 무기 집기 승인, 별도 출입 허가/경계 검사. 악성 출입 전수 미완료',
'T53':'부분 통과 · 실제 엔진 이미 든 총 즉시 회수/회의실 거절, 저장 권한 배제. 예약 발사 공격 전수 미완료',
'T55':'실제 엔진 중력 드리블 통과, 패스/충전 슛 구현. 실제 브라우저 경기 감각 미완료',
'T56':'부분 통과 · 실제 엔진 제어 교차 샘플 위→아래 1회, 중복/아래→위 거절. 실제 슛/링 옆 반복 미실행',
'T57':'라운드 상태/점수/시간/재시작 구현. 팀 배정/완결 규칙 필수 미완료',
'T58':'충전 킥/골라인/밖으로 공 복귀/재시작 구현. 실제 두 브라우저 축구 인수 미완료',
'T59':'사용자 확인: 팩맨처럼 미로 수집/적 회피. 자체 IP 정원 미로 실제 기계 입장/수집 시험 통과; 전체 클리어 미실행',
'T60':'부분 통과 · 실제 기계/점프/장애물 충돌/결과/재시작/나가기. 두 사람 현장 관전 미실행',
'T61':'소파 좌석/눕기/제한 탄성 구현. 실제 여러 사람 동시 검증 미완료',
'T62':'부분 통과 · v2-interactions.json 실제 엔진 6초 조리→음식→접시→의자 식사→싱크 정리/중복 소비 차단. 다중 브라우저 생활 인수 미완료',
'T63':'부분 통과 · 실제 엔진 눕기/취침/안전 기립, 전역 시간 변경 없음. 실제 상대/점유 경합 미완료',
'T64':'로컬 독립 Chromium 2/4/8 actual WebRTC 통과. 공개 Pages 별도 증거 참조; 서로 다른 WAN 두 PC는 미검증',
'T65':'부분 통과 · 실제 late join 공간/개인실/Yjs/원본 PDF/페이지 주석. 모든 생활·게임 진행 상태 조합 미완료',
'T66':'엔진 seq/epoch/권한 검증, 서버 규칙 아케이드. 전체 위조/DoS 인수 미완료',
'T67':'실제 JSON 채널 크기 초과와 오래된 입력 큐 문제 수정, binary chunking/분리 큐/heartbeat. 손실·대역폭/탭 비활성 스트레스 미완료',
'T68':'부분 통과 · v2-browser-handoff.json 실제 두 브라우저 세계·좌표·Yjs·PDF·주석·권위/epoch 이전. 8인 진행 중 게임·생활 전체 인수 미완료',
'T69':'부분 통과 · v2-browser-arcade-voice.json 방장 실제 종료→시각/손실 안내→새 호스트/2실 보존. 모든 문서/슬라이드 복구 조합 미완료',
'T70':'부분 통과 · 실제 가구/개인실/Yjs/PDF 원본/페이지 주석 다운로드→복원→이전→재다운로드. 모든 생활/수납/게임 통합 왕복 미완료',
'T71':'실제 revision 파일 다운로드 및 메뉴 종료 분리. 사용자가 파일을 보관했는지는 자동 보장하지 않음',
'T72':'실제 파일 가져오기 후 두 번째 브라우저가 같은 방·보고서·PDF에 late join 통과',
'T73':'파일 스키마 옛 role/peer/grants/occupancy 배제, restore 손/좌석 초기화. 모든 공격 조합 미완료',
'T74':'Node 7항목 CRC/SHA/경로/중복/권한/자산/버전 거절. ZIP stored만 수용(압축 폭주 불허), 실제 PDF 검증 후 복원. 모든 물리 배치 임시 세계 검증 미완료',
'T75':'허용 필드/자료만 저장, 원음/동의 없는 전사/비밀/실행 코드 저장 경로 없음. 사용자 자료 내용의 민감성 자동 검사 아님',
'T76':'다운로드 요청과 보관을 구분하며 캐시 영구 저장 보장 없음. 디스크 부족/취소 실제 시험 미완료',
'T77':'실제 localhost 하위 경로 Godot WASM/PCK/GLB/폰트/JS 통과. 공개 Pages 증거는 pages-validation.json 참조(없으면 미검증)',
'T78':'미통과 · v2-multiplayer-scale.json 2/4/8 동시 Chromium. 8개 동일 PC host 6~7fps. STT 동시 1080p 별도 32~38fps. 목표 성능 및 전체 메모리/대역폭 미달/미계측',
'T79':'퇴장 heartbeat 정리/강제 종료 새 세션은 실제 시험. 장시간 반복 GPU/DOM/track 누수 측정 미완료',
'T80':'56개 원문과 80개 인수 모두 유지. 전체 필수 기능 및 품질이 남아 있으므로 제품 완료 아님'})
rows=['# T01~T80 실제 인수 기록','','2026-09-15. 부분 시험 통과는 전체 원문 인수 통과가 아니다. 실제 브라우저, 실제 엔진의 위치 고정 시험, Node 규칙 시험, 합성 음성을 구분한다.','', '| ID | 분야 | 원문 시험 | 실제 결과/증거 |','|---|---|---|---|']
for t in tests:rows.append('| '+' | '.join(t[:3]+[e.get(t[0],'미실행 · 필수 인수 미완료')])+' |')
(d/'acceptance-80.md').write_text('\n'.join(rows)+'\n',encoding='utf8')
remaining='''# 필수 미완료 및 검증 한계

이 빌드는 최종 제품 완료가 아니다. U01~U56의 범위를 줄이지 않았으며 아래는 선택적 확장이 아닌 필수 잔여 작업이다. 상세 근거는 requirements-traceability.md와 acceptance-80.md를 따른다.

- 캐릭터: 제공 GLB는 정적 메시였다. 신규 간이 13본 리깅과 절차적 이동/들기, 별도 앉기/눕기 메시를 사용했다. 모든 동작의 자연스러운 전환, 손·발 IK, 무기/마카/스포츠/조리 그립이 미완료다.
- 환경/사물: 전체 건축과 주요 가구는 실제 제작되어 있지만 최종 미술 검수, 수납형 상자·서랍·개별 조명 사용, 두 사람 교행/가구 설치 경합, 전 공간 생활 디테일 품질이 남았다.
- 스포츠/태그: 실제 물리 공/득점/충전/라운드와 호스트 허가는 있으나 팀 배정·완결된 팀 규칙, 경기 감각, 방패 방향/벽/림의 반복 실전 시험이 남았다. 미로 전체 클리어와 두 사람 아케이드 현장 관전도 추가 검증이 필요하다.
- 회의: Yjs 동시 한글, PDF/레이저/주석/보드가 있으나 실제 사람 IME와 재접속/Undo 전수, 질문 큐, 전체 회의 의제→보고서→할 일 흐름의 인수가 남았다.
- 음성/한국어: 실제 RTP 시험은 합성 마이크다. 두 사람 실제 청취, 장치 교체/허가 거부/에코/잡음, 실제 한국어 마이크 테스트셋, 브라우저 언어팩 비교와 품질 개선이 남았다. 합성 6문장 CER 17.2%, WER 29.7%를 실제 사람 정확도로 해석하지 않는다.
- 네트워크/저장: 로컬 다중 브라우저와 정상 방장 이전/강제 종료 복구는 시험했지만 서로 다른 WAN의 두 PC, 높은 손실/지연/악성 메시지 전체, 완전한 예측 재적용/원격 소품 보간, 임시 물리 세계 배치 검증, 모든 생활/게임을 함께 담은 저장 왕복이 남았다.
- 성능: 동일 PC의 독립 Chromium 8개에서 호스트 6~7fps로 목표 미달. 2~8인/1080p 60fps 또는 저품질 30fps를 보장하지 않는다. 메모리 0 표시는 미계측이며 전체 RAM/VRAM 사용량을 뜻하지 않는다. 장시간 누수 측정과 저사양 최적화가 남았다.
- 입력: 상태에 따른 이동 차단과 감도/Esc 탈출은 있으나 사용자 키 재설정 전체 UI가 남았다.

기존 파일/Blender/Firebase 보존본은 작업 폴더 artifacts에 있다. 백업 ZIP을 새 공개 저장소에 자동 게시하지 않는다.
'''
(d/'required-remaining.md').write_text(remaining,encoding='utf8')
# Pin exactly the package versions already installed and tested.
pkg=json.loads((p/'package.json').read_text());lock=json.loads((p/'package-lock.json').read_text());pkg['version']='0.2.0-dev'
for group in ['dependencies','devDependencies']:
 for name in pkg.get(group,{}):pkg[group][name]=lock['packages']['node_modules/'+name]['version']
pkg['scripts']['test']='node --test tests/save-v2.test.mjs tests/arcade-rules.test.mjs'
lock['version']=pkg['version'];lock['packages']['']['version']=pkg['version']
for group in ['dependencies','devDependencies']:lock['packages'][''][group]=pkg[group]
(p/'package.json').write_text(json.dumps(pkg,indent=2)+'\n');(p/'package-lock.json').write_text(json.dumps(lock,indent=2)+'\n')
# Blender scripts accept an explicit path on any machine; current blend file also supplies a default.
for name in ['build_v2.py','materials_v2.py','prepare_v2_character.py','optimize_furniture_v2.py','preview_v2.py']:
 f=p/'art'/name;s=f.read_text(encoding='utf8');s=s.replace("Path(r'C:/Users/admin/Documents/ChatGPT/3D_모임/homeoffice')", "Path(__import__('os').environ.get('MOYEO_PROJECT', str(Path(bpy.data.filepath).parent.parent)))")
 f.write_text(s,encoding='utf8')
shutil.copyfile(p/'assets/fonts/OFL-NotoSansKR.txt',p/'docs/licenses/NotoSansKR-OFL-1.1.txt')
print('56 requirements, 80 tests, mandatory remaining scope and exact dependency versions updated')
