from pathlib import Path
p=Path(__file__).resolve().parents[1]
c=p/'tools/v2_base.txt';s=c.read_text(encoding='utf8')
s=s.replace('var frozen=false','var transfer_frozen=false\nvar frozen=false')
s=s.replace('frozen=bool(e.hidden)','frozen=transfer_frozen or bool(e.hidden)')
s=s.replace('\t\t"slide_texture":', '''		"handoff_freeze":
			transfer_frozen=bool(e.paused)
			frozen=transfer_frozen
			for o in objects.values():
				if o is RigidBody3D:o.freeze=frozen or not host
		"handoff_capture":
			if host and bridge:bridge.handoff_capture(JSON.stringify(make_checkpoint()))
		"handoff_commit":apply_checkpoint(e)
		"slide_texture":''')
s=s.replace('"state":o.get_meta("state")}', '"state":o.get_meta("state"),"v":arr(o.linear_velocity) if o is RigidBody3D else [0,0,0],"av":arr(o.angular_velocity) if o is RigidBody3D else [0,0,0],"seats":o.get_meta("seats",{})}')
c.write_text(s,encoding='utf8')
c=p/'tools/v2_functions.txt';s=c.read_text(encoding='utf8')+'''

func make_checkpoint() -> Dictionary:
	return {"world":save_world(),"state":network_state(),"memberSlots":member_slots,"memberIdentity":member_identity,"roomClaims":room_claims,"tagScore":tag_score}

func apply_checkpoint(e:Dictionary):
	var checkpoint=e.get("checkpoint",{})
	host=false
	if not checkpoint.is_empty():
		restore_world(checkpoint.world)
		var state=checkpoint.state
		for a in state.players:
			add_player(a.id)
			var player=players.get(a.id)
			if not player:continue
			player.position=vec(a.p)
			player.remote_target=vec(a.p)
			player.velocity=vec(a.v)
			player.rotation.y=float(a.yaw)
			player.remote_yaw=float(a.yaw)
			player.command.yaw=float(a.yaw)
			player.command.pitch=float(a.pitch)
			player.command.x=0.0;player.command.z=0.0;player.command.jump=false
			player.seated=a.seat;player.holding=a.hold
			player.seat_yaw=float(a.seatYaw)
			player.posture=a.posture;player.seat_index=int(a.seatIndex)
			player.last_input_ms=Time.get_ticks_msec()
			if a.id==local_id:yaw=float(a.yaw);pitch=float(a.pitch)
		for a in state.objects:
			var object=objects.get(a.id)
			if not object:continue
			object.position=vec(a.p);object.rotation=vec(a.r)
			object.set_meta("owner",a.owner);object.set_meta("occupant",a.occupant);object.set_meta("seats",a.get("seats",{}))
			var object_state=a.state.duplicate(true)
			object_state.erase("nextShot");object_state.erase("reloadUntil")
			object.set_meta("state",object_state)
			if object is RigidBody3D:object.linear_velocity=vec(a.v);object.angular_velocity=vec(a.av)
		member_slots=checkpoint.memberSlots.duplicate(true)
		member_identity=checkpoint.memberIdentity.duplicate(true)
		room_claims=checkpoint.roomClaims.duplicate(true)
		door_states=state.doors.duplicate(true)
		weapon_grants=state.grants.duplicate(true)
		weapon_zones=state.weaponZones.duplicate(true)
		rounds=state.rounds.duplicate(true)
		tag_score=checkpoint.tagScore.duplicate(true)
	host=bool(e.host)
	epoch=e.epoch
	inputs.clear();actions.clear();ball_previous.clear()
	last_remote_tick=-1
	last_snapshot_ms=Time.get_ticks_msec()
	transfer_frozen=false;frozen=false;ready_to_play=true
	for object in objects.values():
		if object is RigidBody3D:object.freeze=not host
'''
c.write_text(s,encoding='utf8')
c=p/'web/bridge.mjs';s=c.read_text(encoding='utf8');s="import {createHandoff} from './handoff.mjs';\n"+s
s=s.replace("if(size>1024*1024)return;", "if(size>(m.type==='handoff-offer'?4:1)*1024*1024)return;\n  if(m.type.startsWith('handoff-')){handoff.receive(c.peer,m);return}")
s=s.replace("if(host&&(connections.size>=7||connections.has(c.peer)))", "if(host&&(handoff.active()&&!handoffSwitching||connections.size>=7||connections.has(c.peer)))")
s=s.replace("c.on('close',()=>{connections.delete", "c.on('close',()=>{if(c.retired)return;connections.delete")
s=s.replace("async export_world(json)","handoff_capture:json=>handoff.captured(json),\n async export_world(json)")
s=s.replace("const controls=document", "const controls=document")
s+='''

async function flushNetwork(){for(let n=0;n<160;n++){if([...sendQueues.values()].every(q=>!q.urgent.length)&&[...connections.values()].every(c=>(c.dataChannel?.bufferedAmount||0)<1024))return;await new Promise(r=>setTimeout(r,25))}throw Error('전송 대기열이 비워지지 않았습니다')}
const handoff=createHandoff({host:()=>host,id:()=>id,room:()=>room,peers:()=>[...connections.keys()],composing:()=>collaboration.diagnostics().composing,
 pause(){playing=false;stopTransmit();collaboration.hide();activities.hide();presentation.hide();$('tool').hidden=true;document.activeElement?.blur();status('방장 이전 중 · 세계와 문서의 확인 시점을 맞추고 있습니다.')},resume,notify:status,engine:push,send:(m,to)=>net({...m,epoch},to),flush:flushNetwork,
 decorate(world){world.collaboration=collaboration.snapshot();world.presentation=presentation.metadata();return world},presentation:()=>presentation.session(),voice:()=>({max:voiceMax,broadcast:[...broadcastAllowed],ranges:rangeByPeer,modes:voiceModes,blocks:blocksByPeer}),
 async validate(c){validateWorld(c.world);collaboration.validate(c.world.collaboration);await presentation.validate(c.world.presentation,presentation.attachments);if(!c.state?.players.some(p=>p.id===id))throw Error('수신 참가자가 체크포인트에 없습니다')},
 async switch(target,newEpoch,checkpoint){
  handoffSwitching=true;playing=false;stopTransmit();const old=[...connections.values()];for(const c of old){c.retired=true;sendQueues.delete(c)}connections.clear();host=id===target;room=target;epoch=newEpoch;
  if(host&&checkpoint){collaboration.restore(checkpoint.world.collaboration);presentation.setSession(checkpoint.presentation);voiceMax=checkpoint.voice.max;broadcastAllowed=new Set(checkpoint.voice.broadcast);rangeByPeer=checkpoint.voice.ranges;voiceModes=checkpoint.voice.modes;blocksByPeer=checkpoint.voice.blocks;}
  push({type:'handoff_commit',host,epoch,checkpoint:checkpoint||{}});
  for(const c of old)c.close();
  if(host){handoffSwitching=false;entered();status('세계·문서·권위를 인수했습니다. 친구들의 재연결을 기다립니다.')}
  else{bind(peer.connect(room,{reliable:true,serialization:'json',metadata:{clientId:clientIdentity}}));status('새 방장에게 다시 연결하는 중입니다.')}
 }
});
const transferPanel=document.createElement('div');transferPanel.innerHTML='<h3>방장 이전</h3><select id="nextHost"></select><button id="transferHost">선택한 친구에게 세계와 방장 권한 이전</button><p>정상 연결 중 확인·일시정지·인수·재접속을 진행합니다. 강제 종료는 마지막 확인 복구본을 사용하며 미확정 변경은 잃을 수 있습니다.</p>';$('hostControls').append(transferPanel);
setInterval(()=>{const select=$('nextHost'),before=select.value,ids=[...connections.keys()];if(select.dataset.ids===ids.join(','))return;select.dataset.ids=ids.join(',');select.replaceChildren();for(const who of ids)select.append(new Option(who.slice(-6),who));if(ids.includes(before))select.value=before},1000);$('transferHost').onclick=()=>handoff.begin($('nextHost').value);
'''
c.write_text(s,encoding='utf8')
print('Two-phase host transfer, checkpoint physics and document authority implemented')
