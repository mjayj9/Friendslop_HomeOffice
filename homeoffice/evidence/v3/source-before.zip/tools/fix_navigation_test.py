from pathlib import Path
p=Path(__file__).resolve().parents[1]/'tests/v2-navigation.gd'
s=p.read_text(encoding='utf8').replace('\t\tawait physics_frame\n\t\tframes+=1','\t\tactor.last_input_ms=Time.get_ticks_msec()\n\t\tawait physics_frame\n\t\tframes+=1')
p.write_text(s,encoding='utf8')
