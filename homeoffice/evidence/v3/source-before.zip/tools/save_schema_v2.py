from pathlib import Path
import json
R=Path(__file__).resolve().parents[1];out=R/'schemas';out.mkdir(exist_ok=True)
def obj(props,required=None):return {'type':'object','additionalProperties':False,'properties':props,'required':list(props) if required is None else required}
def string(n=100):return {'type':'string','minLength':1,'maxLength':n,'pattern':r'^[^\u0000-\u001f<>]+$'}
def number(a,b):return {'type':'number','minimum':a,'maximum':b}
def array(items,n,minimum=0):return {'type':'array','items':items,'maxItems':n,'minItems':minimum}
def ref(name):return {'$ref':'#/$defs/'+name}
asset=['chair','table','sofa','book','crate','marker','low_table','bed','counter','cooker','sink','fridge','plate','pan','basketball','football','ingredient','meal','gun','shield','arcade','storage','drawer','floor_lamp']
defs={
'position':array(number(-110,110),3,3),
'point':array(number(0,1),2,2),
'state':obj({**{k:{'type':'boolean'} for k in ['food','dirty','ready','open','on']},**{k:string(40) for k in ['recipe','stage']},**{k:number(0,1e15) for k in ['cooking','ammo','reloadUntil','nextShot']},'contents':array(string(),4)},[]),
'object':obj({'id':string(),'kind':{'enum':asset},'p':ref('position'),'yaw':number(-100000,100000),'state':ref('state')}),
'roomSlot':obj({'personalRoomId':{'type':'string','pattern':'^office-[1-8]$'},'memberSlotId':{'type':'string','pattern':'^slot-[1-8]$'},'moduleIndex':{'type':'integer','minimum':0,'maximum':3},'side':{'enum':[0,1]},'label':string(60)}),
'stroke':obj({'id':string(180),'author':string(),'points':array(ref('point'),256,2),'color':{'enum':['#183b32','#bd5737','#305ea2','#f4f4ed']},'width':number(1,24),'kind':{'const':'text'},'text':{'type':'string','maxLength':160},'fontSize':{'const':28},'version':{'type':'integer','minimum':0}},['id','author','points','color','width']),
'attachment':obj({'id':{'type':'string','pattern':'^[a-f0-9]{64}$'},'sha256':{'type':'string','pattern':'^[a-f0-9]{64}$'},'name':string(160),'mime':{'enum':['image/png','image/jpeg','application/pdf']},'bytes':{'type':'integer','minimum':1,'maximum':16*1024*1024}}),
'result':obj({'game':{'enum':['maze','runner']},'score':{'type':'integer','minimum':0,'exclusiveMaximum':10000000},'won':{'type':'boolean'}})
}
score=array({'type':'integer','minimum':0,'exclusiveMaximum':10000000},2,2)
schema=obj({'schemaVersion':{'const':2},'worldId':string(),'assetPack':{'const':2},'layoutVersion':{'const':2},'roomSlots':array(ref('roomSlot'),8),'objects':array(ref('object'),256),'doors':{'type':'object','propertyNames':{'pattern':'^(front-door|terrace-door|meeting-door|game-gate|sleep-door|office-[1-8]-door)$'},'additionalProperties':{'type':'boolean'},'maxProperties':20},'board':array(ref('stroke'),512),'revision':{'type':'integer','minimum':0},'results':obj({'basketball':score,'football':score,'arcade':array(ref('result'),64)},['basketball','football']),'settings':obj({'maxPlayers':{'const':8}}),'collaboration':obj({'update':{'type':'string','maxLength':3000000,'pattern':'^[A-Za-z0-9+/]*={0,2}$'},'revision':{'type':'integer','minimum':0}}),'presentation':array(ref('attachment'),64),'presentationView':{'type':'object','description':'Additional validation in web/presentation-view.mjs: presenter-free selected asset/page and bounded annotations.'}},['schemaVersion','worldId','assetPack','layoutVersion','roomSlots','objects','doors','board','revision','results','settings'])
schema.update({'$schema':'https://json-schema.org/draft/2020-12/schema','$id':'https://mjayj9.github.io/Friendslop_HomeOffice/schemas/world-v2.schema.json','title':'Moyeo Homeworld V2 structural interchange schema','$defs':defs,'$comment':'Structural documentation only. Runtime save-v2.mjs and presentation-view.mjs additionally enforce reference consistency, unique IDs, exact room slot ordering, valid storage types/capacity, world and attachment checksums, ZIP paths/limits and materialized Yjs/PDF validation.'})
(out/'world-v2.schema.json').write_text(json.dumps(schema,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
(out/'manifest-v2.schema.json').write_text(json.dumps({'$schema':'https://json-schema.org/draft/2020-12/schema',**obj({'format':{'const':'homeworld'},'schemaVersion':{'const':2},'assetPack':{'const':2},'createdAt':string(40),'worldSha256':{'type':'string','pattern':'^[a-f0-9]{64}$'}})},indent=2)+'\n',encoding='utf8')
print('Versioned structural schemas written; runtime semantic validation remains authoritative')
