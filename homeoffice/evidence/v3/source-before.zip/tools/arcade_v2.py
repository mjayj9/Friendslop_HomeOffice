from pathlib import Path
p=Path(__file__).resolve().parents[1]
c=p/'web/bridge.mjs';s=c.read_text(encoding='utf8');s="import {createArcade} from './arcade.mjs';\n"+s
s=s.replace("if(m.type==='arcade-progress'||m.type==='arcade-result'){", "if(m.type.startsWith('arcade-')){if(m.epoch===epoch)arcade.receive(c.peer,m);return}\n  if(m.type==='arcade-progress'||m.type==='arcade-result'){")
s=s.replace('collaboration.hide();activities.hide();presentation.hide();','collaboration.hide();activities.hide();presentation.hide();arcade.hide();')
s=s.replace("else if(['catalog','runner','maze'].includes(mode))activities.open(mode)","else if(['runner','maze'].includes(mode))arcade.open(mode);else if(mode==='catalog')activities.open(mode)")
s=s.replace('m.world.presentation=presentation.metadata();','m.world.presentation=presentation.metadata();m.world.results.arcade=arcade.results();')
s=s.replace('world.presentation=presentation.metadata();','world.presentation=presentation.metadata();world.results.arcade=arcade.results();')
# The two patterns overlap inside m.world; remove any standalone identifier inserted into that path.
s=s.replace('m.world.presentation=presentation.metadata();world.results.arcade=arcade.results();m.world.results.arcade=arcade.results();','m.world.presentation=presentation.metadata();m.world.results.arcade=arcade.results();')
s=s.replace('presentation.restore(pendingWorld.presentation,pendingAttachments);','presentation.restore(pendingWorld.presentation,pendingAttachments);arcade.restore({records:pendingWorld.results.arcade||[]});')
s=s.replace('presentation:()=>presentation.session(),voice:', 'arcade:()=>arcade.snapshot(),presentation:()=>presentation.session(),voice:')
s=s.replace('presentation.setSession(checkpoint.presentation);','presentation.setSession(checkpoint.presentation);arcade.restore(checkpoint.arcade);')
s=s.replace('return {performance:perfSample,host,','return {arcade:arcade.diagnostics(),performance:perfSample,host,')
s+='\nconst arcade=createArcade({send:m=>net({...m,epoch}),isHost:()=>host,id:()=>id,state:()=>currentState,notify:status});\n'
c.write_text(s,encoding='utf8')
c=p/'web/handoff.mjs';s=c.read_text(encoding='utf8').replace('checkpoint.voice=h.voice();','checkpoint.voice=h.voice();checkpoint.arcade=h.arcade();');c.write_text(s,encoding='utf8')
c=p/'web/save-v2.mjs';s=c.read_text(encoding='utf8').replace("keys(w.results,['basketball','football']);for(const a of Object.values(w.results))", "keys(w.results,['basketball','football'],['arcade']);if(w.results.arcade!==undefined){if(!Array.isArray(w.results.arcade)||w.results.arcade.length>64)bad();for(const r of w.results.arcade){keys(r,['game','score','won']);if(!['maze','runner'].includes(r.game)||!Number.isSafeInteger(r.score)||r.score<0||r.score>1e7||typeof r.won!=='boolean')bad()}}for(const a of [w.results.basketball,w.results.football])")
c.write_text(s,encoding='utf8')
print('Original maze and runner now host-simulated with occupancy, spectators, validated input, results and handoff state')
