import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
const root = process.cwd();
const base = path.join(root,'homeoffice');
for (const dir of ['assets/characters','assets/environment','art','docs','tests','web','scripts','scenes','build','evidence']) await fs.mkdir(path.join(base,dir),{recursive:true});
const report=[];
for(const id of [1157,1158,1160,1161,1162]) {
 const name=`quaternius_cc0-male-character-${id}.glb`;
 const buffer=await fs.readFile(`C:/Users/admin/Downloads/${name}`);
 const json=JSON.parse(buffer.subarray(20,20+buffer.readUInt32LE(12)).toString());
 report.push({id,bytes:buffer.length,sha256:crypto.createHash('sha256').update(buffer).digest('hex'),nodes:json.nodes,skins:json.skins,animations:json.animations?.map(a=>({name:a.name,channels:a.channels.length,duration:Math.max(...a.samplers.map(s=>json.accessors[s.input].max?.[0]||0))}))||[],materials:json.materials,images:json.images,meshes:json.meshes?.map(m=>({name:m.name,primitives:m.primitives.map(p=>({vertices:json.accessors[p.attributes.POSITION].count,bounds:[json.accessors[p.attributes.POSITION].min,json.accessors[p.attributes.POSITION].max],joints:p.attributes.JOINTS_0!==undefined,triangles:p.indices!==undefined?json.accessors[p.indices].count/3:null}))}))});
 await fs.copyFile(`C:/Users/admin/Downloads/${name}`,path.join(base,'assets/characters',name));
}
await fs.writeFile(path.join(base,'docs/character-inspection.json'),JSON.stringify(report,null,2));
console.log(JSON.stringify(report.map(r=>({id:r.id,bytes:r.bytes,skins:r.skins?.map(s=>({name:s.name,joints:s.joints.length})),animations:r.animations,meshes:r.meshes,materials:r.materials?.length,images:r.images?.length})),null,2));
await fs.copyFile('C:/Users/admin/Downloads/Godot_Friendslop_HomeOffice_Master_Prompt_KO.md',path.join(base,'docs/user-specification.md'));
