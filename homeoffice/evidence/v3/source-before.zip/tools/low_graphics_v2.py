from pathlib import Path
p=Path(__file__).resolve().parents[1]
f=p/'tools/v2_base.txt';s=f.read_text(encoding='utf8').replace('var slide_laser:MeshInstance3D','var sunlight:DirectionalLight3D\nvar slide_laser:MeshInstance3D').replace('var sun=DirectionalLight3D.new()','var sun=DirectionalLight3D.new()\n\tsunlight=sun');f.write_text(s,encoding='utf8')
f=p/'tools/v2_functions.txt';s=f.read_text(encoding='utf8').replace('get_viewport().scaling_3d_scale=.75 if low else 1.0','get_viewport().scaling_3d_scale=.75 if low else 1.0\n\tget_viewport().msaa_3d=Viewport.MSAA_DISABLED if low else Viewport.MSAA_2X\n\tif sunlight:sunlight.shadow_enabled=not low');f.write_text(s,encoding='utf8')
f=p/'web/bridge.mjs';s=f.read_text(encoding='utf8').replace('저사양 · 75% 해상도 / 조명 2개','저사양 · 75% 해상도 / 조명 2개 / 그림자 끄기');f.write_text(s,encoding='utf8')
