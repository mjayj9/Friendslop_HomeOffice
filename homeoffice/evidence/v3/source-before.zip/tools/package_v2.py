"""Reproducible reviewed source + exported web packages, preserving all P1 ZIPs."""
from pathlib import Path
import subprocess,zipfile,json,hashlib,datetime
R=Path(__file__).resolve().parents[1];repo=R.parent/'deployment/Friendslop_HomeOffice';out=R/'releases';out.mkdir(exist_ok=True)
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip()
tracked=subprocess.check_output(['git','ls-files','-z'],cwd=repo).decode().split('\0')
readme='''모여집 V2 검토 빌드

실행: https://mjayj9.github.io/Friendslop_HomeOffice/
프로젝트 ZIP은 homeoffice/build에 동일한 웹 빌드를 포함합니다.
Node.js 22.12 이상에서 homeoffice 폴더의 npm ci --ignore-scripts, npm run dev를 실행하세요.
http://127.0.0.1:8060/homeoffice/?signal=local 에서 공간을 열고 친구는 초대 코드를 입력합니다.
Godot 실행 파일/export templates, node_modules는 포함하지 않았습니다. 자세한 설치·재빌드는 homeoffice/README.md를 확인하세요.

원문 전체 완료가 아닌 개발 빌드입니다. 전체 U01~U56과 80개 인수 상태, 필수 잔여 작업은 homeoffice/docs/v2에 있습니다.
실제 사람 마이크/한국어 인식·자연스러운 전체 캐릭터 동작·팀 게임·통합 생활 인수·8인 성능 등이 필수 미완료입니다.
검토 빌드 커밋: '''+commit+'\n'
rows=[]
for kind in ['project','web']:
 target=out/f'moyeo-homeoffice-v2-{kind}.zip'
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  if kind=='project':
   for name in tracked:
    if name.startswith('homeoffice/') and (repo/name).is_file():z.write(repo/name,name)
   for name in tracked:
    if name.startswith('docs/') and (repo/name).is_file():z.write(repo/name,'homeoffice/build/'+name[5:])
   z.writestr('START_HERE_KO.txt',readme)
  else:
   for name in tracked:
    if name.startswith('docs/') and (repo/name).is_file():z.write(repo/name,name[5:])
   z.writestr('START_HERE_KO.txt','웹 서버에서 index.html을 제공하세요. file://로 열지 않습니다. GitHub Pages의 저장소 하위 경로를 지원합니다.\n\n'+readme)
 with zipfile.ZipFile(target) as z:
  bad=z.testzip();assert bad is None,bad
  names=z.namelist();assert not any('/.runtime/' in n or '/node_modules/' in n or '/.git/' in n or '/_qa/' in n for n in names)
 rows.append({'file':target.name,'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'entries':len(names),'crcVerified':True})
report={'version':'0.2.0-dev','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceCommit':commit,'url':'https://mjayj9.github.io/Friendslop_HomeOffice/','engine':'Godot 4.6.1 stable, Compatibility, single-thread, Jolt','completeProduct':False,'packages':rows}
(out/'release-manifest-v2.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps(report,ensure_ascii=False,indent=2))
