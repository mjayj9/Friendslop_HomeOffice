from pathlib import Path
R=Path(__file__).resolve().parents[1]
p=R/'tools/v2_functions.txt';s=p.read_text(encoding='utf8').replace('return is_instance_valid(light))','return is_instance_valid(light) and light.is_inside_tree())');p.write_text(s,encoding='utf8')
p=R/'tests/v2-bindings-ownership.mjs';s=p.read_text(encoding='utf8').replace('w.move(-.3,1.8)','w.move(-.3,-2)').replace('w.move(3.4,1.8)','w.move(3.4,-2)');s=s.replace('await w.move(3.4,-2)}await wa.move','await w.move(3.4,-2);await w.move(w===wa?5.5:6.4,1.5)}await wa.move');s=s.replace('await w.move(-5.6,10.5)}await wa.move','await w.move(-5.6,10.5);await w.move(-6.2,w===wa?10.65:9.55)}await wa.move');p.write_text(s,encoding='utf8')
print('Removed detached lights from render selection; test route uses real free-room doorway and separate arrival spots')
