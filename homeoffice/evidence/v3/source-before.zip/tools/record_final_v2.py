from pathlib import Path
import json
R=Path(__file__).resolve().parents[1]
def edit(name,fn):
 p=R/name;p.write_text(fn(p.read_text(encoding='utf8')),encoding='utf8')
edit('docs/v2/performance.md',lambda s:s+'''\n## 신규 수납/키 설정 빌드의 동일 PC 8인 측정

`evidence/v2-multiplayer-scale-low.json`: 모두 자동 저사양(65%, MSAA/태양 그림자 끄기), 호스트 1920×1080, 손님 640×360. 2명 호스트 45fps/250 draw calls, 4명 37fps/320, 8명 12~14fps/460. 연결과 개인실·퇴장 보존 4개 검사는 통과하고 브라우저 오류는 0개였다. 8명 성능 목표는 여전히 미달이다. STT/마이크 없는 정지 시점이며 이 숫자를 8대의 별도 PC 성능이나 전체 기능 동시 사용 성능으로 해석하지 않는다.

측정 뒤 수납함 하나를 기존 화분과 겹치지 않는 거실 위치로 옮겼다. 신규 에셋 수/메시/조명/렌더 설정은 같다. 공개 HTTPS의 별도 2브라우저 측정은 pages-validation.json이다.
''')
edit('docs/v2/required-remaining.md',lambda s:s.replace('동일 PC의 독립 Chromium 8개에서 호스트 6~7fps로 목표 미달.','동일 PC의 독립 Chromium 8개에서 이전 기본 설정 6~7fps, 최신 저사양 설정 12~14fps로 목표 미달.').replace('두 사람 교행/가구 설치 경합','물건을 든 두 사람 교행/가구 설치 경합'))
edit('README.md',lambda s:s.replace('한 PC에 브라우저 8개를 실행한 시험에서 호스트 6~7fps로 목표 성능에 못 미쳤습니다.','한 PC의 브라우저 8개에서 이전 기본 설정 6~7fps, 최신 저사양 설정 12~14fps로 목표 성능에 못 미쳤습니다.').replace('| `evidence/v2-browser-walk.json`,', '| `evidence/v2-bindings-ownership.json`, `v2-storage-visual.json` | 실제 키 재설정, 두 사용자 물건/좌석 경합, 책 수납·뚜껑·서랍·다운로드 |\n| `evidence/v2-browser-walk.json`,').replace('소스 수정 시 `node tools/bundle_collaboration.mjs`','Godot 템플릿 수정 시 `python tools/assemble_v2.py`로 실행 스크립트를 다시 조합합니다. 소스 수정 시 `node tools/bundle_collaboration.mjs`'))
changes={
'T23':'부분 통과 · v2-bindings-ownership.json 실제 물리 키 변경/중복 거절/페이지 재로드 보존/메뉴 후 keyup 경합 통과. 모든 키보드 배열과 접근성 전수는 미완료',
'T27':'통과 · v2-bindings-ownership.json 두 독립 Chromium 실제 WebRTC/보행/동시 키 요청에서 상자 한 소유자, 의자 한 점유자와 상대 동기화 확인',
'T28':'부분 통과 · v2-authority.json 점유 의자 보호, v2-living-props.json 열린/수납 가구 이동·철거 보호, 퇴장 정리. 배치 삭제 경합 전체 미완료',
'T32':'부분 통과 · 실제 다중 브라우저 이동/집기, 원격 소품 위치·회전 보간 추가. 완전한 입력 재적용/고지연 인수 미완료',
}
def acceptance(s):
 lines=[]
 for line in s.splitlines():
  parts=line.split('|')
  if len(parts)>=6 and parts[1].strip() in changes:parts[4]=' '+changes[parts[1].strip()]+' ';line='|'.join(parts)
  lines.append(line)
 return '\n'.join(lines)+'\n\n추가 생활 시험: `v2-living-props.json` 실제 엔진 12개 통과, `v2-storage-visual.json` 실제 브라우저 4개 통과, `storage-save.test.mjs` 수납 참조/왕복 2개 통과. 이 결과를 원문 전체 80개 인수 통과로 합산하지 않는다.\n'
edit('docs/v2/acceptance-80.md',acceptance)
edit('docs/v2/requirements-traceability.md',lambda s:s.replace('원격 소품 보간·예측 재적용 정밀 검사','원격 소품 보간의 지연 시험·예측 재적용 정밀 검사')+'\n추가 연결: U20~U28의 일반 사물/입력 경로에 `web/key-bindings.mjs`, `art/living_props_v2.py`, `assets/v2/{storage,drawer,floor_lamp}.glb`, `setup_living_prop/use_storage/update_living_props`를 연결했다. 실제 두 브라우저 점유 9개 검사와 최종 수납/서랍 캡처 4개는 evidence/v2-bindings-ownership.json 및 v2-storage-visual.json, 실제 엔진 생활 12개는 v2-living-props.json이다. 개별 원문 요구 전체의 미검증 범위는 표대로 유지한다.\n')
edit('docs/deployment.md',lambda s:s+'\n키 재설정·실제 수납함/서랍/조명·저장 참조 검사·원격 소품 보간을 추가한 실행 빌드를 같은 개발 브랜치의 `/docs`에 갱신한다. main과 이전 프로젝트는 유지한다. `deployment/github-pages.yml`은 선택적 수동 재빌드 예제이며 현재 실제 배포는 Pages 브랜치 배포다.\n')
edit('tools/build.ps1',lambda s:s.replace('& $Godot --headless --path $projectRoot --editor --import --quit\nif ($LASTEXITCODE -ne 0) { throw \'Godot import failed\' }', '$importOutput = & $Godot --headless --path $projectRoot --editor --import --quit 2>&1\n$importExit = $LASTEXITCODE\n$importOutput | Write-Output\nif ($importExit -ne 0 -or ($importOutput -match "SCRIPT ERROR|Parse Error|ERROR: Failed to load")) { throw \'Godot import failed\' }'))
print('Actual final tests, performance and mandatory remaining scope recorded')
