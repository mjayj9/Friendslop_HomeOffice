from pathlib import Path
p=Path(__file__).resolve().parents[1]
c=p/'tools/v2_base.txt';s=c.read_text(encoding='utf8').replace('var module_nodes=[]','var room_lights=[]\nvar module_nodes=[]')
s=s.replace('sun.directional_shadow_max_distance=75','sun.directional_shadow_max_distance=35\n\tsun.directional_shadow_mode=DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS')
s=s.replace('\t\tadd_child(lamp)\n\tfor d in layout.doors:', '\t\tlamp.set_meta("base_energy",.32)\n\t\tlamp.set_meta("zone",r.id)\n\t\troom_lights.append(lamp)\n\t\tadd_child(lamp)\n\tfor d in layout.doors:')
s=s.replace('\tupdate_object_visuals()','\tupdate_object_visuals()\n\tupdate_room_lighting(dt)')
c.write_text(s,encoding='utf8')
c=p/'tools/v2_functions.txt';s=c.read_text(encoding='utf8').replace('module_nodes.append(lamp)','lamp.set_meta("base_energy",.55)\n\tlamp.set_meta("zone",prefix)\n\troom_lights.append(lamp)\n\tmodule_nodes.append(lamp)')
s+='''

func update_room_lighting(dt:float):
	var player=players.get(local_id)
	if not player:return
	room_lights=room_lights.filter(func(light):return is_instance_valid(light))
	var eye=player.eye()
	room_lights.sort_custom(func(a,b):return a.position.distance_squared_to(eye)<b.position.distance_squared_to(eye))
	var low=bridge and String(bridge.graphics_quality())=="low"
	get_viewport().scaling_3d_scale=.75 if low else 1.0
	for i in range(room_lights.size()):
		var light=room_lights[i]
		var active=i<(2 if low else 4) and light.position.distance_to(eye)<16
		light.light_energy=lerpf(light.light_energy,float(light.get_meta("base_energy",.32)) if active else 0.0,minf(1.0,dt*5))
		light.visible=light.light_energy>.005
'''
c.write_text(s,encoding='utf8')
c=p/'web/bridge.mjs';s=c.read_text(encoding='utf8').replace('look_sensitivity:()=>',"graphics_quality:()=>$('graphicsQuality').value,look_sensitivity:()=>")
s=s.replace('<h3>시점 · 조작</h3>', '<h3>시점 · 조작</h3><label>그래픽 <select id="graphicsQuality"><option value="balanced">기본 · 가까운 조명 4개</option><option value="low">저사양 · 75% 해상도 / 조명 2개</option></select></label>')
c.write_text(s,encoding='utf8')
print('Bounded nearby dynamic lights, two sun cascades and user low-quality option; every room retained')
