from pathlib import Path
import json,hashlib,zipfile,re,urllib.request
root=Path(__file__).resolve().parents[2];base=root/'homeoffice'
preserved=[]
with zipfile.ZipFile(root/'artifacts/legacy-before-godot-20260914.zip') as z:
 for name in z.namelist():
  p=root/name
  if not p.exists() or hashlib.sha256(p.read_bytes()).digest()!=hashlib.sha256(z.read(name)).digest():preserved.append(name)
report={'legacyBackupEntriesChanged':preserved,'runtimeFiles':[],'models':[]}
for p in (base/'build').iterdir():
 if p.is_file() and p.suffix not in ['.import']:report['runtimeFiles'].append({'name':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
for p in list((base/'assets/environment').glob('*.glb'))+[base/'assets/characters/male-rigged.glb',base/'assets/characters/male-seated.glb']:
 raw=p.read_bytes();j=json.loads(raw[20:20+int.from_bytes(raw[12:16],'little')])
 report['models'].append({'name':p.name,'bytes':len(raw),'meshPrimitives':sum(len(m['primitives']) for m in j.get('meshes',[])),'triangles':sum(j['accessors'][s['indices']]['count']//3 for m in j.get('meshes',[]) for s in m['primitives']),'skins':len(j.get('skins',[])),'animationClips':len(j.get('animations',[]))})
(base/'evidence/artifact-audit.json').write_text(json.dumps(report,indent=2),encoding='utf8')
lic=base/'docs/licenses';lic.mkdir(exist_ok=True)
for folder,out in [('peerjs','PeerJS-MIT.txt'),('peer','PeerServer-MIT.txt'),('playwright','Playwright-Apache-2.0.txt')]:
 p=root/'node_modules'/folder/'LICENSE'
 if not p.exists():p=root/'node_modules'/folder/'LICENSE.txt'
 if p.exists():(lic/out).write_bytes(p.read_bytes())
for url,out in [('https://raw.githubusercontent.com/godotengine/godot/4.6.1-stable/LICENSE.txt','Godot-MIT.txt'),('https://raw.githubusercontent.com/jrouwe/JoltPhysics/master/LICENSE','Jolt-MIT.txt')]:
 try:
  with urllib.request.urlopen(url,timeout=20) as r:(lic/out).write_bytes(r.read())
 except Exception as e:print('LICENSE_FETCH_FAILED',out,str(e))
print(json.dumps({'legacyFilesUnchanged':not preserved,'changed':preserved,'modelCount':len(report['models']),'webBytes':sum(x['bytes'] for x in report['runtimeFiles'])},indent=2))
