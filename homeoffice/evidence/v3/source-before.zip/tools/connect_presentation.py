from pathlib import Path
R=Path(__file__).resolve().parents[1]
for name in ['pdf.mjs','pdf.worker.mjs']:
 (R/'web'/name).write_bytes((R/'node_modules/pdfjs-dist/build'/name).read_bytes())
p=R/'web/bridge.mjs';s=p.read_text(encoding='utf8');s="import {createPresentation} from './presentation.mjs';\n"+s;s=s.replace('encodeWorld,decodeWorld,validateWorld','encodeWorld,decodeWorld,decodeBundle,validateWorld')
s=s.replace('let peer,host=', 'let pendingAttachments=new Map();\nlet peer,host=')
s=s.replace('const collaboration=createCollaboration',"const presentation=createPresentation({send:(m,to='')=>net({...m,epoch},to),identity:()=>id,isHost:()=>host,members:()=>currentState?.players,inWorld:image=>push({type:'slide_texture',image}),notify:s=>status(s)});\nconst collaboration=createCollaboration")
s=s.replace("if(++count>100||!m||typeof m!=='object')return;", "if(++count>100||!m||typeof m!=='object'||typeof m.type!=='string'||m.type.length>40)return;")
s=s.replace("  if(m.type.startsWith('collab'))", "  if(m.type.startsWith('asset-')||m.type.startsWith('presentation-')){if(m.epoch!==epoch)return;presentation.receive(c.peer,m);return}\n  if(m.type.startsWith('collab'))")
s=s.replace("setTimeout(()=>sendRaw(c,{type:'collab-sync',epoch,...collaboration.snapshot()}),800)","setTimeout(()=>{sendRaw(c,{type:'collab-sync',epoch,...collaboration.snapshot()});presentation.sync(c.peer)},800)")
s=s.replace('collaboration.hide();activities.hide();','collaboration.hide();activities.hide();presentation.hide();')
s=s.replace("if(mode==='book')renderPage();", "if(mode==='presentation')presentation.open();else if(mode==='book')renderPage();")
s=s.replace("pendingWorld=await decodeWorld(new Uint8Array(await f.arrayBuffer()));", "const bundle=await decodeBundle(new Uint8Array(await f.arrayBuffer()));pendingWorld=bundle.world;pendingAttachments=bundle.attachments;")
s=s.replace('collaboration.restore(pendingWorld.collaboration);','collaboration.restore(pendingWorld.collaboration);presentation.restore(pendingWorld.presentation,pendingAttachments);')
s=s.replace('world.collaboration=collaboration.snapshot();lastWorld','world.collaboration=collaboration.snapshot();world.presentation=presentation.metadata();lastWorld')
s=s.replace('encodeWorld(world)', 'encodeWorld(world,presentation.attachments)').replace('encodeWorld(lastWorld)', 'encodeWorld(lastWorld,presentation.attachments)')
s=s.replace('if(m.world)m.world.collaboration=collaboration.snapshot();','if(m.world){m.world.collaboration=collaboration.snapshot();m.world.presentation=presentation.metadata();}')
# Reliable operations queue; transient transforms can be dropped, documents/assets cannot silently disappear.
start=s.index('function sendRaw(c,m)');end=s.index('function net(',start)
s=s[:start]+'''const sendQueues=new Map();
function sendRaw(c,m){if(!c?.open)return;const q=sendQueues.get(c)||{urgent:[],bulk:[],bytes:0};const text=JSON.stringify(m),size=text.length;if(['state','voice-ranges','arcade-progress'].includes(m.type)){if(c.dataChannel?.bufferedAmount<96*1024)try{c.send(m)}catch{}return}if(q.bytes+size>4*1024*1024){status('전송 대기 한도입니다. 큰 자료는 취소 후 다시 요청하세요.');return}q.bytes+=size;(m.type.startsWith('asset-')?q.bulk:q.urgent).push({m,size});sendQueues.set(c,q)}
setInterval(()=>{for(const[c,q]of sendQueues){if(!c.open){sendQueues.delete(c);continue}if(c.dataChannel?.bufferedAmount>96*1024)continue;const item=q.urgent.shift()||q.bulk.shift();if(item){q.bytes-=item.size;try{c.send(item.m)}catch{}}}},25);
''' +s[end:]
p.write_text(s,encoding='utf8')
p=R/'tools/v2_base.txt';s=p.read_text(encoding='utf8').replace('var board_body:StaticBody3D','var board_body:StaticBody3D\nvar slide_mesh:MeshInstance3D')
s=s.replace('\tsetup_board()','\tsetup_board()\n\tsetup_presentation()')
s=s.replace('\t\t"build":begin_build', '\t\t"slide_texture":set_slide(String(e.get("image","")))\n\t\t"build":begin_build')
p.write_text(s,encoding='utf8')
p=R/'tools/v2_functions.txt';s=p.read_text(encoding='utf8').replace('if target_id=="board":notify_ui(id,"board");return','if target_id=="presentation":notify_ui(id,"presentation");return\n\tif target_id=="board":notify_ui(id,"board");return').replace('elif id=="board":label=', 'elif id=="presentation":label="E 발표 자료 · PDF / 이미지"\n\telif id=="board":label=')
s+='''
func setup_presentation():
\tslide_mesh=MeshInstance3D.new()
\tvar quad=QuadMesh.new()
\tquad.size=Vector2(3.6,2.025)
\tslide_mesh.mesh=quad
\tslide_mesh.position=Vector3(9,1.85,4.14)
\tvar material=StandardMaterial3D.new()
\tmaterial.albedo_color=Color("e2e7d9")
\tmaterial.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED
\tslide_mesh.material_override=material
\tadd_child(slide_mesh)
\tvar body=StaticBody3D.new()
\tbody.position=slide_mesh.position
\tbody.set_meta("object_id","presentation")
\tcollision(body,Vector3.ZERO,Vector3(3.6,2.025,.045))
\tadd_child(body)

func set_slide(encoded:String):
\tif encoded.length()>1500000:return
\tvar bytes=Marshalls.base64_to_raw(encoded)
\tvar img=Image.new()
\tif img.load_jpg_from_buffer(bytes)!=OK or img.get_width()>2048 or img.get_height()>2048:return
\tslide_mesh.material_override.albedo_texture=ImageTexture.create_from_image(img)
''';p.write_text(s,encoding='utf8')
p=R/'assets/v2/layout.json';import json;l=json.loads(p.read_text(encoding='utf8'));l['board']=[4.4,1.76,4.14];p.write_text(json.dumps(l,ensure_ascii=False,indent=2),encoding='utf8')
p=R/'tools/design_v2.py';s=p.read_text(encoding='utf8').replace('board=[6.5,1.76,4.14]','board=[4.4,1.76,4.14]');p.write_text(s,encoding='utf8')
p=R/'art/build_v2.py';s=p.read_text(encoding='utf8').replace('[(-12,19),(4,20),(30,19)]','[(-12,17.4),(4,17.4),(30,17.4)]');p.write_text(s,encoding='utf8')
print('PDF/image presentation, separate bulk queue, host presenter authority and in-world screen connected')
