from pathlib import Path
import zipfile,hashlib,json,shutil
root=Path(__file__).resolve().parents[2]
src=root/'homeoffice'; out=root/'artifacts'/'homeoffice-p1-before-v2-20260914.zip'
if not out.exists():
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,6) as z:
        for p in src.rglob('*'):
            if p.is_file() and not any(s in {'.godot','.runtime','node_modules','releases'} for s in p.relative_to(src).parts):
                z.write(p,p.relative_to(root))
    with zipfile.ZipFile(out) as z: assert z.testzip() is None
dest=src/'docs'/'requirements-v2';dest.mkdir(parents=True,exist_ok=True)
for name in ['HomeOffice_Original_Requirements_56_KO.md','Friendslop_Godot_HomeOffice_V2_Complete_Architecture_KO.md']:
    shutil.copy2(Path('C:/Users/admin/Downloads')/name,dest/name)
print(json.dumps({'backup':str(out),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest()}))
