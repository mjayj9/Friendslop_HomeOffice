from pathlib import Path
import json, urllib.request, zipfile, hashlib, concurrent.futures
root=Path(__file__).resolve().parents[2]
base=root/'homeoffice'
runtime=base/'.runtime'
runtime.mkdir(exist_ok=True)
backup=root/'artifacts'/'legacy-before-godot-20260914.zip'
if not backup.exists():
    excluded={'.git','node_modules','.runtime','dist','artifacts','test-results','homeoffice','.firebase'}
    with zipfile.ZipFile(backup,'w',zipfile.ZIP_DEFLATED) as z:
        for p in root.rglob('*'):
            rel=p.relative_to(root)
            if p.is_file() and not any(x in excluded for x in rel.parts): z.write(p,rel)
    print('BACKUP',backup,backup.stat().st_size,flush=True)
def fetch(url,dest):
    if not dest.exists():
        req=urllib.request.Request(url,headers={'User-Agent':'Homeoffice-Development'})
        with urllib.request.urlopen(req,timeout=90) as r,open(dest,'wb') as f:
            while chunk:=r.read(1024*1024): f.write(chunk)
    print('DOWNLOADED',dest.name,dest.stat().st_size,flush=True)
    return dest
version='4.6.1'
urls=[(f'https://github.com/godotengine/godot-builds/releases/download/{version}-stable/Godot_v{version}-stable_win64.exe.zip',runtime/'godot.zip'),(f'https://github.com/godotengine/godot-builds/releases/download/{version}-stable/Godot_v{version}-stable_export_templates.tpz',runtime/'templates.tpz')]
with concurrent.futures.ThreadPoolExecutor() as e:
    list(e.map(lambda t:fetch(*t),urls))
with zipfile.ZipFile(runtime/'godot.zip') as z: z.extractall(runtime/'godot')
with zipfile.ZipFile(runtime/'templates.tpz') as z:
    for name in ['templates/web_nothreads_release.zip','templates/web_nothreads_debug.zip','templates/version.txt']:
        z.extract(name,runtime)
print('ENGINE_READY',flush=True)
refs=base/'docs'/'reference-source'
refs.mkdir(exist_ok=True)
for name in ['README.md','LICENSE','AGENTS.md','docs/architecture.md','docs/voice.md','docs/deployment.md','src/shared/level.ts','src/shared/simulation.ts','src/client/main.ts','src/host/index.ts']:
    dest=refs/name.replace('/','_')
    try:fetch('https://raw.githubusercontent.com/larshurrelb/friendslop-base/main/'+name,dest)
    except Exception as e: print('REFERENCE_UNAVAILABLE',name,str(e),flush=True)

